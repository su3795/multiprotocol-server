# 协议参考实现（Node.js 基准）

> **这是整个交付中唯一能真实运行、且已实际跑通的代码。**

沙盒没有 Java / Go / Rust 工具链，那三版都无法编译验证。
本参考实现用 Node.js 编写，**真实运行并通过了全部测试**，
为三版提供了一个可对照的黄金基准。

---

## 为什么需要它

| 问题 | 本项目的回答 |
|---|---|
| 三版都没编译过，协议设计本身对不对？ | 这里有一个跑通的等价实现，证明设计自洽 |
| 三版编译出来后怎么验证？ | 用 golden 向量逐字节比对 |
| 怎么确认我的改动没破坏互通？ | 跑本实现的测试 + 三版的 golden 测试 |

---

## 已验证内容

### 单元测试（23 项全通过）

```bash
npm test
```

覆盖：CRC32 与标准 IEEE 一致（含 `"123456789" → 0xCBF43926` 标准值）、
帧编解码往返、TCP 粘包/半包、magic 错误、CRC 损坏、KCP 分片重组、
**连续丢包 3 轮后重传恢复**、乱序、conv 校验、32 位回绕。

### 端到端测试（15 项全通过）

```bash
npm run e2e
```

在进程内启动真实服务端与客户端，通过 **真实 loopback socket** 通信：

| 协议 | 结果 |
|---|---|
| TCP | ✓ PING / PUT / GET / ROUTE_SET / ROUTE_GET |
| UDP | ✓ PING / PUT / GET |
| CUSTOM | ✓ PING / PUT / GET |
| **KCP** | ✓ PING / PUT / GET / STATS（含 ARQ 重传） |

---

## 用法

### 作为基准服务端

```bash
npm start
# 或指定端口
node src/server.js --tcp 9101 --udp 9201 --custom 9301 --kcp 9401
```

三版编译出来后，用各自的客户端连本服务端，若行为一致即说明实现正确。

### 作为基准客户端

```bash
node src/client.js --proto tcp  --port 9101
node src/client.js --proto udp  --port 9201
node src/client.js --proto custom --port 9301
node src/client.js --proto kcp  --port 9401
```

可连任意一版的服务端（Java / Go / Rust / 本实现）。

### 生成 golden 向量

```bash
npm run golden
```

输出到 `golden/`：

| 文件 | 内容 |
|---|---|
| `frames.json` | 12 条帧编码向量（十六进制） |
| `kcp.json` | 4 条 KCP 段向量 |
| `constants.json` | 全部协议常量 |

---

## 交叉验证结果（本轮实跑）

### KCP 常量：四版完全一致

| 常量 | Node 基准 | Go | Rust | Java |
|---|---:|---:|---:|---:|
| IKCP_OVERHEAD | 24 | 24 | 24 | 24 |
| IKCP_MTU_DEF | 1400 | 1400 | 1400 | 1400 |
| IKCP_WND_SND | 32 | 32 | 32 | 32 |
| IKCP_WND_RCV | 128 | 128 | 128 | 128 |
| IKCP_RTO_MIN | 30 | 30 | 30 | 30 |
| IKCP_RTO_DEF | 200 | 200 | 200 | 200 |
| IKCP_INTERVAL | 100 | 100 | 100 | 100 |
| IKCP_FAST_ACK_LIMIT | 3 | 3 | 3 | 3 |
| IKCP_MAX_FRG | 255 | 255 | 255 | 255 |
| IKCP_DEAD_LINK | 20 | 20 | 20 | 20 |
| CMD_PUSH / ACK / WASK / WINS | 81/82/83/84 | 同 | 同 | 同 |

### 帧编码：三语言独立实现相互印证

```
Node 生成 golden 向量
      ↓
Python 独立复刻（zlib.crc32）── 12/12 逐字节一致 ✓
      ↓
Rust 硬编码向量 ── 3/3 一致 ✓
```

CRC32 用 Node `zlib.crc32` 与 Python `zlib.crc32` 双向校验，
并用标准值 `crc32("123456789") = 0xCBF43926` 锚定。

---

## 已注入三版的 golden 测试

| 版本 | 文件 | 用例数 |
|---|---|---|
| Go | `internal/mpcommon/golden_test.go` | 12 |
| Rust | `crates/mp-common/src/golden.rs` | 12 |
| Java | `mp-common/src/test/.../GoldenVectorTest.java` | 12 |

三版编译后跑测试即可自证与基准一致。**任何一条失败都说明该版实现有 bug。**

---

## 目录

```
reference-impl/
├── src/
│   ├── frame.js      # 帧编解码（黄金实现）
│   ├── kcp.js        # KCP ARQ 协议
│   ├── constants.js  # KCP 常量
│   ├── server.js     # 基准服务端（TCP/UDP/CUSTOM/KCP）
│   ├── client.js     # 基准客户端
│   ├── test.js       # 单元测试（23 项）
│   ├── e2e.js        # 端到端测试（15 项）
│   └── golden.js     # golden 向量生成
├── golden/           # 生成的向量
└── package.json
```

---

## 环境要求

- Node.js **18+**（实测 v20.19.5）
- 零第三方依赖（仅用 Node 标准库）

---

## 已知限制

- **不含 QUIC**：需 TLS 与外部库，与「零依赖」目标冲突
- **无共识层**：单节点内存状态机，恒为 Leader。
  本实现只验证**协议与传输层**，不验证 Raft 正确性
- KCP 服务端会话无超时清理（演示用途，长跑需自行添加）
