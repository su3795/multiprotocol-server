/**
 * 生成 golden 向量 —— 三版（Java / Go / Rust）编译后可直接比对
 *
 * 输出：
 *   golden/frames.json   帧编码向量
 *   golden/kcp.json      KCP 段编码向量
 *   golden/constants.json 协议常量
 *
 * 用途：三版编译出来后，用相同输入编码，与本文件逐字节比对。
 * 任何不一致都说明该版实现有 bug。
 */

import fs from 'node:fs';
import path from 'node:path';
import {
  MAGIC, HEADER_SIZE, CRC32_SIZE, VERSION,
  CMD_PUT, CMD_GET, CMD_ROUTE_SET, CMD_ROUTE_GET, CMD_PING, CMD_STATS,
  CODE_OK, CODE_NOT_LEADER, CODE_BAD_REQUEST, CODE_INTERNAL,
  FLAG_NEED_RESPONSE, FLAG_COMPRESSED, FLAG_ENCRYPTED,
  encode, crc32, cmdName, formatResponse,
} from './frame.js';
import { Kcp, IKCP_OVERHEAD } from './kcp.js';

const outDir = path.join(process.cwd(), 'golden');
fs.mkdirSync(outDir, { recursive: true });

// ---------------- 1. 帧向量 ----------------

const frameCases = [
  { name: 'empty_ping', cmd: CMD_PING, seq: 1, payload: '' },
  { name: 'ping_hello', cmd: CMD_PING, seq: 2, payload: 'hello' },
  { name: 'put_kv', cmd: CMD_PUT, seq: 3, payload: 'user:1=alice' },
  { name: 'get_key', cmd: CMD_GET, seq: 4, payload: 'user:1' },
  { name: 'route_set', cmd: CMD_ROUTE_SET, seq: 5, payload: '7=node-3' },
  { name: 'route_get', cmd: CMD_ROUTE_GET, seq: 6, payload: '7' },
  { name: 'stats', cmd: CMD_STATS, seq: 7, payload: '' },
  { name: 'utf8_chinese', cmd: CMD_PUT, seq: 8, payload: '名字=张三' },
  { name: 'large_seq', cmd: CMD_GET, seq: 9007199254740991, payload: 'k' },
  { name: 'binary_payload', cmd: CMD_PUT, seq: 9, payload: 'a\u0000b\u00ffc' },
  { name: 'flag_compressed', cmd: CMD_PING, seq: 10, payload: 'x', flags: FLAG_COMPRESSED },
  { name: 'flag_all', cmd: CMD_PING, seq: 11, payload: 'y',
    flags: FLAG_NEED_RESPONSE | FLAG_COMPRESSED | FLAG_ENCRYPTED },
];

const frames = frameCases.map((c) => {
  const f = {
    version: VERSION,
    flags: c.flags ?? FLAG_NEED_RESPONSE,
    cmd: c.cmd,
    seq: c.seq,
    payload: Buffer.from(c.payload, 'utf8'),
  };
  const bytes = encode(f);
  return {
    name: c.name,
    input: { version: f.version, flags: f.flags, cmd: f.cmd, cmdName: cmdName(c.cmd),
             seq: f.seq, payload: c.payload },
    totalLength: bytes.length,
    hex: bytes.toString('hex').toUpperCase(),
  };
});

// ---------------- 2. KCP 段向量 ----------------

const kcp = new Kcp(0x11223344);
const segSamples = [];

// 用真实 send + update 产生 PUSH 段
kcp.send(Buffer.from('hello kcp'));
const pushOut = kcp.update(0);
segSamples.push({
  name: 'push_conv_11223344',
  desc: 'conv=0x11223344 发送 "hello kcp"（单分片）',
  totalLength: pushOut.length,
  hex: pushOut.toString('hex').toUpperCase(),
});

// 大消息产生多分片
const kcp2 = new Kcp(0xaabbccdd);
const big = Buffer.alloc(3000);
for (let i = 0; i < big.length; i++) big[i] = i % 251;
kcp2.send(big);
const multiOut = kcp2.update(0);
segSamples.push({
  name: 'push_multi_fragment',
  desc: 'conv=0xAABBCCDD 发送 3000 字节（3 个分片）',
  totalLength: multiOut.length,
  hex: multiOut.subarray(0, 80).toString('hex').toUpperCase() + '...(截断)',
});

// ACK 段
const kcp3 = new Kcp(0x1);
kcp3.ackList.push([42, 1000]);
const ackOut = kcp3.flush();
segSamples.push({
  name: 'ack_sn42_ts1000',
  desc: 'ACK 段：sn=42 ts=1000',
  totalLength: ackOut.length,
  hex: ackOut.toString('hex').toUpperCase(),
});

// WASK 段
const kcp4 = new Kcp(0x2);
kcp4.probeNeedSend = 1;
const waskOut = kcp4.flush();
segSamples.push({
  name: 'wask',
  desc: 'WASK 窗口探测段',
  totalLength: waskOut.length,
  hex: waskOut.toString('hex').toUpperCase(),
});

// ---------------- 3. 常量 ----------------

const constants = {
  frame: {
    MAGIC: `0x${MAGIC.toString(16).toUpperCase()}`,
    HEADER_SIZE, CRC32_SIZE, VERSION, MAX_PAYLOAD: 1 << 20,
    FLAG_NEED_RESPONSE, FLAG_COMPRESSED, FLAG_ENCRYPTED,
    CMD_PUT, CMD_GET, CMD_ROUTE_SET, CMD_ROUTE_GET, CMD_PING, CMD_STATS,
    CODE_OK, CODE_NOT_LEADER, CODE_BAD_REQUEST, CODE_INTERNAL,
  },
  kcp: {
    IKCP_CMD_PUSH: 81, IKCP_CMD_ACK: 82, IKCP_CMD_WASK: 83, IKCP_CMD_WINS: 84,
    IKCP_OVERHEAD: 24, IKCP_MTU_DEF: 1400, IKCP_WND_SND: 32, IKCP_WND_RCV: 128,
    IKCP_RTO_MIN: 30, IKCP_RTO_DEF: 200, IKCP_INTERVAL: 100,
    IKCP_DEAD_LINK: 20, IKCP_FAST_ACK_LIMIT: 3, IKCP_MAX_FRG: 255,
  },
  crc32: {
    algorithm: 'IEEE 802.3 (反射多项式 0xEDB88320)',
    covers: '[offset 2, 20+payloadLen) —— 不含 magic 与 crc32 本身',
    standardVector: { input: '123456789', expected: '0xCBF43926' },
    endianness: '全部整数字段为大端序（KCP 段为小端序）',
  },
};

// ---------------- 写出 ----------------

fs.writeFileSync(path.join(outDir, 'frames.json'), JSON.stringify({
  description: '帧编码 golden 向量 —— Java/Go/Rust 三版应产生完全相同的 hex',
  generatedBy: 'reference-impl/src/golden.js (Node.js)',
  count: frames.length,
  frames,
}, null, 2));

fs.writeFileSync(path.join(outDir, 'kcp.json'), JSON.stringify({
  description: 'KCP 段编码 golden 向量',
  generatedBy: 'reference-impl/src/golden.js (Node.js)',
  count: segSamples.length,
  segments: segSamples,
}, null, 2));

fs.writeFileSync(path.join(outDir, 'constants.json'), JSON.stringify({
  description: '协议常量 —— 四版必须一致',
  ...constants,
}, null, 2));

console.log(`已生成 golden 向量到 ${outDir}/`);
console.log(`  frames.json    ${frames.length} 条`);
console.log(`  kcp.json       ${segSamples.length} 条`);
console.log(`  constants.json`);
console.log('\n样例（put_kv）:');
console.log(' ', frames.find((f) => f.name === 'put_kv').hex);
console.log('\n样例（KCP push）:');
console.log(' ', segSamples[0].hex);
