/** KCP 协议常量（与 Java / Go / Rust 三版必须一致） */

/** 推送数据 */
export const IKCP_CMD_PUSH = 81;
/** 确认 */
export const IKCP_CMD_ACK = 82;
/** 窗口探测询问 */
export const IKCP_CMD_WASK = 83;
/** 窗口大小告知 */
export const IKCP_CMD_WINS = 84;

/** 单段头部长度: conv4 + cmd1 + frg1 + wnd2 + ts4 + sn4 + una4 + len4 */
export const IKCP_OVERHEAD = 24;

export const IKCP_MTU_DEF = 1400;
export const IKCP_WND_SND = 32;
export const IKCP_WND_RCV = 128;
export const IKCP_RTO_MIN = 30;
export const IKCP_RTO_DEF = 200;
export const IKCP_INTERVAL = 100;
export const IKCP_DEAD_LINK = 20;
export const IKCP_FAST_ACK_LIMIT = 3;
export const IKCP_MAX_FRG = 255;
