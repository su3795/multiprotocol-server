/**
 * KCP 协议参考实现（Node.js）
 *
 * 与 Java KcpControl / Go KCP / Rust Kcp 线格式与算法完全一致。
 * 本实现的价值：用 Python 复刻之外，再加一个真实运行的独立实现，
 * 三方交叉验证可大幅提高对 KCP 正确性的信心。
 */

import {
  IKCP_OVERHEAD, IKCP_CMD_PUSH, IKCP_CMD_ACK, IKCP_CMD_WASK, IKCP_CMD_WINS,
} from './constants.js';

export {
  IKCP_CMD_PUSH, IKCP_CMD_ACK, IKCP_CMD_WASK, IKCP_CMD_WINS,
  IKCP_OVERHEAD, IKCP_MTU_DEF, IKCP_WND_SND, IKCP_WND_RCV,
  IKCP_RTO_MIN, IKCP_RTO_DEF, IKCP_INTERVAL, IKCP_DEAD_LINK,
  IKCP_FAST_ACK_LIMIT, IKCP_MAX_FRG,
} from './constants.js';

/** 32 位无符号加法 */
const u32 = (v) => v >>> 0;

/**
 * 有序时间戳差值（正确处理 32 位回绕）
 * @returns {number} 正数表示 later 晚于 earlier
 */
export function itimediff(later, earlier) {
  return u32(later - earlier) | 0;
}

/** KCP 控制块 */
export class Kcp {
  /**
   * @param {number} conv 会话标识
   * @param {number} mtu
   */
  constructor(conv, mtu = 1400) {
    this.conv = conv >>> 0;
    this.mtu = mtu;
    this.mss = mtu - IKCP_OVERHEAD;

    this.sndUna = 0;
    this.sndNxt = 0;
    this.rcvNxt = 0;

    this.rto = 200;
    this.minRto = 30;
    this.srtt = 0;
    this.rttval = 0;

    this.sndWnd = 32;
    this.rcvWnd = 128;
    this.rmtWnd = 128;
    this.cwnd = 0;

    this.current = 0;
    this.interval = 100;
    this.tsFlush = 0;

    this.sndBuf = [];
    this.rcvBuf = [];
    this.sndQueue = [];
    this.rcvQueue = [];
    this.ackList = [];

    this.probeNeedSend = 0;
    this.probeWait = 0;
    this.deadLink = 20;
    this.state = 0;
    this.fastResend = 3;
    this.noDelay = 1;
  }

  get isClosed() { return this.state !== 0; }

  /** 剩余可通告的接收窗口 */
  wndAvail() {
    const a = this.rcvWnd - this.rcvQueue.length;
    return a < 0 ? 0 : a > 65535 ? 65535 : a;
  }

  // ---------------- 接收侧 ----------------

  /**
   * 处理收到的一个 UDP 数据报（可能含多个段）
   * @param {Buffer} data
   */
  input(data) {
    if (this.state !== 0) throw new Error('KCP 连接已关闭');
    const oldUna = this.sndUna;
    let offset = 0;

    while (data.length - offset >= IKCP_OVERHEAD) {
      const conv = data.readUInt32LE(offset + 0);
      if (conv !== this.conv) throw new Error(`KCP conv 不匹配: ${conv} != ${this.conv}`);
      const cmd = data.readUInt8(offset + 4);
      const frg = data.readUInt8(offset + 5);
      const wnd = data.readUInt16LE(offset + 6);
      const ts = data.readUInt32LE(offset + 8);
      const sn = data.readUInt32LE(offset + 12);
      const una = data.readUInt32LE(offset + 16);
      const len = data.readUInt32LE(offset + 20);
      offset += IKCP_OVERHEAD;

      const payload = Buffer.alloc(len);
      data.copy(payload, 0, offset, offset + len);
      offset += len;

      this.rmtWnd = wnd;
      this.parseUna(una);

      if (cmd === IKCP_CMD_PUSH) {
        // 收到数据：先记录待 ACK，再尝试入接收窗口
        if (itimediff(sn, u32(this.rcvNxt + this.rcvWnd)) < 0) {
          this.ackList.push([sn, ts]);
        }
        if (itimediff(sn, this.rcvNxt) >= 0) {
          const dup = this.rcvBuf.some((s) => s.sn === sn);
          if (!dup) {
            const seg = { sn, frg, ts, data: payload };
            // 按 sn 升序插入，保持有序
            let pos = this.rcvBuf.length;
            for (let i = 0; i < this.rcvBuf.length; i++) {
              if (itimediff(sn, this.rcvBuf[i].sn) < 0) { pos = i; break; }
            }
            this.rcvBuf.splice(pos, 0, seg);
          }
        }
      } else if (cmd === IKCP_CMD_ACK) {
        // 收到 ACK：移除对应段，更新 RTT
        if (itimediff(sn, this.sndUna) < 0 || itimediff(sn, this.sndNxt) >= 0) continue;
        const i = this.sndBuf.findIndex((s) => s.sn === sn);
        if (i >= 0) this.sndBuf.splice(i, 1);
        const rtt = itimediff(this.current, ts);
        this.updateRtt(rtt < 0 ? 0 : rtt);
        this.shrinkBuf();
      } else if (cmd === IKCP_CMD_WASK) {
        this.probeNeedSend = 1;
      } else if (cmd === IKCP_CMD_WINS) {
        this.rmtWnd = wnd;
      } else {
        throw new Error(`KCP 未知命令: ${cmd}`);
      }

      this.moveRcvBuf();
    }

    if (itimediff(this.sndUna, oldUna) > 0 && this.cwnd < this.rmtWnd) this.cwnd++;
    this.tsFlush = this.current;
  }

  parseUna(una) {
    this.sndBuf = this.sndBuf.filter((s) => itimediff(s.sn, una) >= 0);
    this.sndUna = una;
  }

  shrinkBuf() {
    this.sndUna = this.sndBuf.length > 0 ? this.sndBuf[0].sn : this.sndNxt;
  }

  updateRtt(rtt) {
    if (this.srtt === 0) {
      this.srtt = rtt;
      this.rttval = Math.floor(rtt / 2);
    } else {
      const delta = rtt > this.srtt ? rtt - this.srtt : this.srtt - rtt;
      this.rttval = Math.floor((3 * this.rttval + delta) / 4);
      this.srtt = Math.floor((7 * this.srtt + rtt) / 8);
    }
    let rto = this.srtt + Math.max(this.interval, 4 * this.rttval);
    if (rto < this.minRto) rto = this.minRto;
    this.rto = rto;
  }

  moveRcvBuf() {
    while (
      this.rcvBuf.length > 0 &&
      this.rcvBuf[0].sn === this.rcvNxt &&
      this.rcvQueue.length < this.rcvWnd
    ) {
      this.rcvQueue.push(this.rcvBuf.shift());
      this.rcvNxt = u32(this.rcvNxt + 1);
    }
  }

  /** 取出一条完整消息；null 表示暂无完整消息 */
  recv() {
    if (this.state !== 0 || this.rcvQueue.length === 0) return null;
    let count = 0;
    let found = false;
    for (const s of this.rcvQueue) {
      count++;
      if (s.frg === 0) { found = true; break; }
    }
    if (!found) return null;

    const parts = [];
    for (let i = 0; i < count; i++) parts.push(this.rcvQueue[i].data);
    this.rcvQueue.splice(0, count);
    return Buffer.concat(parts);
  }

  // ---------------- 发送侧 ----------------

  send(data) {
    if (this.state !== 0) throw new Error('KCP 连接已关闭');
    const mss = this.mss;
    let count = data.length === 0 ? 1 : Math.ceil(data.length / mss);
    if (count === 0) count = 1;
    if (count > 255) throw new Error(`KCP 消息过大，分片数 ${count} > 255`);

    let offset = 0;
    for (let i = 0; i < count; i++) {
      const size = Math.min(mss, data.length - offset);
      const chunk = Buffer.alloc(size);
      data.copy(chunk, 0, offset, offset + size);
      offset += size;
      this.sndQueue.push({ frg: count - 1 - i, data: chunk });
    }
  }

  /** @returns {Buffer} 待发送字节（可能为空） */
  flush() {
    if (this.state !== 0) return Buffer.alloc(0);
    const cur = this.current;
    const chunks = [];

    // 1. ACK
    for (const [sn, ts] of this.ackList) {
      chunks.push(this.encodeSeg(IKCP_CMD_ACK, 0, this.wndAvail(), ts, sn, this.rcvNxt, Buffer.alloc(0)));
    }
    this.ackList.length = 0;

    // 2. 窗口探测
    if (this.rmtWnd === 0) {
      if (this.probeWait === 0) { this.probeWait = this.interval; this.probeNeedSend = 1; }
      else this.probeWait--;
    } else {
      this.probeWait = 0;
    }
    if (this.probeNeedSend === 1) {
      chunks.push(this.encodeSeg(IKCP_CMD_WASK, 0, this.wndAvail(), 0, 0, this.rcvNxt, Buffer.alloc(0)));
      this.probeNeedSend = 0;
    }

    // 3. 可用窗口
    let cw = u32(this.sndUna + this.cwnd);
    if (this.cwnd === 0) cw = u32(this.sndUna + 1);
    if (this.rmtWnd > 0 && itimediff(u32(this.sndUna + this.rmtWnd), cw) < 0) {
      cw = u32(this.sndUna + this.rmtWnd);
    }

    // 4. sndQueue → sndBuf
    while (this.sndQueue.length > 0) {
      if (itimediff(this.sndNxt, cw) >= 0) break;
      const seg = this.sndQueue.shift();
      seg.conv = this.conv;
      seg.cmd = IKCP_CMD_PUSH;
      seg.wnd = this.wndAvail();
      seg.ts = cur;
      seg.sn = this.sndNxt;
      this.sndNxt = u32(this.sndNxt + 1);
      seg.una = this.rcvNxt;
      seg.rto = this.rto;
      seg.resendts = u32(cur + this.rto);
      seg.fastack = 0;
      seg.xmit = 0;
      this.sndBuf.push(seg);
    }

    // 5. 发送
    for (const seg of this.sndBuf) {
      let need = false;
      if (seg.xmit === 0) {
        need = true;
        seg.rto = this.rto;
        seg.resendts = u32(cur + this.rto);
      } else if (itimediff(cur, seg.resendts) >= 0) {
        need = true;
        seg.rto = Math.min(60000, seg.rto + Math.floor(seg.rto / 2));
        seg.resendts = u32(cur + seg.rto);
      } else if (this.fastResend > 0 && seg.fastack >= this.fastResend) {
        need = true;
        seg.fastack = 0;
        seg.resendts = u32(cur + seg.rto);
      }
      if (need) {
        seg.ts = cur;
        seg.wnd = this.wndAvail();
        seg.una = this.rcvNxt;
        seg.xmit++;
        if (this.deadLink > 0 && seg.xmit >= this.deadLink) this.state = 1;
        chunks.push(this.encodeSeg(IKCP_CMD_PUSH, seg.frg, seg.wnd, seg.ts, seg.sn, seg.una, seg.data));
      }
    }

    return chunks.length > 0 ? Buffer.concat(chunks) : Buffer.alloc(0);
  }

  encodeSeg(cmd, frg, wnd, ts, sn, una, data) {
    const b = Buffer.alloc(IKCP_OVERHEAD + data.length);
    b.writeUInt32LE(this.conv >>> 0, 0);
    b.writeUInt8(cmd, 4);
    b.writeUInt8(frg, 5);
    b.writeUInt16LE(wnd, 6);
    b.writeUInt32LE(ts >>> 0, 8);
    b.writeUInt32LE(sn >>> 0, 12);
    b.writeUInt32LE(una >>> 0, 16);
    b.writeUInt32LE(data.length, 20);
    data.copy(b, IKCP_OVERHEAD);
    return b;
  }

  /** 驱动时钟；返回待发送字节 */
  update(currentMs) {
    this.current = u32(currentMs);
    if (this.tsFlush === 0) this.tsFlush = this.current;
    if (itimediff(this.current, this.tsFlush) >= 0) {
      this.tsFlush = u32(this.current + this.interval);
      return this.flush();
    }
    return Buffer.alloc(0);
  }
}
