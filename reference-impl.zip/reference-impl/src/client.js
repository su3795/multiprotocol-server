/**
 * 参考客户端（Node.js）
 *
 * 用法：
 *   node src/client.js --proto tcp  --port 9101
 *   node src/client.js --proto udp  --port 9201
 *   node src/client.js --proto kcp  --port 9401
 *   node src/client.js --proto custom --port 9301
 *
 * 可用于连接参考服务端，也可连接 Java / Go / Rust 三版编译出的服务端，
 * 以此验证它们的实现是否与本基准一致。
 */

import net from 'node:net';
import dgram from 'node:dgram';
import {
  HEADER_SIZE, CMD_PUT, CMD_GET, CMD_ROUTE_SET, CMD_ROUTE_GET,
  CMD_PING, CMD_STATS, FLAG_NEED_RESPONSE,
  encode, tryDecode, TooShortError, cmdName,
} from './frame.js';
import { Kcp } from './kcp.js';

function parseArgs() {
  const a = process.argv.slice(2);
  const cfg = { host: '127.0.0.1', port: 9101, proto: 'tcp' };
  for (let i = 0; i < a.length; i++) {
    switch (a[i]) {
      case '--host': cfg.host = a[++i]; break;
      case '--port': cfg.port = +a[++i]; break;
      case '--proto': cfg.proto = a[++i].toLowerCase(); break;
      default: break;
    }
  }
  return cfg;
}

const CASES = [
  [CMD_PING, 'hello'],
  [CMD_PUT, 'user:1=alice'],
  [CMD_PUT, 'user:2=bob'],
  [CMD_GET, 'user:1'],
  [CMD_ROUTE_SET, '7=node-3'],
  [CMD_ROUTE_GET, '7'],
  [CMD_STATS, ''],
];

let seq = 0;
const mkFrame = (cmd, payload) => ({
  version: 1,
  flags: FLAG_NEED_RESPONSE,
  cmd,
  seq: ++seq,
  payload: Buffer.from(payload, 'utf8'),
});

// ---------------- TCP ----------------

function runTcp(host, port) {
  return new Promise((resolve) => {
    const sock = net.connect(port, host, () => {
      let acc = Buffer.alloc(0);
      let i = 0;

      sock.on('data', (chunk) => {
        acc = Buffer.concat([acc, chunk]);
        let r;
        try {
          r = tryDecode(acc);
        } catch (e) {
          if (e instanceof TooShortError) return;
          console.error('解析失败:', e.message);
          return;
        }
        acc = acc.subarray(r.consumed);
        console.log(`${cmdName(r.frame.cmd).padEnd(10)} → ${r.frame.payload.toString()}`);

        if (++i < CASES.length) {
          sock.write(encode(mkFrame(CASES[i][0], CASES[i][1])));
        } else {
          sock.end();
          resolve();
        }
      });

      sock.write(encode(mkFrame(CASES[0][0], CASES[0][1])));
    });
    sock.on('error', (e) => { console.error('TCP 错误:', e.message); resolve(); });
  });
}

// ---------------- UDP / CUSTOM ----------------

function runUdp(host, port, label) {
  return new Promise((resolve) => {
    const sock = dgram.createSocket('udp4');
    let i = 0;

    sock.on('message', (msg) => {
      try {
        const { frame } = tryDecode(msg);
        console.log(`${cmdName(frame.cmd).padEnd(10)} → ${frame.payload.toString()}`);
      } catch (e) {
        console.error('解析失败:', e.message);
      }
      if (++i < CASES.length) {
        sock.send(encode(mkFrame(CASES[i][0], CASES[i][1])), port, host);
      } else {
        sock.close();
        resolve();
      }
    });

    sock.bind(0, () => {
      sock.send(encode(mkFrame(CASES[0][0], CASES[0][1])), port, host);
    });
  });
}

// ---------------- KCP ----------------

function runKcp(host, port) {
  return new Promise((resolve) => {
    const sock = dgram.createSocket('udp4');
    const conv = 0x11223344; // 与 Go / Rust 客户端示例一致
    const kcp = new Kcp(conv);
    const start = Date.now();

    // KCP 输出 → UDP
    kcp.outputQueue = [];
    const origFlush = kcp.flush.bind(kcp);
    kcp.flush = function () {
      const out = origFlush();
      if (out.length > 0) sock.send(out, port, host);
      return out;
    };

    let i = 0;
    let done = false;

    // 10ms 驱动
    const ticker = setInterval(() => {
      kcp.update(Date.now() - start);
    }, 10);

    sock.on('message', (msg) => {
      try {
        kcp.input(msg);
      } catch (e) {
        console.error('KCP input 失败:', e.message);
        return;
      }
      let m;
      while ((m = kcp.recv()) !== null) {
        try {
          const { frame } = tryDecode(m);
          console.log(`${cmdName(frame.cmd).padEnd(10)} → ${frame.payload.toString()}`);
        } catch (e) {
          console.error('帧解析失败:', e.message);
        }

        if (++i < CASES.length) {
          kcp.send(encode(mkFrame(CASES[i][0], CASES[i][1])));
          kcp.flush();
        } else if (!done) {
          done = true;
          clearInterval(ticker);
          sock.close();
          resolve();
        }
      }
    });

    sock.bind(0, () => {
      kcp.send(encode(mkFrame(CASES[0][0], CASES[0][1])));
      kcp.flush();
    });

    // 超时保护
    setTimeout(() => {
      if (!done) {
        done = true;
        clearInterval(ticker);
        console.error('KCP 超时（10s 未收到完整响应）');
        try { sock.close(); } catch { /* ignore */ }
        resolve();
      }
    }, 10000);
  });
}

// ---------------- main ----------------

const cfg = parseArgs();
console.log(`>>> ${cfg.proto.toUpperCase()} 客户端 → ${cfg.host}:${cfg.port}\n`);

const runner = {
  tcp: () => runTcp(cfg.host, cfg.port),
  udp: () => runUdp(cfg.host, cfg.port, 'UDP'),
  custom: () => runUdp(cfg.host, cfg.port, 'CUSTOM'),
  kcp: () => runKcp(cfg.host, cfg.port),
}[cfg.proto];

if (!runner) {
  console.error(`未知协议: ${cfg.proto}（可选 tcp/udp/custom/kcp）`);
  process.exit(1);
}

runner().then(() => console.log('\n>>> 完成'));
