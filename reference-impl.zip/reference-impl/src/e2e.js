/**
 * 端到端测试 —— 真实 loopback 网络通信（非 mock）
 *
 * 在同一进程内启动服务端与客户端，通过真实 TCP / UDP / KCP socket 通信。
 * 这是整个交付中**唯一真实跑通网络链路**的验证。
 *
 * 价值：证明这套协议设计（帧格式 + KCP ARQ + 状态机语义）是自洽可运行的。
 * Java / Go / Rust 三版编译出来后，可用同样的用例验证其实现。
 *
 * 用法：node src/e2e.js
 */

import net from 'node:net';
import dgram from 'node:dgram';
import { strict as assert } from 'node:assert';
import {
  CMD_PUT, CMD_GET, CMD_ROUTE_SET, CMD_ROUTE_GET, CMD_PING, CMD_STATS,
  FLAG_NEED_RESPONSE, encode, tryDecode, TooShortError, cmdName,
} from './frame.js';
import { Kcp } from './kcp.js';
import { startTcp, startDatagram, startKcp } from './server.js';

let passed = 0, failed = 0;
function check(name, cond, extra = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name} ${extra}`); }
}

let seq = 0;
const mk = (cmd, payload) => ({
  version: 1, flags: FLAG_NEED_RESPONSE, cmd, seq: ++seq,
  payload: Buffer.from(payload, 'utf8'),
});

// ---------------- TCP 端到端 ----------------

function testTcp(port) {
  return new Promise((resolve) => {
    const server = startTcp(port);
    const cases = [
      [CMD_PING, 'hello', 'PONG'],
      [CMD_PUT, 'user:1=alice', 'stored user:1'],
      [CMD_GET, 'user:1', 'alice'],
      [CMD_ROUTE_SET, '7=node-3', 'route 7 -> node-3'],
      [CMD_ROUTE_GET, '7', 'node-3'],
    ];
    let i = 0;
    const sock = net.connect(port, '127.0.0.1', () => {
      sock.write(encode(mk(cases[0][0], cases[0][1])));
    });
    let acc = Buffer.alloc(0);

    sock.on('data', (chunk) => {
      acc = Buffer.concat([acc, chunk]);
      let r;
      try { r = tryDecode(acc); }
      catch (e) { if (e instanceof TooShortError) return; throw e; }
      acc = acc.subarray(r.consumed);

      const body = r.frame.payload.toString();
      const [cmd, payload, expect] = cases[i];
      console.log(`  [TCP] ${cmdName(cmd).padEnd(10)} → ${body}`);
      check(`TCP ${cmdName(cmd)} 响应正确`, body === `OK|${expect}`,
        `期望 "OK|${expect}" 实际 "${body}"`);

      if (++i < cases.length) {
        sock.write(encode(mk(cases[i][0], cases[i][1])));
      } else {
        sock.end();
        server.close();
        resolve();
      }
    });
    sock.on('error', (e) => { check('TCP 无错误', false, e.message); server.close(); resolve(); });
  });
}

// ---------------- UDP / CUSTOM 端到端 ----------------

function testDatagram(port, label) {
  return new Promise((resolve) => {
    const server = startDatagram(port, label);
    const cases = [
      [CMD_PING, 'hi', 'PONG'],
      [CMD_PUT, 'k=v', 'stored k'],
      [CMD_GET, 'k', 'v'],
    ];
    let i = 0;
    const sock = dgram.createSocket('udp4');

    sock.on('message', (msg) => {
      const { frame } = tryDecode(msg);
      const body = frame.payload.toString();
      const [cmd, payload, expect] = cases[i];
      console.log(`  [${label}] ${cmdName(cmd).padEnd(10)} → ${body}`);
      check(`${label} ${cmdName(cmd)} 响应正确`, body === `OK|${expect}`,
        `期望 "OK|${expect}" 实际 "${body}"`);

      if (++i < cases.length) sock.send(encode(mk(cases[i][0], cases[i][1])), port, '127.0.0.1');
      else { sock.close(); server.close(); resolve(); }
    });

    sock.bind(0, () => sock.send(encode(mk(cases[0][0], cases[0][1])), port, '127.0.0.1'));
  });
}

// ---------------- KCP 端到端（真实 UDP + ARQ 重传）----------------

function testKcp(port) {
  return new Promise((resolve) => {
    const srv = startKcp(port);
    const conv = 0x11223344;
    const cases = [
      [CMD_PING, 'hello', 'PONG'],
      [CMD_PUT, 'user:1=alice', 'stored user:1'],
      [CMD_GET, 'user:1', 'alice'],
      [CMD_STATS, '', null], // 仅校验前缀
    ];

    const sock = dgram.createSocket('udp4');
    const kcp = new Kcp(conv);
    const start = Date.now();

    // KCP 输出 → UDP
    const origFlush = kcp.flush.bind(kcp);
    kcp.flush = () => {
      const out = origFlush();
      if (out.length > 0) sock.send(out, port, '127.0.0.1');
      return out;
    };

    let i = 0, done = false;
    const ticker = setInterval(() => kcp.update(Date.now() - start), 10);

    sock.on('message', (msg) => {
      try { kcp.input(msg); } catch { return; }
      let m;
      while ((m = kcp.recv()) !== null) {
        const { frame } = tryDecode(m);
        const body = frame.payload.toString();
        const [cmd, , expect] = cases[i];
        console.log(`  [KCP] ${cmdName(cmd).padEnd(10)} → ${body}`);
        if (expect !== null) {
          check(`KCP ${cmdName(cmd)} 响应正确`, body === `OK|${expect}`,
            `期望 "OK|${expect}" 实际 "${body}"`);
        } else {
          check(`KCP ${cmdName(cmd)} 有响应`, body.startsWith('OK|'), `实际 "${body}"`);
        }

        if (++i < cases.length) {
          kcp.send(encode(mk(cases[i][0], cases[i][1])));
          kcp.flush();
        } else if (!done) {
          done = true;
          clearInterval(ticker);
          sock.close();
          clearInterval(srv.ticker);
          srv.sock.close();
          resolve();
        }
      }
    });

    sock.bind(0, () => {
      kcp.send(encode(mk(cases[0][0], cases[0][1])));
      kcp.flush();
    });

    setTimeout(() => {
      if (!done) {
        done = true;
        clearInterval(ticker);
        check('KCP 端到端未完成（超时）', false);
        try { sock.close(); } catch { /* ignore */ }
        clearInterval(srv.ticker);
        try { srv.sock.close(); } catch { /* ignore */ }
        resolve();
      }
    }, 8000);
  });
}

// ---------------- main ----------------

console.log('\n========== 端到端测试（真实 loopback 网络）==========\n');

console.log('--- TCP ---');
await testTcp(19601);
console.log('\n--- UDP ---');
await testDatagram(19602, 'UDP');
console.log('\n--- CUSTOM ---');
await testDatagram(19603, 'CUSTOM');
console.log('\n--- KCP（含 ARQ 重传）---');
await testKcp(19604);

console.log(`\n${'='.repeat(50)}`);
console.log(`端到端结果: ${passed} 通过, ${failed} 失败`);
console.log('='.repeat(50));
process.exit(failed > 0 ? 1 : 0);
