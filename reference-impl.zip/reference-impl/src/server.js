/**
 * 参考服务端（Node.js）—— 可真实运行的多协议基准实现
 *
 * 支持的协议：TCP / UDP / KCP / CUSTOM
 * （QUIC 需 TLS 与外部库，此处不实现）
 *
 * 价值：
 *   1. 证明这套协议设计是自洽、可运行的
 *   2. Java / Go / Rust 三版编译出来后，可用本服务端做互通基准
 *   3. 也可作为客户端去连三版的服务端，验证它们的实现
 *
 * 用法：
 *   node src/server.js [--tcp 9101] [--udp 9201] [--custom 9301] [--kcp 9401]
 */

import net from 'node:net';
import dgram from 'node:dgram';
import {
  HEADER_SIZE, CMD_PUT, CMD_GET, CMD_ROUTE_SET, CMD_ROUTE_GET,
  CMD_PING, CMD_STATS, FLAG_NEED_RESPONSE, CODE_OK, CODE_BAD_REQUEST,
  encode, tryDecode, TooShortError, cmdName, formatResponse,
} from './frame.js';
import { Kcp, IKCP_OVERHEAD } from './kcp.js';

// ---------------- 参数 ----------------

function parseArgs() {
  const args = process.argv.slice(2);
  const cfg = { tcp: 9101, udp: 9201, custom: 9301, kcp: 9401 };
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--tcp': cfg.tcp = +args[++i]; break;
      case '--udp': cfg.udp = +args[++i]; break;
      case '--custom': cfg.custom = +args[++i]; break;
      case '--kcp': cfg.kcp = +args[++i]; break;
      default: break;
    }
  }
  return cfg;
}

// ---------------- 状态机（内存 KV + 路由表）----------------

export class StateMachine {
  constructor() {
    this.kv = new Map();
    this.routes = new Map();
    this.requests = 0;
    this.isLeader = true; // 单节点基准实现恒为 Leader
  }

  apply(cmd, payloadStr) {
    switch (cmd) {
      case CMD_PUT: {
        const idx = payloadStr.indexOf('=');
        if (idx < 0) return { code: CODE_BAD_REQUEST, body: 'PUT 格式应为 key=value' };
        const key = payloadStr.substring(0, idx);
        const val = payloadStr.substring(idx + 1);
        this.kv.set(key, val);
        return { code: CODE_OK, body: `stored ${key}` };
      }
      case CMD_GET: {
        const v = this.kv.get(payloadStr);
        return v === undefined
          ? { code: CODE_BAD_REQUEST, body: `not found: ${payloadStr}` }
          : { code: CODE_OK, body: v };
      }
      case CMD_ROUTE_SET: {
        const idx = payloadStr.indexOf('=');
        if (idx < 0) return { code: CODE_BAD_REQUEST, body: 'ROUTE_SET 格式应为 shard=node' };
        const shard = payloadStr.substring(0, idx);
        const node = payloadStr.substring(idx + 1);
        this.routes.set(shard, node);
        return { code: CODE_OK, body: `route ${shard} -> ${node}` };
      }
      case CMD_ROUTE_GET: {
        const v = this.routes.get(payloadStr);
        return v === undefined
          ? { code: CODE_BAD_REQUEST, body: `no route for ${payloadStr}` }
          : { code: CODE_OK, body: v };
      }
      case CMD_PING:
        return { code: CODE_OK, body: 'PONG' };
      case CMD_STATS:
        return {
          code: CODE_OK,
          body: `role=Leader kv=${this.kv.size} routes=${this.routes.size} requests=${this.requests}`,
        };
      default:
        return { code: CODE_BAD_REQUEST, body: `unknown cmd ${cmd}` };
    }
  }
}

const sm = new StateMachine();

/**
 * 处理一帧，返回响应帧
 * @param {object} frame
 * @param {string} proto
 */
export function processFrame(frame, proto) {
  sm.requests++;
  const payloadStr = frame.payload ? frame.payload.toString('utf8') : '';
  const { code, body } = sm.apply(frame.cmd, payloadStr);
  return {
    version: 1,
    flags: 0,
    cmd: frame.cmd,
    seq: frame.seq,
    payload: Buffer.from(formatResponse(code, body), 'utf8'),
  };
}

// ---------------- TCP ----------------

export function startTcp(port) {
  const server = net.createServer((sock) => {
    let acc = Buffer.alloc(0);
    sock.on('data', (chunk) => {
      acc = Buffer.concat([acc, chunk]);
      // TCP 是字节流，需循环切出所有完整帧（粘包/半包）
      for (;;) {
        let r;
        try {
          r = tryDecode(acc);
        } catch (e) {
          if (e instanceof TooShortError) break; // 半包，等下一轮
          console.error(`[TCP] 协议错误: ${e.message}`);
          sock.destroy();
          return;
        }
        acc = acc.subarray(r.consumed);
        if (r.frame.flags & FLAG_NEED_RESPONSE) {
          const resp = processFrame(r.frame, 'TCP');
          sock.write(encode(resp));
        }
      }
    });
    sock.on('error', () => {});
  });
  server.listen(port, () => console.log(`[TCP]    监听 0.0.0.0:${port}`));
  return server;
}

// ---------------- UDP / CUSTOM ----------------

export function startDatagram(port, label) {
  const sock = dgram.createSocket('udp4');
  sock.on('message', (msg, rinfo) => {
    try {
      const { frame } = tryDecode(msg);
      if (frame.flags & FLAG_NEED_RESPONSE) {
        const resp = processFrame(frame, label);
        sock.send(encode(resp), rinfo.port, rinfo.address);
      }
    } catch (e) {
      console.error(`[${label}] 解析失败: ${e.message}`);
    }
  });
  sock.bind(port, () => console.log(`[${label}] 监听 0.0.0.0:${port}`));
  return sock;
}

// ---------------- KCP ----------------

export function startKcp(port) {
  const sock = dgram.createSocket('udp4');
  /** @type {Map<string, {kcp: Kcp, start: number}>} */
  const sessions = new Map();

  // 10ms 驱动所有会话（KCP 内部 interval=100ms）
  const ticker = setInterval(() => {
    for (const [key, s] of sessions) {
      const out = s.kcp.update(Date.now() - s.start);
      if (out.length > 0) {
        const [addr, p] = key.split(':');
        sock.send(out, +p, addr);
      }
    }
  }, 10);

  sock.on('message', (msg, rinfo) => {
    const key = `${rinfo.address}:${rinfo.port}`;
    if (msg.length < IKCP_OVERHEAD) return;

    let s = sessions.get(key);
    if (!s) {
      const conv = msg.readUInt32LE(0);
      s = { kcp: new Kcp(conv), start: Date.now() };
      sessions.set(key, s);
      console.log(`[KCP]    会话建立 ${key} conv=0x${conv.toString(16)}`);
    }

    try {
      s.kcp.input(msg);
    } catch (e) {
      console.error(`[KCP] input 失败: ${e.message}`);
      return;
    }

    let m;
    while ((m = s.kcp.recv()) !== null) {
      try {
        const { frame } = tryDecode(m);
        if (frame.flags & FLAG_NEED_RESPONSE) {
          const resp = processFrame(frame, 'KCP');
          s.kcp.send(encode(resp));
        }
      } catch (e) {
        console.error(`[KCP] 帧解析失败: ${e.message}`);
      }
    }

    const pending = s.kcp.flush();
    if (pending.length > 0) sock.send(pending, rinfo.port, rinfo.address);
  });

  sock.bind(port, () => console.log(`[KCP]    监听 0.0.0.0:${port}`));
  return { sock, ticker };
}

// ---------------- main ----------------

// 仅在直接运行时启动（被 import 时不自动启动，便于端到端测试复用）
if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split('/').pop())) {
  const cfg = parseArgs();
  console.log('='.repeat(55));
  console.log('多协议集群服务器 · 参考实现（Node.js 基准）');
  console.log('='.repeat(55));
  const servers = [];
  servers.push(startTcp(cfg.tcp));
  servers.push(startDatagram(cfg.udp, 'UDP'));
  servers.push(startDatagram(cfg.custom, 'CUSTOM'));
  const kcpSrv = startKcp(cfg.kcp);

  console.log('-'.repeat(55));
  console.log(`就绪 | TCP=${cfg.tcp} UDP=${cfg.udp} CUSTOM=${cfg.custom} KCP=${cfg.kcp}`);
  console.log('-'.repeat(55));

  process.on('SIGINT', () => {
    console.log('\n正在关闭...');
    clearInterval(kcpSrv.ticker);
    for (const s of servers) { try { s.close(); } catch { /* ignore */ } }
    try { kcpSrv.sock.close(); } catch { /* ignore */ }
    process.exit(0);
  });
}
