/**
 * 统一帧格式 —— 黄金参考实现（Node.js）
 *
 * 帧结构（与 Java / Go / Rust 三版字节级一致）：
 *
 *   ┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
 *   │ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
 *   │ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
 *   └────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
 *                           头部固定 20B                      尾部 4B
 *
 * - magic 固定 0x4D50（"MP"），全部整数为**大端序**
 * - crc32 覆盖 [offset 2, 2+18+len)，即从 version 到 payload 结束
 *   （**不含** magic 与 crc32 本身）
 * - CRC32 采用标准 IEEE 802.3 多项式（与 Python zlib.crc32 一致）
 *
 * 本实现的价值：它是唯一能在无 Java/Go/Rust 工具链环境下**真实运行**的部分，
 * 可作为三版编译出来后的互通基准。
 */

// ---------------- 常量 ----------------

/** 帧起始标记 'M''P' */
export const MAGIC = 0x4d50;
/** 头部固定长度 */
export const HEADER_SIZE = 20;
/** 尾部校验长度 */
export const CRC32_SIZE = 4;
/** 当前协议版本 */
export const VERSION = 1;
/** 单帧 payload 上限 1MiB */
export const MAX_PAYLOAD = 1 << 20;

// 标志位
export const FLAG_NEED_RESPONSE = 0x01;
export const FLAG_COMPRESSED = 0x02;
export const FLAG_ENCRYPTED = 0x04;

// 命令字（与 Java io.mp.gateway.Cmd 一致）
export const CMD_PUT = 1;
export const CMD_GET = 2;
export const CMD_ROUTE_SET = 3;
export const CMD_ROUTE_GET = 4;
export const CMD_PING = 5;
export const CMD_STATS = 6;

// 响应码
export const CODE_OK = 0;
export const CODE_NOT_LEADER = 1;
export const CODE_BAD_REQUEST = 2;
export const CODE_INTERNAL = 3;

/** 协议类型 */
export const PROTOCOLS = ['TCP', 'UDP', 'QUIC', 'KCP', 'CUSTOM'];

/** 命令字 → 可读名 */
export function cmdName(cmd) {
  switch (cmd) {
    case CMD_PUT: return 'PUT';
    case CMD_GET: return 'GET';
    case CMD_ROUTE_SET: return 'ROUTE_SET';
    case CMD_ROUTE_GET: return 'ROUTE_GET';
    case CMD_PING: return 'PING';
    case CMD_STATS: return 'STATS';
    default: return `UNKNOWN(${cmd})`;
  }
}

// ---------------- CRC32（IEEE 802.3） ----------------

// 标准 CRC32 表：多项式 0xEDB88320（反射形式）
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

/**
 * 计算 CRC32（与 Python zlib.crc32、Go hash/crc32 IEEE 表一致）
 * @param {Buffer} buf
 * @returns {number} 无符号 32 位
 */
export function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

// ---------------- 帧编解码 ----------------

/**
 * 编码一帧
 * @param {object} f { version, flags, cmd, seq, payload }
 * @returns {Buffer}
 */
export function encode(f) {
  const payload = f.payload == null ? Buffer.alloc(0) : Buffer.from(f.payload);
  if (payload.length > MAX_PAYLOAD) {
    throw new Error(`payload 超限: ${payload.length} > ${MAX_PAYLOAD}`);
  }
  const total = HEADER_SIZE + payload.length + CRC32_SIZE;
  const b = Buffer.alloc(total);

  b.writeUInt16BE(MAGIC, 0);
  b.writeUInt8(f.version ?? VERSION, 2);
  b.writeUInt8(f.flags ?? 0, 3);
  b.writeInt32BE(f.cmd, 4);
  // seq 为 int64：Node 的 writeBigInt64BE 需要 BigInt
  b.writeBigInt64BE(BigInt(f.seq), 8);
  b.writeUInt32BE(payload.length, 16);
  payload.copy(b, HEADER_SIZE);

  // CRC 覆盖 [2, 2+18+len)
  const crc = crc32(b.subarray(2, HEADER_SIZE + payload.length));
  b.writeUInt32BE(crc, HEADER_SIZE + payload.length);
  return b;
}

/** 解码错误类型 */
export class DecodeError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'DecodeError';
  }
}

/** 数据不足（半包） */
export class TooShortError extends DecodeError {
  constructor(need, got) {
    super(`数据不足: 需要 ${need} 字节，实际 ${got}`);
    this.name = 'TooShortError';
  }
}

/**
 * 尝试从缓冲区解码一帧
 * @param {Buffer} buf
 * @returns {{ frame: object, consumed: number }}
 * @throws {TooShortError} 半包
 * @throws {DecodeError} magic 错 / CRC 错 / 长度非法
 */
export function tryDecode(buf) {
  if (buf.length < HEADER_SIZE) {
    throw new TooShortError(HEADER_SIZE, buf.length);
  }
  const magic = buf.readUInt16BE(0);
  if (magic !== MAGIC) {
    throw new DecodeError(`magic 不匹配: 期望 0x${MAGIC.toString(16)} 实际 0x${magic.toString(16)}`);
  }
  const length = buf.readUInt32BE(16);
  if (length > MAX_PAYLOAD) {
    throw new DecodeError(`length 非法: ${length} > ${MAX_PAYLOAD}`);
  }
  const total = HEADER_SIZE + length + CRC32_SIZE;
  if (buf.length < total) {
    throw new TooShortError(total, buf.length);
  }

  const payload = buf.subarray(HEADER_SIZE, HEADER_SIZE + length);
  const expectCrc = buf.readUInt32BE(HEADER_SIZE + length);
  const actualCrc = crc32(buf.subarray(2, HEADER_SIZE + length));
  if (expectCrc !== actualCrc) {
    throw new DecodeError(`CRC 不匹配: 期望 0x${expectCrc.toString(16)} 实际 0x${actualCrc.toString(16)}`);
  }

  return {
    frame: {
      version: buf.readUInt8(2),
      flags: buf.readUInt8(3),
      cmd: buf.readInt32BE(4),
      seq: Number(buf.readBigInt64BE(8)),
      payload: Buffer.from(payload), // 拷贝，避免引用原缓冲
    },
    consumed: total,
  };
}

/** 解码（要求 buf 恰好或至少含一帧） */
export function decode(buf) {
  return tryDecode(buf).frame;
}

// ---------------- 响应格式 ----------------

/**
 * 构造响应 payload：`OK|body` 或 `ERR|body`
 * @param {number} code 响应码
 * @param {string} body
 */
export function formatResponse(code, body) {
  const prefix = code === CODE_OK ? 'OK' : 'ERR';
  return body ? `${prefix}|${body}` : prefix;
}

/** 解析响应 payload */
export function parseResponse(payload) {
  const s = payload.toString('utf8');
  const idx = s.indexOf('|');
  if (idx < 0) return { ok: s === 'OK', body: '' };
  return { ok: s.substring(0, idx) === 'OK', body: s.substring(idx + 1) };
}
