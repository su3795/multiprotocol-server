# 跨语言帧测试向量

Java / Go / Rust 三版共用同一套帧格式，以下向量由 **Java 编码逻辑**生成，
用作另外两版的编解码基准。三版必须产生**完全相同**的字节序列。

## 帧结构

```
┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
│ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
│ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
└────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
                        头部固定 20B                      尾部 4B
```

- `magic` = `0x4D50`（"MP"），全部整数**大端序**
- `crc32` 覆盖 `[offset 2, 2+18+len)`：从 version 到 payload 结束，不含 magic 与 crc 自身

## 向量

| 用例 | cmd | seq | payload | 长度 | crc32 |
|---|---|---|---|---|---|
| PUT | 1 | 1 | `user:1=alice` | 36 | `0x9617BE24` |
| GET | 2 | 2 | `user:1` | 30 | `0x3CF8ACF8` |
| PING | 5 | 3 | `hello` | 29 | `0x51C9B09C` |
| STATS(空 payload) | 6 | 4 | - | 24 | `0x5A8ACBF2` |
| ROUTE_SET | 3 | 5 | `7=node-3` | 32 | `0x3A115965` |
| 大 seq | 1 | 0x0102030405060708 | `k=v` | 27 | `0xBDFC19D7` |

## 字节序列

**PUT seq=1 `user:1=alice`**
```
4D 50 01 01 00 00 00 01 00 00 00 00 00 00 00 01 00 00 00 0C
75 73 65 72 3A 31 3D 61 6C 69 63 65 96 17 BE 24
```

**GET seq=2 `user:1`**
```
4D 50 01 01 00 00 00 02 00 00 00 00 00 00 00 02 00 00 00 06
75 73 65 72 3A 31 3C F8 AC F8
```

**STATS seq=4（空 payload）**
```
4D 50 01 01 00 00 00 06 00 00 00 00 00 00 00 04 00 00 00 00
5A 8A CB F2
```

**ROUTE_SET seq=5 `7=node-3`**
```
4D 50 01 01 00 00 00 03 00 00 00 00 00 00 00 05 00 00 00 08
37 3D 6E 6F 64 65 2D 33 3A 11 59 65
```

**大 seq（验证 int64 大端）**
```
4D 50 01 01 00 00 00 01 01 02 03 04 05 06 07 08 00 00 00 03
6B 3D 76 BD FC 19 D7
```

这些向量已硬编码在三版各自的单元测试中：
- Java: `mp-common/src/test/java/io/mp/common/codec/FrameCodecTest.java`
- Go: `internal/mpcommon/frame_test.go`
- Rust: `crates/mp-common/src/frame.rs` 的 `mod tests`
