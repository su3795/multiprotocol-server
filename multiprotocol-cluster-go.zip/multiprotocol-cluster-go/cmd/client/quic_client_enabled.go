//go:build quic

package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"os"
	"time"

	"github.com/quic-go/quic-go"

	"mpc/internal/mpcommon"
)

// runQUIC 运行 QUIC 演示客户端（需 -tags quic 构建）。
//
// 注意：服务端使用自签证书，客户端需设置 InsecureSkipVerify。
func runQUIC(host string, port int) {
	addr := fmt.Sprintf("%s:%d", host, port)
	tlsConf := &tls.Config{
		InsecureSkipVerify: true, // 自签证书，仅供演示
		NextProtos:         []string{"mp"},
		MinVersion:         tls.VersionTLS13,
	}

	conn, err := quic.DialAddr(context.Background(), addr, tlsConf, &quic.Config{
		MaxIdleTimeout: 30 * time.Second,
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "QUIC 连接失败: %v\n", err)
		return
	}
	defer conn.CloseWithError(0, "bye")

	for _, c := range []struct {
		cmd     int32
		payload string
	}{
		{mpcommon.CmdPing, "hello"},
		{mpcommon.CmdPut, "user:1=alice"},
		{mpcommon.CmdGet, "user:1"},
		{mpcommon.CmdStats, ""},
	} {
		callQUIC(conn, c.cmd, c.payload)
	}
}

// callQUIC 在一条新的 QUIC 流上发一帧并读响应
func callQUIC(conn quic.Connection, cmd int32, payload string) {
	stream, err := conn.OpenStreamSync(context.Background())
	if err != nil {
		fmt.Printf("%-10s → 打开流失败: %v\n", mpcommon.CmdName(cmd), err)
		return
	}
	defer stream.Close()

	req := mpcommon.NewFrame(mpcommon.FlagNeedResponse, cmd, nextSeq(), []byte(payload))
	out, err := mpcommon.Encode(req)
	if err != nil {
		return
	}
	if _, err := stream.Write(out); err != nil {
		fmt.Printf("%-10s → 发送失败: %v\n", mpcommon.CmdName(cmd), err)
		return
	}

	// 先读头部，再按长度读余下部分
	stream.SetReadDeadline(time.Now().Add(5 * time.Second))
	head := make([]byte, mpcommon.HeaderSize)
	if _, err := readFull(stream, head); err != nil {
		fmt.Printf("%-10s → 读取失败: %v\n", mpcommon.CmdName(cmd), err)
		return
	}
	total := mpcommon.PeekFrameLength(head)
	rest := make([]byte, total-mpcommon.HeaderSize)
	if _, err := readFull(stream, rest); err != nil {
		fmt.Printf("%-10s → 读取失败: %v\n", mpcommon.CmdName(cmd), err)
		return
	}

	full := append(head, rest...)
	resp, err := mpcommon.Decode(full)
	if err != nil {
		fmt.Printf("%-10s → 解码失败: %v\n", mpcommon.CmdName(cmd), err)
		return
	}
	fmt.Printf("%-10s → %s\n", mpcommon.CmdName(cmd), resp.Payload)
}
