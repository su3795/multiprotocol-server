// Command mp-client 是演示客户端（对应 Java 版 DemoClient）。
//
// 用原生 net 包直接发帧，验证端到端链路。可与 Java / Rust 版服务端互通，
// 因为三者共用同一套帧格式与命令字。
//
// 用法：
//
//	go run ./cmd/client --proto tcp --port 9101
//	go run ./cmd/client --proto udp --port 9201
package main

import (
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"time"

	"mpc/internal/gateway"
	"mpc/internal/mpcommon"
)

var seq int64 = 1

func main() {
	var (
		proto = flag.String("proto", "tcp", "协议: tcp | udp")
		host  = flag.String("host", "127.0.0.1", "目标主机")
		port  = flag.Int("port", 9101, "目标端口")
	)
	flag.Parse()

	fmt.Printf("=== 演示客户端 · %s → %s:%d ===\n", *proto, *host, *port)

	switch *proto {
	case "udp":
		runUDP(*host, *port)
	case "kcp":
		runKCP(*host, *port)
	case "quic":
		runQUIC(*host, *port)
	default:
		runTCP(*host, *port)
	}
}

func nextSeq() int64 {
	s := seq
	seq++
	return s
}

func runTCP(host string, port int) {
	conn, err := net.Dial("tcp", fmt.Sprintf("%s:%d", host, port))
	if err != nil {
		fmt.Fprintf(os.Stderr, "连接失败: %v\n", err)
		os.Exit(1)
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	// 1. 心跳（不走共识，测纯接入层）
	callTCP(conn, mpcommon.CmdPing, "hello")
	// 2. 写 KV（走共识）
	callTCP(conn, mpcommon.CmdPut, "user:1=alice")
	callTCP(conn, mpcommon.CmdPut, "user:2=bob")
	// 3. 线性一致读
	callTCP(conn, mpcommon.CmdGet, "user:1")
	// 4. 设置分片路由
	callTCP(conn, mpcommon.CmdRouteSet, "7=node-3")
	callTCP(conn, mpcommon.CmdRouteGet, "7")
	// 5. 节点状态
	callTCP(conn, mpcommon.CmdStats, "")
}

func callTCP(conn net.Conn, cmd int32, payload string) {
	req := mpcommon.NewFrame(mpcommon.FlagNeedResponse, cmd, nextSeq(), []byte(payload))
	data, err := mpcommon.Encode(req)
	if err != nil {
		fmt.Println("编码失败:", err)
		return
	}
	if _, err := conn.Write(data); err != nil {
		fmt.Println("发送失败:", err)
		return
	}

	// 先读头部，再按长度读余下部分（处理半包）
	head := make([]byte, mpcommon.HeaderSize)
	if _, err := readFull(conn, head); err != nil {
		fmt.Println("读取失败:", err)
		return
	}
	total := mpcommon.PeekFrameLength(head)
	rest := make([]byte, total-mpcommon.HeaderSize)
	if _, err := readFull(conn, rest); err != nil {
		fmt.Println("读取失败:", err)
		return
	}

	full := append(head, rest...)
	resp, err := mpcommon.Decode(full)
	if err != nil {
		fmt.Println("解码失败:", err)
		return
	}
	fmt.Printf("%-10s → %s\n", mpcommon.CmdName(cmd), resp.Payload)
}

// readFull 读满 buf（兼容 net.Conn 与 QUIC stream 等任意 io.Reader）
func readFull(r io.Reader, buf []byte) (int, error) {
	total := 0
	for total < len(buf) {
		n, err := r.Read(buf[total:])
		if err != nil {
			return total, err
		}
		total += n
	}
	return total, nil
}

func runUDP(host string, port int) {
	conn, err := net.Dial("udp", fmt.Sprintf("%s:%d", host, port))
	if err != nil {
		fmt.Fprintf(os.Stderr, "连接失败: %v\n", err)
		os.Exit(1)
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	callUDP(conn, mpcommon.CmdPing, "hello")
	callUDP(conn, mpcommon.CmdPut, "user:3=carol")
	callUDP(conn, mpcommon.CmdGet, "user:3")
	callUDP(conn, mpcommon.CmdStats, "")
}

func callUDP(conn net.Conn, cmd int32, payload string) {
	req := mpcommon.NewFrame(mpcommon.FlagNeedResponse, cmd, nextSeq(), []byte(payload))
	data, err := mpcommon.Encode(req)
	if err != nil {
		fmt.Println("编码失败:", err)
		return
	}
	if _, err := conn.Write(data); err != nil {
		fmt.Println("发送失败:", err)
		return
	}
	buf := make([]byte, 4096)
	n, err := conn.Read(buf)
	if err != nil {
		fmt.Println("读取失败 (UDP 可能丢包):", err)
		return
	}
	resp, err := mpcommon.Decode(buf[:n])
	if err != nil {
		fmt.Println("解码失败:", err)
		return
	}
	fmt.Printf("%-10s → %s\n", mpcommon.CmdName(cmd), resp.Payload)
}


// ---------------- KCP 客户端 ----------------
//
// KCP 是可靠传输协议，因此客户端需要：
//  1. 周期性驱动 kcp.Update（触发重传与 ACK）
//  2. 把收到的 UDP 数据报交给 kcp.Input
//  3. 从 kcp.Recv 取出重组后的完整消息
//
// 这里全部在主 goroutine 串行执行（收包经 channel 转入），无需加锁。

func runKCP(host string, port int) {
	conn, err := net.Dial("udp", fmt.Sprintf("%s:%d", host, port))
	if err != nil {
		fmt.Fprintf(os.Stderr, "连接失败: %v\n", err)
		os.Exit(1)
	}
	defer conn.Close()

	const conv = 0x11223344 // 会话标识，服务端从包头读取
	start := time.Now()
	nowMs := func() uint32 { return uint32(time.Since(start).Milliseconds()) }

	// KCP 的输出回调：直接写 UDP
	k := gateway.NewKCP(conv, func(buf []byte) {
		_, _ = conn.Write(buf)
	})

	// 收包协程：UDP 数据报 → channel，由主 goroutine 串行消费
	pktCh := make(chan []byte, 256)
	go func() {
		buf := make([]byte, 2048)
		for {
			n, err := conn.Read(buf)
			if err != nil {
				return
			}
			raw := make([]byte, n)
			copy(raw, buf[:n])
			select {
			case pktCh <- raw:
			default:
			}
		}
	}()

	cmds := []struct {
		cmd     int32
		payload string
	}{
		{mpcommon.CmdPing, "hello"},
		{mpcommon.CmdPut, "user:1=alice"},
		{mpcommon.CmdPut, "user:2=bob"},
		{mpcommon.CmdGet, "user:1"},
		{mpcommon.CmdRouteSet, "7=node-3"},
		{mpcommon.CmdRouteGet, "7"},
		{mpcommon.CmdStats, ""},
	}

	for _, c := range cmds {
		callKCP(k, pktCh, nowMs, c.cmd, c.payload)
	}
}

// callKCP 发一帧并等待响应（期间持续驱动 KCP 时钟）
func callKCP(k *gateway.KCP, pktCh <-chan []byte, nowMs func() uint32,
	cmd int32, payload string) {
	req := mpcommon.NewFrame(mpcommon.FlagNeedResponse, cmd, nextSeq(), []byte(payload))
	out, err := mpcommon.Encode(req)
	if err != nil {
		fmt.Println("编码失败:", err)
		return
	}
	if err := k.Send(out); err != nil {
		fmt.Println("发送失败:", err)
		return
	}

	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		// 非阻塞取包并交给 KCP
		select {
		case pkt := <-pktCh:
			_ = k.Input(pkt)
		default:
		}
		// 驱动时钟（内部会在需要时 flush，触发重传/ACK）
		k.Update(nowMs())

		// 尝试取出完整响应
		if msg, err := k.Recv(); err == nil {
			resp, err := mpcommon.Decode(msg)
			if err != nil {
				fmt.Println("解码失败:", err)
				return
			}
			fmt.Printf("%-10s → %s\n", mpcommon.CmdName(cmd), resp.Payload)
			return
		}
		time.Sleep(2 * time.Millisecond)
	}
	fmt.Printf("%-10s → 超时（KCP 重传仍未收到响应）\n", mpcommon.CmdName(cmd))
}
