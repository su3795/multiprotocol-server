//go:build !quic

package main

import "fmt"

// runQUIC 默认构建下的占位实现。
//
// QUIC 需要 -tags quic 构建。启用方式：
//
//	go get github.com/quic-go/quic-go
//	go build -tags quic ./...
func runQUIC(host string, port int) {
	fmt.Printf("QUIC 模式需要以 -tags quic 构建: go build -tags quic ./cmd/client\n")
	fmt.Printf("（目标 %s:%d 未连接）\n", host, port)
}
