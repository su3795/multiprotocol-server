// Command mp-server 是 Go 版多协议集群服务器入口（对应 Java 版 ServerMain）。
//
// 用法：
//
//	go run ./cmd/server --mode memory --node-id 0 \
//	     --tcp :9101 --udp :9201 --metrics :9091
//
// 共识模式：
//   - memory     零依赖内存 Raft（默认，单进程 3 节点，开箱可跑）
//   - dragonboat 工业级 Multi-Raft-Group（需 -tags dragonboat 构建）
package main

import (
	"flag"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"mpc/internal/consensus"
	"mpc/internal/gateway"
	"mpc/internal/observability"
)

func main() {
	var (
		mode        = flag.String("mode", "memory", "共识模式: memory | dragonboat")
		nodeID      = flag.Int("node-id", 0, "本节点 ID (0-based)")
		members     = flag.String("members", "0,1,2", "集群成员 ID，逗号分隔")
		nodeAddr    = flag.String("node-addr", "127.0.0.1:8081", "本节点 Raft 地址")
		peers       = flag.String("peers", "", "全部节点地址，逗号分隔 (dragonboat 模式用)")
		tcpAddr     = flag.String("tcp", ":9101", "TCP 监听地址")
		udpAddr     = flag.String("udp", ":9201", "UDP 监听地址")
		customAddr  = flag.String("custom", "", "自定义协议监听地址，留空则不启用")
		kcpAddr     = flag.String("kcp", "", "KCP 监听地址(基于 UDP 的可靠传输)，留空则不启用")
		quicAddr    = flag.String("quic", "", "QUIC 监听地址(需 -tags quic 构建)，留空则不启用")
		metricsPort = flag.Int("metrics-port", 9091, "Prometheus 指标端口")
		dataDir     = flag.String("data-dir", "./data/node0", "数据目录")
	)
	flag.Parse()

	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	log.Printf("========== 多协议集群服务器 · Go 版 ==========")
	log.Printf("共识模式 = %s, nodeID = %d", *mode, *nodeID)

	// ---------- 1. 共识层 ----------
	c, err := consensus.New(consensus.Config{
		Mode:     *mode,
		NodeID:   *nodeID,
		Members:  *members,
		NodeAddr: *nodeAddr,
		Peers:    *peers,
		DataDir:  *dataDir,
	})
	if err != nil {
		log.Fatalf("启动共识层失败: %v", err)
	}
	if err := c.Start(); err != nil {
		log.Fatalf("共识层 Start 失败: %v", err)
	}

	// ---------- 2. 指标端点 ----------
	observability.ServeMetrics(*metricsPort)
	log.Printf("指标端点: http://0.0.0.0:%d/metrics", *metricsPort)

	// ---------- 3. 多协议接入 ----------
	proc := gateway.NewRequestProcessor(c)

	go func() {
		if err := gateway.ServeTCP(*tcpAddr, proc); err != nil {
			log.Fatalf("TCP 服务失败: %v", err)
		}
	}()
	go func() {
		if err := gateway.ServeUDP(*udpAddr, proc); err != nil {
			log.Fatalf("UDP 服务失败: %v", err)
		}
	}()
	if *customAddr != "" {
		go func() {
			if err := gateway.ServeCustom(*customAddr, proc); err != nil {
				log.Fatalf("CUSTOM 服务失败: %v", err)
			}
		}()
	}
	if *kcpAddr != "" {
		go func() {
			if err := gateway.ServeKCP(*kcpAddr, proc); err != nil {
				log.Fatalf("KCP 服务失败: %v", err)
			}
		}()
	}
	if *quicAddr != "" {
		if err := gateway.ServeQUIC(*quicAddr, proc); err != nil {
			log.Fatalf("QUIC 服务失败: %v", err)
		}
	}

	// 等待接入层就绪
	time.Sleep(300 * time.Millisecond)
	log.Printf("--------------------------------------------------")
	log.Printf("节点就绪 | 实现=%s | 角色=%s | TCP=%s | UDP=%s | KCP=%s | QUIC=%s",
		c.Implementation(), c.Role(), *tcpAddr, *udpAddr, *kcpAddr, *quicAddr)
	log.Printf("--------------------------------------------------")

	// ---------- 4. 优雅退出 ----------
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Println("正在关闭节点...")
	if err := c.Close(); err != nil {
		log.Printf("关闭共识层出错: %v", err)
	}
	log.Println("节点已关闭")
}
