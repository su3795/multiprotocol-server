# 多协议集群服务器 · Go 版

按统一架构方案实现的**可运行 Demo**。与 [Java 版](../multiprotocol-cluster) 严格对齐：
**帧格式、命令字、响应格式、模块划分全部一致**，因此 Go 服务端可与 Java / Rust 客户端互相通信，反之亦然。

---

## 一、模块结构

```
multiprotocol-cluster-go/
├── cmd/
│   ├── server/main.go           # 启动器（对应 Java ServerMain）
│   └── client/main.go           # 演示客户端（对应 Java DemoClient）
├── internal/
│   ├── mpcommon/                # 对应 mp-common：帧格式 + 命令模型（零依赖）
│   ├── consensus/               # 对应 mp-consensus-api + 实现
│   ├── observability/           # 对应 mp-observability：指标 + Prometheus
│   └── gateway/                 # 对应 mp-gateway：TCP/UDP/CUSTOM 接入
├── docs/VECTORS.md              # 跨语言测试向量
└── scripts/                     # 构建与启停脚本
```

### 与 Java 版的对应关系

| Java 模块 | Go 包 | 说明 |
|---|---|---|
| `mp-common` | `internal/mpcommon` | 帧编解码、Command、RouteTable |
| `mp-consensus-api` | `internal/consensus` | `Consensus` 接口 |
| `mp-consensus-jraft` | `internal/consensus` (mode=dragonboat) | 工业级实现 |
| `mp-observability` | `internal/observability` | 指标 |
| `mp-gateway` | `internal/gateway` | Netty → goroutine-per-conn |
| `mp-launcher` | `cmd/server` + `cmd/client` | 启动器 |

---

## 二、为什么默认零依赖

Go 版**默认构建只依赖标准库**：

```bash
go build ./...   # 无需 go mod download，离线可构建
```

共识层默认使用 `memory` 模式（单进程内 3 个 Raft 节点，channel 互联），
完整演示选举 / 复制 / 提交 / 线性读全链路。

工业级 dragonboat 通过 build tag 启用：

```bash
go get github.com/lni/dragonboat/v4
go build -tags dragonboat ./...
```

这样既保证 `go run` 一定成功，又保留了生产级升级路径。

---

## 三、快速开始

### 前置条件

| 组件 | 版本 |
|---|---|
| Go | **1.21+** |

无需联网下载依赖（默认模式）。

### 构建

```bash
cd multiprotocol-cluster-go
make build          # 或 ./scripts/build.sh
```

产物：`bin/mp-server`、`bin/mp-client`

### 契约自测

```bash
make test           # 或 ./scripts/test.sh
```

验证帧编解码与 Java 版**字节级一致**（见 `docs/VECTORS.md`）。

### 启动

```bash
./scripts/start.sh
# 或
./bin/mp-server --mode memory --node-id 0 --tcp :9101 --udp :9201 --custom :9301 --metrics-port 9091
```

### 端到端验证

```bash
./bin/mp-client --proto tcp --port 9101
./bin/mp-client --proto udp --port 9201
```

预期输出：

```
=== 演示客户端 · tcp → 127.0.0.1:9101 ===
PING       → OK|PONG
PUT        → OK|applied, cost=1240us
PUT        → OK|applied, cost=680us
GET        → OK|alice
ROUTE_SET  → OK|applied, cost=910us
ROUTE_GET  → OK|node-3
STATS      → OK|impl=MemoryRaft(Go), role=LEADER, leader=true, connections=1, kvCount=2, routeCount=1
```

### 查看指标

```bash
curl http://127.0.0.1:9091/metrics | grep ^mp_
```

| 指标 | 类型 | 说明 |
|---|---|---|
| `mp_requests_total` | Counter | 按协议/命令维度请求数 |
| `mp_request_duration` | Histogram | 请求耗时（分桶） |
| `mp_consensus_propose_duration` | Histogram | 共识提交耗时 |
| `mp_consensus_propose_errors_total` | Counter | 共识写失败数 |
| `mp_connections_active` | Gauge | 活跃连接数 |
| `mp_uptime_seconds` | Gauge | 进程运行时长 |

### 一键演示

```bash
./scripts/e2e.sh    # 构建 → 启动 → TCP/UDP 验证 → 抓指标
./scripts/stop.sh   # 停止
```

---

## 四、帧格式

与 Java / Rust 版完全一致：

```
┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
│ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
│ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
└────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
```

- `magic` = `0x4D50`，大端序
- `crc32` 覆盖 `[offset 2, 2+18+len)`

### 命令字

| cmd | 名称 | 走共识 | 说明 |
|---|---|---|---|
| 1 | `PUT` | ✅ 写 | 写 KV，仅 Leader 可写 |
| 2 | `GET` | ✅ 线性读 | 线性一致读 |
| 3 | `ROUTE_SET` | ✅ 写 | 设置 `shard → node` |
| 4 | `ROUTE_GET` | 本地读 | 读路由表 |
| 5 | `PING` | ❌ | 测纯接入层延迟 |
| 6 | `STATS` | ❌ | 节点状态 |

响应 payload 格式：`OK|body` 或 `ERR|body`（与 Java 版一致）。

---

## 五、与 Java 版的实现差异

| 维度 | Java 版 | Go 版 |
|---|---|---|
| IO 模型 | Netty EventLoop | goroutine-per-connection（标准 net 包） |
| 分帧 | `FrameDecoder extends ByteToMessageDecoder` | `TryDecode` + 累积切片 |
| 共识（生产） | SOFAJRaft | dragonboat（build tag） |
| 共识（默认） | 无 | 内存 Raft（单进程多节点） |
| 指标 | Micrometer | 自实现 Prometheus 文本导出 |
| 依赖 | 多（Netty/JRaft/Micrometer） | 默认**零**第三方依赖 |

**架构分层完全一致**：协议差异收敛在 `gateway`，共识差异收敛在 `consensus`，
上层 `RequestProcessor` 只见 `Frame`。

---

## 六、扩展新协议

新增协议只需两步，业务代码零改动：

1. 实现对应的 `serve` 函数（如 `ServeQUIC`）
2. 在 `cmd/server/main.go` 中启动

`internal/gateway/processor.go` 只认 `Frame`，完全不感知底层协议。
`Protocol` 枚举已预留 `QUIC` / `KCP` / `CUSTOM`。

---

## 七、⚠️ 验证状态

**本项目未在真实环境中编译与运行验证。**

生成环境的限制：

| 限制 | 影响 |
|---|---|
| 无 Go 工具链 | 无法 `go build` / `go test` |
| 外网不可达（Maven/apt 均 403） | 无法安装 Go |

已完成的自检：

- ✅ 12 个默认构建文件的括号平衡
- ✅ 跨包符号引用全部可解析（含 `var` 块定义）
- ✅ 全部 `import` 均被使用，无冗余
- ✅ 帧编解码逻辑逐行复核，测试向量与 Java 版基准一致

**首次构建请按此顺序排查**：

```bash
go vet ./...        # 1. 静态检查
make test           # 2. 契约自测（零依赖，最容易跑通）
make build          # 3. 全量构建
./scripts/e2e.sh    # 4. 端到端
```

### 可能需要调整的地方

1. **Go 版本**：`go.mod` 声明 `go 1.21`。若使用更低版本，请把 `min`/`max` 等内置函数替换掉（本项目未使用，但 `errors.Join` 等需注意）。
2. **dragonboat API**：`backend_dragonboat.go` 基于 dragonboat v4 API 编写。
   启用前请对照 [dragonboat 官方 example](https://github.com/lni/dragonboat) 核对
   `StartCluster` / `SyncPropose` / `SyncRead` 签名。
3. **端口占用**：默认 TCP 9101 / UDP 9201 / CUSTOM 9301 / metrics 9091，冲突时请用参数改。

---

---

## 八、KCP（可靠 UDP）实现说明

> 这是原始需求里明确要求的一项。KCP 不是占位，而是**完整实现**的 ARQ 协议。

### 为什么需要它

| 场景 | TCP | UDP | KCP |
|---|---|---|---|
| 弱网丢包 5% | 队头阻塞，延迟飙升 | 直接丢包 | ✅ 选择性重传，延迟可控 |
| 实时对战/信令 | 太慢 | 不可靠 | ✅ 可靠 + 低延迟 |
| 大文件/带宽敏感 | ✅ 最省 | - | ❌ 多耗 10~20% 带宽 |

**KCP 用带宽换延迟**：RTO 按 ×1.5 增长（TCP 是 ×2）、只重传真正丢失的段
（TCP 会重传该段之后全部数据）、支持快速重传不等超时。

### 实现位置

| 版本 | 文件 |
|---|---|
| Go | `internal/gateway/kcp.go` |
| Rust | `crates/mp-gateway/src/kcp.rs` |

两版**线格式完全一致**（小端序、24 字节段头），因此可互通：
Go 客户端可以直接连 Rust 的 KCP 服务端。

### 验证状态

用 Python 独立复刻同一套算法做了交叉验证：

- ✅ 5000 字节消息自动分为 4 个分片，重组后与原文逐字节相同
- ✅ 连续丢弃 3 轮数据包后，通过重传最终完整恢复（3000 字节）
- ✅ 段格式：小端序 conv、`cmd=81(PUSH)`、24 字节头
- ✅ Go / Rust 两版 12 个协议常量全部一致

### 启动

```bash
--kcp :9401          # Go
--kcp 127.0.0.1:9401 # Rust
```

客户端：

```bash
./bin/mp-client --proto kcp --port 9401                    # Go
./target/release/mp-server client --proto kcp --port 9401  # Rust
```

### 使用要点（容易踩坑）

1. **必须周期性 `update`**：KCP 靠时钟驱动重传与 ACK，接入层用 10ms
   ticker 驱动（`interval=100ms`）。不驱动就等于没有重传。
2. **会话靠 conv 区分**：服务端从接收到的首个包的前 4 字节读取 conv，
   并以「对端地址 + conv」作为会话键。客户端示例固定用 `0x11223344`。
3. **单条消息上限**：分片数最多 255，即约 `255 × 1376 ≈ 345KB`。
   超过返回 `TooLarge`。
4. **不适用大文件**：KCP 以带宽换延迟，批量传输请用 TCP。

---

## 协议支持矩阵（已补全）

| 协议 | Java | Go | Rust | 默认启用 | 说明 |
|---|:---:|:---:|:---:|:---:|---|
| TCP | ✅ | ✅ | ✅ | ✅ | 流式，需处理粘包/半包 |
| UDP | ✅ | ✅ | ✅ | ✅ | 数据报，天然分帧 |
| **KCP** | ✅ 新增 | ✅ | ✅ | ✅ | 可靠 UDP（ARQ），零依赖自实现 |
| **CUSTOM** | ✅ 新增 | ✅ | ✅ | ✅ | UDP 变体 + 可插拔 payload 变换 |
| **QUIC** | ✅ 新增 | ✅ 新增 | ✅ 新增 | ❌ 可选 | 需外部库与 TLS 证书 |

### 统一端口

| 协议 | 端口 |
|---|---|
| TCP | 9101 |
| UDP | 9201 |
| CUSTOM | 9301 |
| KCP | 9401 |
| QUIC | 9501（可选） |
| metrics | 9091 |

### QUIC 为什么默认关闭

QUIC 需要额外依赖与 TLS 1.3 证书，与「默认零依赖、开箱可跑」冲突。
三版均通过**构建开关**隔离，不影响默认构建：

| 版本 | 启用方式 | 依赖 |
|---|---|---|
| Java | `mvn -Pquic clean package` | `netty-incubator-codec-quic` |
| Go | `make build-quic`（`-tags quic`） | `quic-go` |
| Rust | `cargo build --features quic` | `quinn` + `rustls` + `rcgen` |

Java 版未指定 `--quic-port` 时不加载任何 QUIC 代码（反射探测）；
Go/Rust 版未启用开关时给出明确错误提示而非静默失败。

### QUIC 核心优势

- **0-RTT / 1-RTT 握手**：连接建立延迟显著低于 TCP+TLS
- **无队头阻塞**：多路复用流相互独立，单流丢包不阻塞其他流
- **连接迁移**：网络切换（WiFi↔4G）时连接不断开

### 各协议适用场景

| 场景 | 推荐协议 | 理由 |
|---|---|---|
| 常规 RPC / 元数据 | TCP | 最省带宽，生态最成熟 |
| 高频低价值数据（埋点、位置同步） | UDP | 允许少量丢失换低延迟 |
| 弱网实时（对战、音视频信令） | **KCP** | 选择性重传，延迟可控 |
| 移动端 / 需要连接迁移 | **QUIC** | 网络切换不断线 |
| 需私有混淆加密 | **CUSTOM** | 可插拔 payload 变换 |
| 大文件、带宽敏感 | TCP | KCP 多耗 10~20% 带宽，不划算 |

### ⚠️ QUIC 的验证状态

QUIC 是三版中**唯一完全未验证**的部分（连静态检查都覆盖不到，因为
默认构建会跳过它）。原因：

- 需要 `quic-go` / `quinn` / `netty-incubator-codec-quic` 外部库
- 沙盒无工具链、无网络，无法拉取依赖也无法编译

**已知风险点**：

1. **quinn 版本差异**：0.10 与 0.11 的 `Endpoint::server` 签名不同
   （0.10 返回 `(Endpoint, Incoming)`，0.11 改为 `Endpoint::accept`）。
   本实现基于 **0.10**，用 0.11 需对照官方 example 调整。
2. **quic-go API**：`quic.ListenAddr` / `AcceptStream` 在不同版本有变动。
3. **netty QUIC**：`QuicServerCodecBuilder` API 在 0.0.x 各版本间有调整。

启用 QUIC 时请优先对照各库官方 example 核对 API 签名。

## License

参考实现，可自由使用与修改。
