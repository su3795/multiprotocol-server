#!/usr/bin/env bash
# 端到端验证：启动服务端 → TCP/UDP 客户端 → 抓指标 → 停止
set -euo pipefail
cd "$(dirname "$0")/.."

echo "########## 1/4 构建 ##########"
./scripts/build.sh

echo "########## 2/4 启动节点 ##########"
./scripts/start.sh

echo "########## 3/4 TCP 端到端 ##########"
./bin/mp-client --proto tcp --port 9101

echo "########## 4/5 UDP 端到端 ##########"
./bin/mp-client --proto udp --port 9201

echo "########## 5/5 KCP 端到端（可靠 UDP）##########"
./bin/mp-client --proto kcp --port 9401

echo
echo "########## Prometheus 指标 ##########"
curl -s http://127.0.0.1:9091/metrics | grep -E "^mp_" | head -20

echo
echo "########## 完成 ##########"
echo "停止: ./scripts/stop.sh"
