#!/usr/bin/env bash
cd "$(dirname "$0")/.."
if [[ -f logs/server.pid ]]; then
  PID=$(cat logs/server.pid)
  if kill -0 "$PID" 2>/dev/null; then
    echo ">>> 停止进程 $PID"
    kill "$PID"
  fi
  rm -f logs/server.pid
fi
pkill -f "bin/mp-server" 2>/dev/null || true
echo ">>> 已停止"
