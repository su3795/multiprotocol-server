#!/usr/bin/env bash
# 构建 Go 版（需要 Go 1.21+）
set -euo pipefail
cd "$(dirname "$0")/.."
echo ">>> 构建 multiprotocol-cluster-go ..."
go build -o bin/mp-server ./cmd/server
go build -o bin/mp-client ./cmd/client
echo ">>> 产物:"
ls -lh bin/
