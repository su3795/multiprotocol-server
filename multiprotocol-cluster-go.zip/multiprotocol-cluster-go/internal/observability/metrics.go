// Package observability 对应 Java 版 mp-observability：指标采集与暴露。
//
// 设计取舍：为了让 `go run` 开箱即跑，这里**不引入 client_golang**，
// 而是用标准库实现一个极简 Prometheus 文本导出器（原子计数 + 分桶直方图）。
// 生产环境替换为 prometheus/client_golang 只需改动本包，业务埋点代码不变。
//
// 关键约束：埋点只做原子累加与直方图观测，绝不阻塞关键路径。
package observability

import (
	"fmt"
	"net/http"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// 默认耗时分桶边界（秒）
var defaultBuckets = []float64{
	0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5,
}

// counter 原子计数器
type counter struct {
	v int64
}

func (c *counter) Inc()      { atomic.AddInt64(&c.v, 1) }
func (c *counter) Get() int64 { return atomic.LoadInt64(&c.v) }

// gauge 可增减的瞬时值
type gauge struct {
	v int64
}

func (g *gauge) Inc()       { atomic.AddInt64(&g.v, 1) }
func (g *gauge) Dec()       { atomic.AddInt64(&g.v, -1) }
func (g *gauge) Set(n int64) { atomic.StoreInt64(&g.v, n) }
func (g *gauge) Get() int64  { return atomic.LoadInt64(&g.v) }

// histogram 分桶直方图
type histogram struct {
	buckets []float64
	counts  []int64
	sum     uint64 // float64 位模式
	count   int64
}

func newHistogram(buckets []float64) *histogram {
	return &histogram{buckets: append([]float64{}, buckets...), counts: make([]int64, len(buckets))}
}

func (h *histogram) Observe(sec float64) {
	for i, b := range h.buckets {
		if sec <= b {
			atomic.AddInt64(&h.counts[i], 1)
		}
	}
	atomic.AddInt64(&h.count, 1)
	atomic.AddUint64(&h.sum, uint64(sec*1e9)) // 纳秒，避免浮点原子
}

// Metrics 指标注册表
type Metrics struct {
	mu        sync.RWMutex
	counters  map[string]*counter
	gauges    map[string]*gauge
	histograms map[string]*histogram
	startTime time.Time
}

var global = &Metrics{
	counters:   make(map[string]*counter),
	gauges:     make(map[string]*gauge),
	histograms: make(map[string]*histogram),
	startTime:  time.Now(),
}

// Get 全局指标注册器
func Get() *Metrics { return global }

func (m *Metrics) counter(key string) *counter {
	m.mu.Lock()
	defer m.mu.Unlock()
	if c, ok := m.counters[key]; ok {
		return c
	}
	c := &counter{}
	m.counters[key] = c
	return c
}

func (m *Metrics) gauge(key string) *gauge {
	m.mu.Lock()
	defer m.mu.Unlock()
	if g, ok := m.gauges[key]; ok {
		return g
	}
	g := &gauge{}
	m.gauges[key] = g
	return g
}

func (m *Metrics) histogram(key string) *histogram {
	m.mu.Lock()
	defer m.mu.Unlock()
	if h, ok := m.histograms[key]; ok {
		return h
	}
	h := newHistogram(defaultBuckets)
	m.histograms[key] = h
	return h
}

// ---------------- 埋点 API ----------------

// IncRequests 请求计数，按协议与命令维度
func IncRequests(proto string, cmd string) {
	global.counter(fmt.Sprintf("mp_requests_total{proto=%q,cmd=%q}", proto, cmd)).Inc()
}

// ObserveRequestDuration 请求耗时（秒）
func ObserveRequestDuration(proto string, seconds float64) {
	global.histogram(fmt.Sprintf("mp_request_duration{proto=%q}", proto)).Observe(seconds)
}

// ObserveProposeDuration 共识提交耗时（秒）
func ObserveProposeDuration(seconds float64) {
	global.histogram(`mp_consensus_propose_duration{}`).Observe(seconds)
}

// IncProposeErrors 共识写失败计数
func IncProposeErrors() {
	global.counter("mp_consensus_propose_errors_total").Inc()
}

// IncConnections 连接建立
func IncConnections() { global.gauge("mp_connections_active").Inc() }

// DecConnections 连接断开
func DecConnections() { global.gauge("mp_connections_active").Dec() }

// ConnectionCount 当前连接数
func ConnectionCount() int64 { return global.gauge("mp_connections_active").Get() }

// ---------------- 暴露 ----------------

// Render 生成 Prometheus 文本格式
func (m *Metrics) Render() string {
	var sb strings.Builder

	m.mu.RLock()
	counterKeys := make([]string, 0, len(m.counters))
	for k := range m.counters {
		counterKeys = append(counterKeys, k)
	}
	gaugeKeys := make([]string, 0, len(m.gauges))
	for k := range m.gauges {
		gaugeKeys = append(gaugeKeys, k)
	}
	histKeys := make([]string, 0, len(m.histograms))
	for k := range m.histograms {
		histKeys = append(histKeys, k)
	}
	m.mu.RUnlock()

	sort.Strings(counterKeys)
	sort.Strings(gaugeKeys)
	sort.Strings(histKeys)

	for _, k := range counterKeys {
		name, labels := splitKey(k)
		fmt.Fprintf(&sb, "# TYPE %s counter\n%s%s %d\n", name, name, labels,
			global.counter(k).Get())
	}
	for _, k := range gaugeKeys {
		name, labels := splitKey(k)
		fmt.Fprintf(&sb, "# TYPE %s gauge\n%s%s %d\n", name, name, labels,
			global.gauge(k).Get())
	}
	for _, k := range histKeys {
		name, labels := splitKey(k)
		h := global.histogram(k)
		fmt.Fprintf(&sb, "# TYPE %s histogram\n", name)
		for i, b := range h.buckets {
			fmt.Fprintf(&sb, "%s_bucket%s,le=%q} %d\n", name, trimLabels(labels),
				fmt.Sprintf("%g", b), atomic.LoadInt64(&h.counts[i]))
		}
		sumNs := atomic.LoadUint64(&h.sum)
		fmt.Fprintf(&sb, "%s_sum%s %f\n", name, labels, float64(sumNs)/1e9)
		fmt.Fprintf(&sb, "%s_count%s %d\n", name, labels, atomic.LoadInt64(&h.count))
	}

	fmt.Fprintf(&sb, "# TYPE mp_uptime_seconds gauge\nmp_uptime_seconds %f\n",
		time.Since(m.startTime).Seconds())
	return sb.String()
}

// splitKey 从 "name{labels}" 拆出 name 与 "{labels}"
func splitKey(k string) (string, string) {
	if i := strings.Index(k, "{"); i >= 0 {
		return k[:i], k[i:]
	}
	return k, ""
}

// trimLabels 把 "{a=\"b\"}" 变成 "{a=\"b\","，用于追加 le
func trimLabels(labels string) string {
	if labels == "" {
		return "{"
	}
	if strings.HasSuffix(labels, "}") {
		return labels[:len(labels)-1] + ","
	}
	return labels
}

// ServeMetrics 在指定端口启动 /metrics 端点
func ServeMetrics(port int) {
	mux := http.NewServeMux()
	mux.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
		fmt.Fprint(w, Get().Render())
	})
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, "ok\n")
	})
	go func() {
		addr := fmt.Sprintf(":%d", port)
		if err := http.ListenAndServe(addr, mux); err != nil {
			fmt.Printf("[metrics] 监听 %s 失败: %v\n", addr, err)
		}
	}()
}
