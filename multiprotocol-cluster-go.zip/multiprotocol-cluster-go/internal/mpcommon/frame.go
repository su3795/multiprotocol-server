// Package mpcommon 对应 Java 版 mp-common：统一帧格式与命令模型。
//
// 帧结构（与 Java io.mp.common.codec.Frame 字节级一致）：
//
//	┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
//	│ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
//	│ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
//	└────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
//	                        头部固定 20B                      尾部 4B
//
// magic 固定 0x4D50（"MP"），全部整数为大端序。
// crc32 覆盖 [offset 2, 2+18+len)，即从 version 到 payload 结束（不含 magic 与 crc 本身）。
//
// 字节级一致是硬性要求：Java / Go / Rust 三版必须能互相通信。
package mpcommon

import (
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
)

const (
	// Magic 帧起始标记，'M''P'
	Magic uint16 = 0x4D50
	// HeaderSize 头部固定长度
	HeaderSize = 20
	// CRC32Size 尾部校验长度
	CRC32Size = 4
	// Version 当前协议版本
	Version byte = 1
	// MaxPayload 单帧 payload 上限 1MiB
	MaxPayload = 1 << 20
)

// 标志位
const (
	FlagNeedResponse byte = 0x01
	FlagCompressed   byte = 0x02
	FlagEncrypted    byte = 0x04
)

// 命令字（与 Java io.mp.gateway.Cmd 一致）
const (
	CmdPut      int32 = 1
	CmdGet      int32 = 2
	CmdRouteSet int32 = 3
	CmdRouteGet int32 = 4
	CmdPing     int32 = 5
	CmdStats    int32 = 6
)

// 响应码
const (
	CodeOK           int32 = 0
	CodeNotLeader    int32 = 1
	CodeBadRequest   int32 = 2
	CodeInternal     int32 = 3
)

// CmdName 命令字可读名
func CmdName(cmd int32) string {
	switch cmd {
	case CmdPut:
		return "PUT"
	case CmdGet:
		return "GET"
	case CmdRouteSet:
		return "ROUTE_SET"
	case CmdRouteGet:
		return "ROUTE_GET"
	case CmdPing:
		return "PING"
	case CmdStats:
		return "STATS"
	}
	return fmt.Sprintf("UNKNOWN(%d)", cmd)
}

// 协议类型
type Protocol string

const (
	ProtoTCP    Protocol = "TCP"
	ProtoUDP    Protocol = "UDP"
	ProtoQUIC   Protocol = "QUIC"
	ProtoKCP    Protocol = "KCP"
	ProtoCustom Protocol = "CUSTOM"
)

// Frame 一帧
type Frame struct {
	Version byte
	Flags   byte
	Cmd     int32
	Seq     int64
	Payload []byte
}

// NewFrame 构造请求帧
func NewFrame(flags byte, cmd int32, seq int64, payload []byte) *Frame {
	return &Frame{Version: Version, Flags: flags, Cmd: cmd, Seq: seq, Payload: payload}
}

// NeedResponse 是否需要响应
func (f *Frame) NeedResponse() bool { return f.Flags&FlagNeedResponse != 0 }

// Compressed 是否压缩
func (f *Frame) Compressed() bool { return f.Flags&FlagCompressed != 0 }

// Encrypted 是否加密
func (f *Frame) Encrypted() bool { return f.Flags&FlagEncrypted != 0 }

// EncodedLength 编码后总长度
func (f *Frame) EncodedLength() int { return HeaderSize + len(f.Payload) + CRC32Size }

// ---------------- 编码 ----------------

// Encode 编码为完整字节（含 magic 与 crc32）
func Encode(f *Frame) ([]byte, error) {
	if len(f.Payload) > MaxPayload {
		return nil, fmt.Errorf("payload 过大: %d", len(f.Payload))
	}
	total := f.EncodedLength()
	buf := make([]byte, total)

	binary.BigEndian.PutUint16(buf[0:2], Magic)
	buf[2] = f.Version
	buf[3] = f.Flags
	binary.BigEndian.PutUint32(buf[4:8], uint32(f.Cmd))
	binary.BigEndian.PutUint64(buf[8:16], uint64(f.Seq))
	binary.BigEndian.PutUint32(buf[16:20], uint32(len(f.Payload)))
	copy(buf[20:], f.Payload)

	// crc 覆盖 offset 2 起、长度 18+len（与 Java 一致）
	crc := crc32.ChecksumIEEE(buf[2 : 20+len(f.Payload)])
	binary.BigEndian.PutUint32(buf[total-CRC32Size:], crc)
	return buf, nil
}

// ---------------- 解码 ----------------

var (
	// ErrTooShort 数据不足一整帧
	ErrTooShort = errors.New("数据不足一整帧")
	// ErrBadMagic magic 不匹配
	ErrBadMagic = errors.New("magic 不匹配")
	// ErrBadLength payload 长度非法
	ErrBadLength = errors.New("payload 长度非法")
	// ErrBadCRC crc 校验失败
	ErrBadCRC = errors.New("crc32 校验失败")
)

// Decode 解码一帧（入参须为从 magic 开始的完整帧）
func Decode(data []byte) (*Frame, error) {
	if len(data) < HeaderSize+CRC32Size {
		return nil, ErrTooShort
	}
	if got := binary.BigEndian.Uint16(data[0:2]); got != Magic {
		return nil, fmt.Errorf("%w: 期望 0x%04X 实际 0x%04X", ErrBadMagic, Magic, got)
	}
	payloadLen := int(int32(binary.BigEndian.Uint32(data[16:20])))
	if payloadLen < 0 || payloadLen > len(data)-HeaderSize-CRC32Size {
		return nil, fmt.Errorf("%w: %d", ErrBadLength, payloadLen)
	}

	total := HeaderSize + payloadLen + CRC32Size
	want := binary.BigEndian.Uint32(data[total-CRC32Size:])
	if got := crc32.ChecksumIEEE(data[2 : 20+payloadLen]); got != want {
		return nil, fmt.Errorf("%w: 期望 0x%08X 实际 0x%08X", ErrBadCRC, want, got)
	}

	payload := make([]byte, payloadLen)
	copy(payload, data[20:20+payloadLen])

	return &Frame{
		Version: data[2],
		Flags:   data[3],
		Cmd:     int32(binary.BigEndian.Uint32(data[4:8])),
		Seq:     int64(binary.BigEndian.Uint64(data[8:16])),
		Payload: payload,
	}, nil
}

// TryDecode 从累积缓冲中尝试切出一帧，用于 TCP 流式分帧。
// 数据不足返回 (nil, 0, ErrTooShort)，调用方应继续累积。
func TryDecode(accumulated []byte) (*Frame, int, error) {
	if len(accumulated) < HeaderSize {
		return nil, 0, ErrTooShort
	}
	if got := binary.BigEndian.Uint16(accumulated[0:2]); got != Magic {
		return nil, 0, fmt.Errorf("%w: 期望 0x%04X 实际 0x%04X", ErrBadMagic, Magic, got)
	}
	payloadLen := int(int32(binary.BigEndian.Uint32(accumulated[16:20])))
	if payloadLen < 0 {
		return nil, 0, fmt.Errorf("%w: %d", ErrBadLength, payloadLen)
	}
	total := HeaderSize + payloadLen + CRC32Size
	if len(accumulated) < total {
		return nil, 0, ErrTooShort
	}
	f, err := Decode(accumulated[:total])
	if err != nil {
		return nil, 0, err
	}
	return f, total, nil
}

// PeekFrameLength 从至少 HeaderSize 字节的缓冲中读出整帧长度
func PeekFrameLength(head []byte) int {
	return HeaderSize + int(int32(binary.BigEndian.Uint32(head[16:20]))) + CRC32Size
}
