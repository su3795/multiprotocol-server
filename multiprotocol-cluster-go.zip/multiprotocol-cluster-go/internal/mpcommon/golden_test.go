package mpcommon

import (
	"encoding/hex"
	"testing"
)

// golden 向量测试 —— 由参考实现（Node.js）生成，经 Python 独立复刻交叉验证。
// 三版（Java/Go/Rust）编码结果必须逐字节一致。
// 用例来源: reference-impl/golden/frames.json

var goldenFrames = []struct {
	name    string
	flags   byte
	cmd     int32
	seq     int64
	payload string
	wantHex string
}{
	{"empty_ping", 0x01, 5, 1, "",
		"4d500101000000050000000000000001000000002fa0284c"},
	{"ping_hello", 0x01, 5, 2, "hello",
		"4d5001010000000500000000000000020000000568656c6c6fbe0bdba2"},
	{"put_kv", 0x01, 1, 3, "user:1=alice",
		"4d5001010000000100000000000000030000000c757365723a313d616c696365422b2ee3"},
	{"get_key", 0x01, 2, 4, "user:1",
		"4d50010100000002000000000000000400000006757365723a31d44d66bb"},
	{"route_set", 0x01, 3, 5, "7=node-3",
		"4d50010100000003000000000000000500000008373d6e6f64652d333a115965"},
	{"route_get", 0x01, 4, 6, "7",
		"4d50010100000004000000000000000600000001378ceb079e"},
	{"stats", 0x01, 6, 7, "",
		"4d500101000000060000000000000007000000001d2ab122"},
	{"utf8_chinese", 0x01, 1, 8, "名字=张三",
		"4d5001010000000100000000000000080000000de5908de5ad973de5bca0e4b8899fb3a2ea"},
	{"large_seq", 0x01, 2, 9007199254740991, "k",
		"4d50010100000002001fffffffffffff000000016b5cab6f88"},
	{"binary_payload", 0x01, 1, 9, "a\x00b\xffc",
		"4d50010100000001000000000000000900000006610062c3bf63006087cf"},
	{"flag_compressed", 0x02, 5, 10, "x",
		"4d50010200000005000000000000000a00000001786ac3a7f0"},
	{"flag_all", 0x07, 5, 11, "y",
		"4d50010700000005000000000000000b000000017932622524"},
}

func TestGoldenFrameEncoding(t *testing.T) {
	for _, c := range goldenFrames {
		f := NewFrame(c.flags, c.cmd, c.seq, []byte(c.payload))
		got, err := Encode(f)
		if err != nil {
			t.Fatalf("%s: 编码失败: %v", c.name, err)
		}
		gotHex := hex.EncodeToString(got)
		if gotHex != c.wantHex {
			t.Errorf("%s:\n  得到 %s\n  期望 %s", c.name, gotHex, c.wantHex)
		}
	}
}

func TestGoldenFrameDecode(t *testing.T) {
	for _, c := range goldenFrames {
		raw, err := hex.DecodeString(c.wantHex)
		if err != nil { t.Fatal(err) }
		f, err := Decode(raw)
		if err != nil {
			t.Fatalf("%s: 解码失败: %v", c.name, err)
		}
		if f.Cmd != c.cmd || f.Seq != c.seq {
			t.Errorf("%s: cmd/seq 不符", c.name)
		}
		if string(f.Payload) != c.payload {
			t.Errorf("%s: payload 不符: 得到 %q 期望 %q", c.name, f.Payload, c.payload)
		}
	}
}
