package mpcommon

import (
	"testing"
)

// 跨语言契约测试：编码结果必须与 Java 版 FrameCodec 完全一致。
// 基准向量由 Java 编码逻辑生成（见 docs/VECTORS.md）。

func TestEncodePutMatchesJavaVector(t *testing.T) {
	f := NewFrame(FlagNeedResponse, CmdPut, 1, []byte("user:1=alice"))
	b, err := Encode(f)
	if err != nil {
		t.Fatal(err)
	}
	want := []byte{
		0x4D, 0x50, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
		0x00, 0x00, 0x00, 0x0C,
		0x75, 0x73, 0x65, 0x72, 0x3A, 0x31, 0x3D, 0x61, 0x6C, 0x69, 0x63, 0x65,
		0x96, 0x17, 0xBE, 0x24,
	}
	if len(b) != len(want) {
		t.Fatalf("长度不符: got %d want %d", len(b), len(want))
	}
	for i := range want {
		if b[i] != want[i] {
			t.Fatalf("字节 %d 不符: got 0x%02X want 0x%02X\n全帧: % X", i, b[i], want[i], b)
		}
	}
}

func TestEncodeGetMatchesJavaVector(t *testing.T) {
	f := NewFrame(FlagNeedResponse, CmdGet, 2, []byte("user:1"))
	b, _ := Encode(f)
	want := []byte{
		0x4D, 0x50, 0x01, 0x01, 0x00, 0x00, 0x00, 0x02,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02,
		0x00, 0x00, 0x00, 0x06, 0x75, 0x73, 0x65, 0x72, 0x3A, 0x31,
		0x3C, 0xF8, 0xAC, 0xF8,
	}
	if len(b) != len(want) {
		t.Fatalf("长度不符: got %d want %d", len(b), len(want))
	}
	for i := range want {
		if b[i] != want[i] {
			t.Fatalf("字节 %d 不符: got 0x%02X want 0x%02X", i, b[i], want[i])
		}
	}
}

func TestEncodeEmptyPayloadMatchesJavaVector(t *testing.T) {
	f := NewFrame(FlagNeedResponse, CmdStats, 4, nil)
	b, _ := Encode(f)
	want := []byte{
		0x4D, 0x50, 0x01, 0x01, 0x00, 0x00, 0x00, 0x06,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04,
		0x00, 0x00, 0x00, 0x00, 0x5A, 0x8A, 0xCB, 0xF2,
	}
	if len(b) != len(want) {
		t.Fatalf("长度不符: got %d want %d", len(b), len(want))
	}
	for i := range want {
		if b[i] != want[i] {
			t.Fatalf("字节 %d 不符: got 0x%02X want 0x%02X", i, b[i], want[i])
		}
	}
}

func TestEncodeLargeSeqIsBigEndian(t *testing.T) {
	f := NewFrame(FlagNeedResponse, CmdPut, 0x0102030405060708, []byte("k=v"))
	b, _ := Encode(f)
	want := []byte{
		0x4D, 0x50, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01,
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
		0x00, 0x00, 0x00, 0x03, 0x6B, 0x3D, 0x76, 0xBD, 0xFC, 0x19, 0xD7,
	}
	if len(b) != len(want) {
		t.Fatalf("长度不符: got %d want %d", len(b), len(want))
	}
	for i := range want {
		if b[i] != want[i] {
			t.Fatalf("字节 %d 不符: got 0x%02X want 0x%02X", i, b[i], want[i])
		}
	}
}

func TestDecodeRoundTrip(t *testing.T) {
	orig := NewFrame(FlagNeedResponse|FlagCompressed, CmdRouteSet, 99, []byte("7=node-3"))
	b, _ := Encode(orig)
	got, err := Decode(b)
	if err != nil {
		t.Fatal(err)
	}
	if got.Cmd != orig.Cmd || got.Seq != orig.Seq || got.Flags != orig.Flags {
		t.Fatalf("解码不一致: %+v vs %+v", got, orig)
	}
	if string(got.Payload) != "7=node-3" {
		t.Fatalf("payload 不符: %q", got.Payload)
	}
	if !got.Compressed() || !got.NeedResponse() {
		t.Fatal("标志位解析错误")
	}
}

func TestDecodeRejectsBadMagic(t *testing.T) {
	f := NewFrame(0, CmdPing, 1, []byte("x"))
	b, _ := Encode(f)
	b[0] = 0x00
	if _, err := Decode(b); err == nil {
		t.Fatal("应拒绝 magic 不匹配")
	}
}

func TestDecodeRejectsCorruptedPayload(t *testing.T) {
	f := NewFrame(0, CmdPing, 1, []byte("hello"))
	b, _ := Encode(f)
	b[HeaderSize] ^= 0xFF // 篡改 payload 首字节
	if _, err := Decode(b); err == nil {
		t.Fatal("应拒绝 CRC 校验失败")
	}
}

func TestTryDecodeHalfPacket(t *testing.T) {
	f := NewFrame(0, CmdPut, 1, []byte("half packet test"))
	b, _ := Encode(f)
	partial := b[:HeaderSize+3]
	if _, _, err := TryDecode(partial); err != ErrTooShort {
		t.Fatalf("半包应返回 ErrTooShort, got %v", err)
	}
}

func TestTryDecodeFullPacketFromStream(t *testing.T) {
	f := NewFrame(0, CmdGet, 7, []byte("full"))
	b, _ := Encode(f)
	got, n, err := TryDecode(b)
	if err != nil {
		t.Fatal(err)
	}
	if n != len(b) {
		t.Fatalf("消费字节数不符: got %d want %d", n, len(b))
	}
	if string(got.Payload) != "full" || got.Seq != 7 {
		t.Fatalf("解码结果不符: %+v", got)
	}
}

func TestTryDecodeStickyPacket(t *testing.T) {
	a, _ := Encode(NewFrame(0, CmdPut, 1, []byte("a=1")))
	bb, _ := Encode(NewFrame(0, CmdGet, 2, []byte("a")))
	stream := append(append([]byte{}, a...), bb...)

	f1, n1, err := TryDecode(stream)
	if err != nil {
		t.Fatal(err)
	}
	if f1.Seq != 1 || n1 != len(a) {
		t.Fatalf("第一帧解析错误: seq=%d n=%d", f1.Seq, n1)
	}
	f2, n2, err := TryDecode(stream[n1:])
	if err != nil {
		t.Fatal(err)
	}
	if f2.Seq != 2 || n2 != len(bb) {
		t.Fatalf("第二帧解析错误: seq=%d n=%d", f2.Seq, n2)
	}
}

func TestCommandSerializeRoundTrip(t *testing.T) {
	c := NewUpsertRoute(7, "node-3")
	back, err := DeserializeCommand(c.Serialize())
	if err != nil {
		t.Fatal(err)
	}
	if back.Type != TypeUpsertRoute || back.ShardID() != 7 || back.Node() != "node-3" {
		t.Fatalf("往返失败: %+v", back)
	}
}

func TestCommandPutKvRoundTrip(t *testing.T) {
	c := NewPutKv("user:1", "alice")
	back, err := DeserializeCommand(c.Serialize())
	if err != nil {
		t.Fatal(err)
	}
	if back.Type != TypePutKv || back.Key2 != "user:1" || back.Val != "alice" {
		t.Fatalf("往返失败: %+v", back)
	}
}

func TestRouteTableApplyAndSnapshot(t *testing.T) {
	rt := NewRouteTable()
	rt.Apply(NewPutKv("k1", "v1"))
	rt.Apply(NewUpsertRoute(3, "node-9"))

	if v, ok := rt.KV("k1"); !ok || v != "v1" {
		t.Fatal("KV 读取失败")
	}
	if v, ok := rt.Route(3); !ok || v != "node-9" {
		t.Fatal("路由读取失败")
	}

	snap := rt.Snapshot()
	rt2 := NewRouteTable()
	rt2.LoadSnapshot(snap)
	if v, ok := rt2.KV("k1"); !ok || v != "v1" {
		t.Fatal("快照恢复后 KV 丢失")
	}
	if rt2.KVCount() != 1 || rt2.RouteCount() != 1 {
		t.Fatalf("快照恢复后计数错误: kv=%d route=%d", rt2.KVCount(), rt2.RouteCount())
	}
}

func TestParseKeyValue(t *testing.T) {
	k, v, err := ParseKeyValue("user:1=alice")
	if err != nil || k != "user:1" || v != "alice" {
		t.Fatalf("解析失败: %q %q %v", k, v, err)
	}
	if _, _, err := ParseKeyValue("novalue"); err == nil {
		t.Fatal("无 = 时应报错")
	}
}
