package mpcommon

import (
	"encoding/binary"
	"errors"
	"fmt"
	"strings"
	"sync"
)

// ---------------- 命令模型（对应 Java io.mp.common.model.Command） ----------------

// CommandType 命令类型
type CommandType byte

const (
	// TypeUpsertRoute shard -> node 路由更新
	TypeUpsertRoute CommandType = 1
	// TypeUpdateConfig 全局配置更新
	TypeUpdateConfig CommandType = 2
	// TypeTransferOwner 会话归属迁移
	TypeTransferOwner CommandType = 3
	// TypePutKv 通用 KV 写入（演示线性一致读）
	TypePutKv CommandType = 4
)

func (t CommandType) String() string {
	switch t {
	case TypeUpsertRoute:
		return "UPSERT_ROUTE"
	case TypeUpdateConfig:
		return "UPDATE_CONFIG"
	case TypeTransferOwner:
		return "TRANSFER_OWNER"
	case TypePutKv:
		return "PUT_KV"
	}
	return fmt.Sprintf("UNKNOWN(%d)", byte(t))
}

// Command 上共识层的命令。
//
// 设计约束：只承载元数据（路由表、配置、会话归属、少量 KV），
// 业务数据流绝不进入共识层，否则 Raft 会成为吞吐天花板。
//
// 序列化格式与 Java DataOutputStream 兼容：
// type(1) + key1(8) + key2(len:2 + UTF8) + value(len:2 + UTF8)
type Command struct {
	Type CommandType
	Key1 int64  // UPSERT_ROUTE: shardId ; TRANSFER_OWNER: connId
	Key2 string // UPSERT_ROUTE: node ; UPDATE_CONFIG/PUT_KV: key
	Val  string // UPDATE_CONFIG/PUT_KV: value
}

// NewUpsertRoute 路由更新命令
func NewUpsertRoute(shardID int64, node string) Command {
	return Command{Type: TypeUpsertRoute, Key1: shardID, Key2: node}
}

// NewUpdateConfig 配置更新命令
func NewUpdateConfig(key, value string) Command {
	return Command{Type: TypeUpdateConfig, Key2: key, Val: value}
}

// NewPutKv KV 写入命令
func NewPutKv(key, value string) Command {
	return Command{Type: TypePutKv, Key2: key, Val: value}
}

// ShardID UPSERT_ROUTE 场景下的语义化访问器
func (c Command) ShardID() int64 { return c.Key1 }

// Node UPSERT_ROUTE 场景下的语义化访问器
func (c Command) Node() string { return c.Key2 }

// Serialize 序列化
func (c Command) Serialize() []byte {
	k2 := []byte(c.Key2)
	v := []byte(c.Val)
	buf := make([]byte, 0, 1+8+2+len(k2)+2+len(v))
	buf = append(buf, byte(c.Type))

	var b8 [8]byte
	binary.BigEndian.PutUint64(b8[:], uint64(c.Key1))
	buf = append(buf, b8[:]...)

	var b2 [2]byte
	binary.BigEndian.PutUint16(b2[:], uint16(len(k2)))
	buf = append(buf, b2[:]...)
	buf = append(buf, k2...)

	binary.BigEndian.PutUint16(b2[:], uint16(len(v)))
	buf = append(buf, b2[:]...)
	buf = append(buf, v...)
	return buf
}

// ErrBadCommand 命令反序列化失败
var ErrBadCommand = errors.New("命令反序列化失败")

// DeserializeCommand 反序列化
func DeserializeCommand(data []byte) (Command, error) {
	var c Command
	if len(data) < 9 {
		return c, fmt.Errorf("%w: 长度不足 %d", ErrBadCommand, len(data))
	}
	c.Type = CommandType(data[0])
	c.Key1 = int64(binary.BigEndian.Uint64(data[1:9]))
	pos := 9

	k2, n, err := readUTF(data, pos)
	if err != nil {
		return c, err
	}
	c.Key2 = k2
	pos = n

	v, _, err := readUTF(data, pos)
	if err != nil {
		return c, err
	}
	c.Val = v
	return c, nil
}

// readUTF 读取 2B 长度前缀 + UTF8 字节（兼容 Java DataInputStream.readUTF）
func readUTF(data []byte, pos int) (string, int, error) {
	if pos+2 > len(data) {
		return "", 0, fmt.Errorf("%w: 读长度越界", ErrBadCommand)
	}
	n := int(binary.BigEndian.Uint16(data[pos : pos+2]))
	pos += 2
	if pos+n > len(data) {
		return "", 0, fmt.Errorf("%w: 读内容越界", ErrBadCommand)
	}
	return string(data[pos : pos+n]), pos + n, nil
}

func (c Command) String() string {
	return fmt.Sprintf("Command{%s, key1=%d, key2=%q, val=%q}", c.Type, c.Key1, c.Key2, c.Val)
}

// -------- ParsePayload 解析 "k=v" 形式的请求体 --------

// ParseKeyValue 解析 "key=value"，返回 key、value。无 '=' 时返回错误。
func ParseKeyValue(s string) (string, string, error) {
	idx := strings.Index(s, "=")
	if idx <= 0 {
		return "", "", fmt.Errorf("期望 key=value 格式，实际 %q", s)
	}
	return s[:idx], s[idx+1:], nil
}

// ---------------- 状态机（对应 Java io.mp.common.model.RouteTable） ----------------

// RouteTable 状态机持有的共享状态：路由表 + 配置 + 演示用 KV。
//
// 约定：
//   - 写操作只能经由共识层 apply（保证所有副本顺序一致）
//   - 所有变更必须幂等 —— Raft 在重放与重试时会重复 apply 同一条日志
type RouteTable struct {
	mu     sync.RWMutex
	routes map[int64]string
	config map[string]string
	owners map[int64]string
	kv     map[string]string
}

// NewRouteTable 创建空状态机
func NewRouteTable() *RouteTable {
	return &RouteTable{
		routes: make(map[int64]string),
		config: make(map[string]string),
		owners: make(map[int64]string),
		kv:     make(map[string]string),
	}
}

// Apply 应用一条命令（幂等）
func (t *RouteTable) Apply(c Command) {
	t.mu.Lock()
	defer t.mu.Unlock()
	switch c.Type {
	case TypeUpsertRoute:
		t.routes[c.Key1] = c.Key2
	case TypeUpdateConfig:
		t.config[c.Key2] = c.Val
	case TypeTransferOwner:
		t.owners[c.Key1] = c.Key2
	case TypePutKv:
		t.kv[c.Key2] = c.Val
	}
}

// Route 查询路由
func (t *RouteTable) Route(shardID int64) (string, bool) {
	t.mu.RLock()
	defer t.mu.RUnlock()
	v, ok := t.routes[shardID]
	return v, ok
}

// KV 查询 KV
func (t *RouteTable) KV(key string) (string, bool) {
	t.mu.RLock()
	defer t.mu.RUnlock()
	v, ok := t.kv[key]
	return v, ok
}

// RouteCount 路由条目数
func (t *RouteTable) RouteCount() int {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return len(t.routes)
}

// KVCount KV 条目数
func (t *RouteTable) KVCount() int {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return len(t.kv)
}

// Snapshot 快照序列化："R:k=v\n" 文本格式，与 Java 版一致便于互相恢复
func (t *RouteTable) Snapshot() []byte {
	t.mu.RLock()
	defer t.mu.RUnlock()
	var sb strings.Builder
	for k, v := range t.routes {
		fmt.Fprintf(&sb, "R:%d=%s\n", k, v)
	}
	for k, v := range t.config {
		fmt.Fprintf(&sb, "C:%s=%s\n", k, v)
	}
	for k, v := range t.kv {
		fmt.Fprintf(&sb, "K:%s=%s\n", k, v)
	}
	return []byte(sb.String())
}

// LoadSnapshot 快照反序列化
func (t *RouteTable) LoadSnapshot(data []byte) {
	next := NewRouteTable()
	for _, line := range strings.Split(string(data), "\n") {
		if len(line) < 3 {
			continue
		}
		kind := line[0]
		eq := strings.Index(line[2:], "=")
		if eq < 0 {
			continue
		}
		k := line[2 : 2+eq]
		v := line[2+eq+1:]
		switch kind {
		case 'R':
			var id int64
			if _, err := fmt.Sscanf(k, "%d", &id); err == nil {
				next.routes[id] = v
			}
		case 'C':
			next.config[k] = v
		case 'K':
			next.kv[k] = v
		}
	}
	t.mu.Lock()
	t.routes, t.config, t.kv = next.routes, next.config, next.kv
	t.mu.Unlock()
}
