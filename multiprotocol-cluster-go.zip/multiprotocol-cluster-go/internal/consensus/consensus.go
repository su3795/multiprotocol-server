// Package consensus 对应 Java 版 mp-consensus-api：共识层抽象。
//
// 本包同时提供两套实现，运行期通过 --mode 切换，业务代码零改动：
//
//   - memory     → 零依赖内存 Raft（单进程多节点，channel 互联），默认，保证开箱可跑
//   - dragonboat → 工业级 Multi-Raft-Group（需 build tag: -tags dragonboat）
//
// 三条硬约束：
//  1. 只有元数据上共识层，业务数据流不进 Raft
//  2. 状态机 apply 必须幂等（日志会被重放与重试）
//  3. 线性读不得返回旧值
package consensus

import (
	"errors"

	"mpc/internal/mpcommon"
)

// ErrNotLeader 非 Leader，客户端应重定向
var ErrNotLeader = errors.New("本节点非 Leader")

// ErrTimeout 共识超时
var ErrTimeout = errors.New("共识操作超时")

// Consensus 共识层统一抽象，与 Java io.mp.consensus.Consensus 对应
type Consensus interface {
	// Start 启动本节点的共识服务
	Start() error
	// IsLeader 当前节点是否为 Leader
	IsLeader() bool
	// Role 当前角色（LEADER / FOLLOWER / CANDIDATE）
	Role() string
	// Propose 提交一条命令，阻塞至多数派复制并提交
	Propose(cmd mpcommon.Command) (string, error)
	// LinearizableGet 线性一致读
	LinearizableGet(key string) (string, error)
	// StateMachine 本地状态机（非 Leader 也可用，但为最终一致）
	StateMachine() *mpcommon.RouteTable
	// Implementation 实现名称
	Implementation() string
	// Close 关闭
	Close() error
}
