//go:build dragonboat

package consensus

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"

	"mpc/internal/mpcommon"

	"github.com/lni/dragonboat/v4"
	"github.com/lni/dragonboat/v4/config"
	"github.com/lni/dragonboat/v4/statemachine"
)

// ---------------- dragonboat 状态机 ----------------

// metaSM 元数据复制状态机（dragonboat IStateMachine 实现）。
//
// 与 Java 版 MetaStateMachine 职责一致：只承载路由表 / 配置 / KV，
// 业务数据流不进入共识层。Update 必须幂等且不做阻塞 IO。
type metaSM struct {
	clusterID uint64
	nodeID    uint64
	table     *mpcommon.RouteTable
}

func newMetaSM(clusterID, nodeID uint64) statemachine.IStateMachine {
	return &metaSM{clusterID: clusterID, nodeID: nodeID, table: mpcommon.NewRouteTable()}
}

func (s *metaSM) Update(e statemachine.Entry) (statemachine.Result, error) {
	cmd, err := mpcommon.DeserializeCommand(e.Cmd)
	if err != nil {
		return statemachine.Result{}, err
	}
	s.table.Apply(cmd) // 幂等
	return statemachine.Result{Value: uint64(len(cmd.Key2) + len(cmd.Val))}, nil
}

func (s *metaSM) Lookup(q interface{}) (interface{}, error) {
	key, ok := q.(string)
	if !ok {
		return nil, fmt.Errorf("lookup 期望 string key")
	}
	v, _ := s.table.KV(key)
	return v, nil
}

func (s *metaSM) SaveSnapshot(w io.Writer, _ statemachine.ISnapshotFileCollection,
	_ <-chan struct{}) error {
	data := s.table.Snapshot()
	var hdr [4]byte
	binary.BigEndian.PutUint32(hdr[:], uint32(len(data)))
	if _, err := w.Write(hdr[:]); err != nil {
		return err
	}
	_, err := w.Write(data)
	return err
}

func (s *metaSM) RecoverFromSnapshot(r io.Reader, _ []statemachine.SnapshotFile,
	_ <-chan struct{}) error {
	var hdr [4]byte
	if _, err := io.ReadFull(r, hdr[:]); err != nil {
		return err
	}
	n := binary.BigEndian.Uint32(hdr[:])
	buf := make([]byte, n)
	if _, err := io.ReadFull(r, buf); err != nil {
		return err
	}
	s.table.LoadSnapshot(buf)
	return nil
}

func (s *metaSM) Close() error { return nil }

// ---------------- dragonboat 集群 ----------------

// dragonboatCluster 工业级共识实现
type dragonboatCluster struct {
	nh        *dragonboat.NodeHost
	clusterID uint64
	nodeID    uint64
	sm        *metaSM
	timeout   time.Duration
}

func createDragonboat(cfg Config) (Consensus, error) {
	members, err := parsePeerAddrs(cfg.Peers)
	if err != nil {
		return nil, err
	}
	nodeID := uint64(cfg.NodeID)
	if nodeID == 0 {
		nodeID = 1 // dragonboat 要求 1-based
	}
	clusterID := uint64(100)

	nhc := config.NodeHostConfig{
		WALDir:         cfg.DataDir + "/wal",
		NodeHostDir:    cfg.DataDir,
		RTTMillisecond: 200,
		RaftAddress:    cfg.NodeAddr,
	}
	nh, err := dragonboat.NewNodeHost(nhc)
	if err != nil {
		return nil, fmt.Errorf("创建 NodeHost 失败: %w", err)
	}

	rc := config.Config{
		NodeID:             nodeID,
		ClusterID:          clusterID,
		ElectionRTT:        10,
		HeartbeatRTT:       1,
		CheckQuorum:        true,
		SnapshotEntries:    10000,
		CompactionOverhead: 5000,
	}
	if err := nh.StartCluster(members, false, newMetaSM, rc); err != nil {
		return nil, fmt.Errorf("启动 Raft 组失败: %w", err)
	}

	return &dragonboatCluster{
		nh:        nh,
		clusterID: clusterID,
		nodeID:    nodeID,
		timeout:   5 * time.Second,
	}, nil
}

func (d *dragonboatCluster) Start() error { return nil }

func (d *dragonboatCluster) IsLeader() bool {
	id, _, ok, err := d.nh.GetLeaderID(d.clusterID)
	return err == nil && ok && id == d.nodeID
}

func (d *dragonboatCluster) Role() string {
	if d.IsLeader() {
		return "LEADER"
	}
	return "FOLLOWER"
}

func (d *dragonboatCluster) StateMachine() *mpcommon.RouteTable {
	// 通过本地查询获取（dragonboat 的 sm 由内部持有，这里用 SyncRead 语义等价）
	v, err := d.nh.SyncRead(context.Background(), d.clusterID, "__kv__")
	if err == nil {
		if m, ok := v.(*mpcommon.RouteTable); ok {
			return m
		}
	}
	return mpcommon.NewRouteTable()
}

func (d *dragonboatCluster) Implementation() string { return "Dragonboat(Go)" }

func (d *dragonboatCluster) Propose(cmd mpcommon.Command) (string, error) {
	start := time.Now()
	session := d.nh.GetNoOPSession(d.clusterID)
	ctx, cancel := context.WithTimeout(context.Background(), d.timeout)
	defer cancel()

	if _, err := d.nh.SyncPropose(ctx, session, cmd.Serialize()); err != nil {
		return "", err
	}
	return fmt.Sprintf("applied, cost=%dus", time.Since(start).Microseconds()), nil
}

func (d *dragonboatCluster) LinearizableGet(key string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), d.timeout)
	defer cancel()
	v, err := d.nh.SyncRead(ctx, d.clusterID, key)
	if err != nil {
		return "", ErrNotLeader
	}
	s, _ := v.(string)
	return s, nil
}

func (d *dragonboatCluster) Close() error {
	if d.nh != nil {
		d.nh.Stop()
	}
	return nil
}

// parsePeerAddrs 解析 "1=127.0.0.1:8081,2=127.0.0.1:8082" 形式的成员表
func parsePeerAddrs(s string) (map[uint64]string, error) {
	out := make(map[uint64]string)
	if strings.TrimSpace(s) == "" {
		return nil, fmt.Errorf("dragonboat 模式需要通过 --peers 指定成员地址")
	}
	for _, item := range strings.Split(s, ",") {
		item = strings.TrimSpace(item)
		if item == "" {
			continue
		}
		var id uint64
		var addr string
		if i := strings.Index(item, "="); i >= 0 {
			v, err := strconv.ParseUint(strings.TrimSpace(item[:i]), 10, 64)
			if err != nil {
				return nil, fmt.Errorf("非法成员 %q", item)
			}
			id, addr = v, strings.TrimSpace(item[i+1:])
		} else {
			// 无 ID 时按顺序分配
			id, addr = uint64(len(out)+1), item
		}
		out[id] = addr
	}
	return out, nil
}
