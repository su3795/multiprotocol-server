//go:build !dragonboat

package consensus

import "fmt"

// createDragonboat 默认构建下的占位实现。
//
// dragonboat 需要外部依赖（github.com/lni/dragonboat/v4），
// 为保证 `go build` / `go run` 零依赖开箱可跑，默认构建不包含它。
// 启用方式：go build -tags dragonboat ./...
func createDragonboat(cfg Config) (Consensus, error) {
	return nil, fmt.Errorf(
		"dragonboat 模式需要以 -tags dragonboat 构建: go build -tags dragonboat ./...\n" +
			"并先在 go.mod 中添加依赖: go get github.com/lni/dragonboat/v4")
}
