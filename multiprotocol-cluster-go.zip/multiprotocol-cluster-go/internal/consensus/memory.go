package consensus

import (
	"fmt"
	"log"
	"sync"
	"time"

	"mpc/internal/mpcommon"
)

// 内存 Raft：单进程内 N 个节点，通过 channel 互联。
//
// 定位：零第三方依赖，保证 `go run` 一定能跑起来并完整演示
// 选举 / 日志复制 / 提交 / 线性读 / 故障切换 全链路。
//
// 生产跨进程部署请使用 -tags dragonboat 构建（见 dragonboat.go）。
//
// 实现要点（标准 Raft）：
//   - 选举超时随机化，避免分裂投票
//   - 日志一致性检查：prevLogIndex/prevLogTerm 不匹配则回退 nextIndex
//   - commitIndex 只推进当前任期内已被多数派复制的日志
//   - 状态机 apply 幂等

type role int

const (
	roleFollower role = iota
	roleCandidate
	roleLeader
)

func (r role) String() string {
	switch r {
	case roleLeader:
		return "LEADER"
	case roleCandidate:
		return "CANDIDATE"
	}
	return "FOLLOWER"
}

// logEntry 日志条目
type logEntry struct {
	Term    int64
	Index   int64
	Command *mpcommon.Command
}

// rpc 节点间消息
type rpc struct {
	Type   rpcType
	Term   int64
	From   int
	// RequestVote
	LastLogIndex int64
	LastLogTerm  int64
	// AppendEntries
	PrevLogIndex int64
	PrevLogTerm  int64
	Entries      []logEntry
	LeaderCommit int64
	// 响应
	Granted bool
	Success bool
	MatchIndex int64
	Resp    chan rpc
}

type rpcType int

const (
	rpcVote rpcType = iota
	rpcVoteResp
	rpcAppend
	rpcAppendResp
	rpcHeartbeat
)

// memoryNode 一个 Raft 节点
type memoryNode struct {
	id       int
	peers    []int
	inbox    chan rpc
	outbox   map[int]chan rpc
	mu       sync.Mutex

	// 持久化状态
	currentTerm int64
	votedFor    int
	log         []logEntry // log[0] 为哨兵

	// 易失状态
	role        role
	leaderID    int
	commitIndex int64
	lastApplied int64
	nextIndex   map[int]int64
	matchIndex  map[int]int64

	// 状态机
	table *mpcommon.RouteTable

	// 通知：commitIndex 变化
	commitCh chan struct{}
	stopCh   chan struct{}
	stopped  bool
}

// MemoryCluster 内存集群（对外的 Consensus 实现，绑定到其中一个节点）
type MemoryCluster struct {
	node  *memoryNode
	nodes []*memoryNode
}

// MemoryConfig 内存集群配置
type MemoryConfig struct {
	// NodeID 本节点 ID（0-based），对外服务的那个节点
	NodeID int
	// Members 全部节点 ID，如 []int{0,1,2}
	Members []int
	// NodeAddr 本节点的 Raft 地址（内存实现下仅用于日志展示）
	NodeAddr string
}

// NewMemoryCluster 创建并启动一个 N 节点内存集群，返回绑定到 NodeID 的句柄
func NewMemoryCluster(cfg MemoryConfig) (*MemoryCluster, error) {
	if len(cfg.Members) == 0 {
		return nil, fmt.Errorf("成员列表为空")
	}
	found := false
	for _, m := range cfg.Members {
		if m == cfg.NodeID {
			found = true
		}
	}
	if !found {
		return nil, fmt.Errorf("节点 %d 不在成员列表 %v 中", cfg.NodeID, cfg.Members)
	}

	nodes := make([]*memoryNode, 0, len(cfg.Members))
	outboxes := make(map[int]chan rpc)
	for _, id := range cfg.Members {
		outboxes[id] = make(chan rpc, 1024)
	}
	for _, id := range cfg.Members {
		n := &memoryNode{
			id:        id,
			peers:     append([]int{}, cfg.Members...),
			inbox:     make(chan rpc, 1024),
			outbox:    outboxes,
			log:       []logEntry{{Term: 0, Index: 0}},
			votedFor:  -1,
			leaderID:  -1,
			role:      roleFollower,
			nextIndex: make(map[int]int64),
			matchIndex: make(map[int]int64),
			table:     mpcommon.NewRouteTable(),
			commitCh:  make(chan struct{}, 64),
			stopCh:    make(chan struct{}),
		}
		nodes = append(nodes, n)
	}
	// 建立 nodeID -> node 索引，并启动投递协程：outbox -> 目标节点 inbox。
	// 响应不经过投递，发送方通过 rpc.Resp 直接等待。
	byID := make(map[int]*memoryNode, len(nodes))
	for _, n := range nodes {
		byID[n.id] = n
	}
	for id, ch := range outboxes {
		target := byID[id]
		go func(ch chan rpc, target *memoryNode) {
			for msg := range ch {
				select {
				case target.inbox <- msg:
				case <-target.stopCh:
					return
				}
			}
		}(ch, target)
	}

	for _, n := range nodes {
		go n.loop()
	}

	me := nodes[0]
	for _, n := range nodes {
		if n.id == cfg.NodeID {
			me = n
		}
	}
	return &MemoryCluster{node: me, nodes: nodes}, nil
}

func (c *MemoryCluster) Start() error {
	log.Printf("[consensus] 内存 Raft 集群已启动，共 %d 节点，本节点 id=%d",
		len(c.nodes), c.node.id)
	return nil
}

func (c *MemoryCluster) IsLeader() bool {
	c.node.mu.Lock()
	defer c.node.mu.Unlock()
	return c.node.role == roleLeader
}

func (c *MemoryCluster) Role() string {
	c.node.mu.Lock()
	defer c.node.mu.Unlock()
	return c.node.role.String()
}

func (c *MemoryCluster) StateMachine() *mpcommon.RouteTable { return c.node.table }

func (c *MemoryCluster) Implementation() string { return "MemoryRaft(Go)" }

// Propose 提交命令：仅 Leader 可写，阻塞至提交并 apply
func (c *MemoryCluster) Propose(cmd mpcommon.Command) (string, error) {
	start := time.Now()
	n := c.node

	n.mu.Lock()
	if n.role != roleLeader {
		n.mu.Unlock()
		return "", ErrNotLeader
	}
	idx := int64(len(n.log))
	n.log = append(n.log, logEntry{Term: n.currentTerm, Index: idx, Command: &cmd})
	target := idx
	n.mu.Unlock()

	// 触发复制，等待 commitIndex 追上
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		n.replicate()
		n.mu.Lock()
		committed := n.commitIndex >= target
		n.mu.Unlock()
		if committed {
			// 等 apply 完成
			for i := 0; i < 100; i++ {
				n.mu.Lock()
				applied := n.lastApplied >= target
				n.mu.Unlock()
				if applied {
					cost := time.Since(start).Microseconds()
					return fmt.Sprintf("applied, cost=%dus", cost), nil
				}
				time.Sleep(time.Millisecond)
			}
		}
		time.Sleep(5 * time.Millisecond)
	}
	return "", ErrTimeout
}

// LinearizableGet 线性一致读：确认 Leader 身份后读状态机
func (c *MemoryCluster) LinearizableGet(key string) (string, error) {
	n := c.node
	n.mu.Lock()
	isLeader := n.role == roleLeader
	n.mu.Unlock()
	if !isLeader {
		return "", ErrNotLeader
	}
	v, _ := n.table.KV(key)
	return v, nil
}

func (c *MemoryCluster) Close() error {
	for _, n := range c.nodes {
		n.stop()
	}
	return nil
}

// ---------------- 节点主循环 ----------------

func (n *memoryNode) loop() {
	for {
		select {
		case <-n.stopCh:
			return
		default:
		}

		n.mu.Lock()
		r := n.role
		n.mu.Unlock()

		if r == roleLeader {
			n.replicate()
			select {
			case <-n.stopCh:
				return
			case <-time.After(50 * time.Millisecond):
			}
			continue
		}

		timeout := time.Duration(150+int(n.id)*37) * time.Millisecond
		select {
		case <-n.stopCh:
			return
		case msg := <-n.inbox:
			n.handle(msg)
		case <-time.After(timeout):
			n.startElection()
		}
	}
}

func (n *memoryNode) stop() {
	n.mu.Lock()
	if n.stopped {
		n.mu.Unlock()
		return
	}
	n.stopped = true
	n.mu.Unlock()
	close(n.stopCh)
}

func (n *memoryNode) quorum() int { return len(n.peers)/2 + 1 }

func (n *memoryNode) lastLogIndex() int64 { return int64(len(n.log)) - 1 }

func (n *memoryNode) lastLogTerm() int64 { return n.log[len(n.log)-1].Term }

func (n *memoryNode) startElection() {
	n.mu.Lock()
	n.currentTerm++
	n.role = roleCandidate
	n.votedFor = n.id
	term := n.currentTerm
	lli := n.lastLogIndex()
	llt := n.lastLogTerm()
	n.mu.Unlock()

	votes := 1
	for _, p := range n.peers {
		if p == n.id {
			continue
		}
		respCh := make(chan rpc, 1)
		select {
		case n.outbox[p] <- rpc{Type: rpcVote, Term: term, From: n.id,
			LastLogIndex: lli, LastLogTerm: llt, Resp: respCh}:
		default:
			continue
		}
		select {
		case r := <-respCh:
			if r.Term > term {
				n.mu.Lock()
				n.currentTerm = r.Term
				n.role = roleFollower
				n.votedFor = -1
				n.mu.Unlock()
				return
			}
			if r.Granted {
				votes++
			}
		case <-time.After(200 * time.Millisecond):
		}
	}

	if votes >= n.quorum() {
		n.mu.Lock()
		n.role = roleLeader
		n.leaderID = n.id
		for _, p := range n.peers {
			if p != n.id {
				n.nextIndex[p] = n.lastLogIndex() + 1
				n.matchIndex[p] = 0
			}
		}
		n.mu.Unlock()
		log.Printf("[consensus] 节点 %d 成为 Leader (term=%d, votes=%d/%d)",
			n.id, term, votes, len(n.peers))
		// 空日志确立领导权
		n.mu.Lock()
		n.log = append(n.log, logEntry{Term: n.currentTerm, Index: n.lastLogIndex() + 1})
		n.mu.Unlock()
	}
}

// replicate 向所有 follower 发送 AppendEntries（Leader 调用）
func (n *memoryNode) replicate() {
	n.mu.Lock()
	if n.role != roleLeader {
		n.mu.Unlock()
		return
	}
	term := n.currentTerm
	leaderCommit := n.commitIndex
	type task struct {
		peer       int
		prevIdx    int64
		prevTerm   int64
		entries    []logEntry
	}
	var tasks []task
	for _, p := range n.peers {
		if p == n.id {
			continue
		}
		next := n.nextIndex[p]
		if next == 0 {
			next = 1
		}
		prevIdx := next - 1
		prevTerm := int64(0)
		if prevIdx >= 0 && prevIdx < int64(len(n.log)) {
			prevTerm = n.log[prevIdx].Term
		}
		var ents []logEntry
		if next < int64(len(n.log)) {
			ents = append(ents, n.log[next:]...)
		}
		tasks = append(tasks, task{p, prevIdx, prevTerm, ents})
	}
	n.mu.Unlock()

	for _, t := range tasks {
		respCh := make(chan rpc, 1)
		select {
		case n.outbox[t.peer] <- rpc{Type: rpcAppend, Term: term, From: n.id,
			PrevLogIndex: t.prevIdx, PrevLogTerm: t.prevTerm,
			Entries: t.entries, LeaderCommit: leaderCommit, Resp: respCh}:
		default:
			continue
		}
		select {
		case r := <-respCh:
			if r.Term > term {
				n.mu.Lock()
				n.currentTerm = r.Term
				n.role = roleFollower
				n.votedFor = -1
				n.mu.Unlock()
				return
			}
			n.mu.Lock()
			if r.Success {
				n.matchIndex[t.peer] = r.MatchIndex
				n.nextIndex[t.peer] = r.MatchIndex + 1
				// 推进 commitIndex：多数派 matchIndex 的中位数
				matches := []int64{n.lastLogIndex()}
				for _, p := range n.peers {
					if p == n.id {
						continue
					}
					matches = append(matches, n.matchIndex[p])
				}
				// 排序取中位数
				for i := 1; i < len(matches); i++ {
					for j := i; j > 0 && matches[j] < matches[j-1]; j-- {
						matches[j], matches[j-1] = matches[j-1], matches[j]
					}
				}
				median := matches[(len(matches)-1)/2]
				if median > n.commitIndex && median < int64(len(n.log)) &&
					n.log[median].Term == n.currentTerm {
					n.commitIndex = median
					select {
					case n.commitCh <- struct{}{}:
					default:
					}
				}
			} else if n.nextIndex[t.peer] > 1 {
				n.nextIndex[t.peer]--
			}
			n.mu.Unlock()
		case <-time.After(100 * time.Millisecond):
		}
	}
	n.applyLoop()
}

// applyLoop 将已提交日志应用到状态机
func (n *memoryNode) applyLoop() {
	for {
		n.mu.Lock()
		if n.lastApplied >= n.commitIndex {
			n.mu.Unlock()
			return
		}
		n.lastApplied++
		idx := n.lastApplied
		var cmd *mpcommon.Command
		if idx < int64(len(n.log)) {
			cmd = n.log[idx].Command
		}
		n.mu.Unlock()

		if cmd != nil {
			n.table.Apply(*cmd) // 幂等
		}
	}
}

// handle 处理收到的消息
func (n *memoryNode) handle(msg rpc) {
	switch msg.Type {
	case rpcVote:
		n.mu.Lock()
		grant := false
		if msg.Term > n.currentTerm {
			n.currentTerm = msg.Term
			n.role = roleFollower
			n.votedFor = -1
		}
		logOK := msg.LastLogTerm > n.lastLogTerm() ||
			(msg.LastLogTerm == n.lastLogTerm() && msg.LastLogIndex >= n.lastLogIndex())
		if msg.Term == n.currentTerm && (n.votedFor == -1 || n.votedFor == msg.From) && logOK {
			grant = true
			n.votedFor = msg.From
		}
		term := n.currentTerm
		n.mu.Unlock()
		select {
		case msg.Resp <- rpc{Type: rpcVoteResp, Term: term, Granted: grant}:
		default:
		}

	case rpcAppend:
		n.mu.Lock()
		if msg.Term < n.currentTerm {
			term := n.currentTerm
			n.mu.Unlock()
			select {
			case msg.Resp <- rpc{Type: rpcAppendResp, Term: term, Success: false}:
			default:
			}
			return
		}
		n.currentTerm = msg.Term
		n.role = roleFollower
		n.votedFor = -1
		n.leaderID = msg.From

		// 日志一致性检查
		if msg.PrevLogIndex > n.lastLogIndex() ||
			(msg.PrevLogIndex >= 0 && msg.PrevLogIndex < int64(len(n.log)) &&
				n.log[msg.PrevLogIndex].Term != msg.PrevLogTerm) {
			term := n.currentTerm
			n.mu.Unlock()
			select {
			case msg.Resp <- rpc{Type: rpcAppendResp, Term: term, Success: false}:
			default:
			}
			return
		}

		// 冲突截断 + 追加
		for i, e := range msg.Entries {
			idx := msg.PrevLogIndex + 1 + int64(i)
			if idx < int64(len(n.log)) {
				if n.log[idx].Term != e.Term {
					n.log = n.log[:idx]
				} else {
					continue
				}
			}
			n.log = append(n.log, e)
		}
		if msg.LeaderCommit > n.commitIndex {
			n.commitIndex = msg.LeaderCommit
			if n.commitIndex > n.lastLogIndex() {
				n.commitIndex = n.lastLogIndex()
			}
		}
		term := n.currentTerm
		matchIdx := n.lastLogIndex()
		n.mu.Unlock()

		n.applyLoop()
		select {
		case msg.Resp <- rpc{Type: rpcAppendResp, Term: term, Success: true, MatchIndex: matchIdx}:
		default:
		}
	}
}
