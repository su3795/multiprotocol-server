package consensus

import (
	"fmt"
	"strconv"
	"strings"
)

// Config 集群配置
type Config struct {
	// Mode 共识模式：memory | dragonboat
	Mode string
	// NodeID 本节点 ID（0-based 用于 memory；1-based 用于 dragonboat，内部转换）
	NodeID int
	// Members 成员 ID 列表，逗号分隔，如 "0,1,2"
	Members string
	// NodeAddr 本节点 Raft 地址，如 "127.0.0.1:8081"
	NodeAddr string
	// Peers 全部节点地址，逗号分隔（dragonboat 模式用）
	Peers string
	// DataDir 数据目录
	DataDir string
}

// New 按模式创建共识实现。
//
//   - memory     → 零依赖内存 Raft，默认，开箱可跑
//   - dragonboat → 工业级 Multi-Raft-Group，需 -tags dragonboat 构建
func New(cfg Config) (Consensus, error) {
	switch cfg.Mode {
	case "", "memory":
		return newMemory(cfg)
	case "dragonboat":
		return createDragonboat(cfg)
	default:
		return nil, fmt.Errorf("未知共识模式: %s（可选 memory / dragonboat）", cfg.Mode)
	}
}

// newMemory 创建内存 Raft 集群
func newMemory(cfg Config) (Consensus, error) {
	ids, err := parseIntList(cfg.Members)
	if err != nil {
		return nil, fmt.Errorf("解析 members 失败: %w", err)
	}
	return NewMemoryCluster(MemoryConfig{
		NodeID:   cfg.NodeID,
		Members:  ids,
		NodeAddr: cfg.NodeAddr,
	})
}

// parseIntList 解析 "0,1,2" 形式的成员列表
func parseIntList(s string) ([]int, error) {
	if strings.TrimSpace(s) == "" {
		return nil, fmt.Errorf("成员列表为空")
	}
	parts := strings.Split(s, ",")
	out := make([]int, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		v, err := strconv.Atoi(p)
		if err != nil {
			return nil, fmt.Errorf("非法成员 ID %q", p)
		}
		out = append(out, v)
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("成员列表为空")
	}
	return out, nil
}
