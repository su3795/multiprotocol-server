// Package gateway 对应 Java 版 mp-gateway：多协议接入层。
//
// 与 Java 版的差异：Java 用 Netty 的 EventLoop 处理 IO；
// Go 用 goroutine-per-connection + 标准 net 包，天然支撑高并发，
// 无需额外框架。分层保持一致：分帧 → 路由 → 业务 → 回包。
//
// 协议差异全部收敛在本层：上层 RequestProcessor 只见 Frame，
// 新增协议（QUIC/KCP）只需实现对应的 serve 函数。
package gateway

import (
	"fmt"
	"time"

	"mpc/internal/consensus"
	"mpc/internal/mpcommon"
	"mpc/internal/observability"
)

// RequestProcessor 协议无关的业务处理器。
//
// 与 Java 版 RequestProcessor 行为一致：
//   - 写命令（PUT / ROUTE_SET）必须走共识层，仅 Leader 可写
//   - 读命令（GET / ROUTE_GET）走线性读
//   - PING 不走共识，用于压测纯接入层
//   - 埋点只做原子累加
type RequestProcessor struct {
	consensus consensus.Consensus
}

// NewRequestProcessor 创建处理器
func NewRequestProcessor(c consensus.Consensus) *RequestProcessor {
	return &RequestProcessor{consensus: c}
}

// Process 处理一帧，返回响应帧
func (p *RequestProcessor) Process(req *mpcommon.Frame, proto mpcommon.Protocol) *mpcommon.Frame {
	start := time.Now()
	defer func() {
		observability.ObserveRequestDuration(string(proto), time.Since(start).Seconds())
	}()

	observability.IncRequests(string(proto), mpcommon.CmdName(req.Cmd))
	payload := string(req.Payload)

	switch req.Cmd {
	case mpcommon.CmdPing:
		return resp(req, mpcommon.CodeOK, "PONG")

	case mpcommon.CmdPut:
		if !p.consensus.IsLeader() {
			return resp(req, mpcommon.CodeNotLeader, "not leader, retry on leader")
		}
		k, v, err := mpcommon.ParseKeyValue(payload)
		if err != nil {
			return resp(req, mpcommon.CodeBadRequest, err.Error())
		}
		result, err := p.consensus.Propose(mpcommon.NewPutKv(k, v))
		if err != nil {
			observability.IncProposeErrors()
			return resp(req, mpcommon.CodeInternal, err.Error())
		}
		return resp(req, mpcommon.CodeOK, result)

	case mpcommon.CmdGet:
		v, err := p.consensus.LinearizableGet(payload)
		if err != nil {
			return resp(req, mpcommon.CodeNotLeader, err.Error())
		}
		return resp(req, mpcommon.CodeOK, v)

	case mpcommon.CmdRouteSet:
		if !p.consensus.IsLeader() {
			return resp(req, mpcommon.CodeNotLeader, "not leader")
		}
		k, v, err := mpcommon.ParseKeyValue(payload)
		if err != nil {
			return resp(req, mpcommon.CodeBadRequest, "expect shardId=node")
		}
		var shardID int64
		if _, err := fmt.Sscanf(k, "%d", &shardID); err != nil {
			return resp(req, mpcommon.CodeBadRequest, "shardId 必须为整数")
		}
		result, err := p.consensus.Propose(mpcommon.NewUpsertRoute(shardID, v))
		if err != nil {
			observability.IncProposeErrors()
			return resp(req, mpcommon.CodeInternal, err.Error())
		}
		return resp(req, mpcommon.CodeOK, result)

	case mpcommon.CmdRouteGet:
		var shardID int64
		if _, err := fmt.Sscanf(payload, "%d", &shardID); err != nil {
			return resp(req, mpcommon.CodeBadRequest, "shardId 必须为整数")
		}
		node, ok := p.consensus.StateMachine().Route(shardID)
		if !ok {
			return resp(req, mpcommon.CodeOK, "")
		}
		return resp(req, mpcommon.CodeOK, node)

	case mpcommon.CmdStats:
		stats := fmt.Sprintf("impl=%s, role=%s, leader=%v, connections=%d, kvCount=%d, routeCount=%d",
			p.consensus.Implementation(),
			p.consensus.Role(),
			p.consensus.IsLeader(),
			observability.ConnectionCount(),
			p.consensus.StateMachine().KVCount(),
			p.consensus.StateMachine().RouteCount())
		return resp(req, mpcommon.CodeOK, stats)

	default:
		return resp(req, mpcommon.CodeBadRequest,
			fmt.Sprintf("unknown cmd %d", req.Cmd))
	}
}

// resp 构造响应帧，格式与 Java 版一致："OK|body" 或 "ERR|body"
func resp(req *mpcommon.Frame, code int32, body string) *mpcommon.Frame {
	prefix := "OK|"
	if code != mpcommon.CodeOK {
		prefix = "ERR|"
	}
	return mpcommon.NewFrame(mpcommon.FlagNeedResponse, code, req.Seq,
		[]byte(prefix+body))
}
