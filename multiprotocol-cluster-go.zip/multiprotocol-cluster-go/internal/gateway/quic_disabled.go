//go:build !quic

package gateway

import "fmt"

// ServeQUIC 默认构建下的占位实现。
//
// QUIC 需要外部依赖 github.com/quic-go/quic-go，
// 为保证 `go build` / `go run` 零依赖开箱可跑，默认构建不包含它。
//
// 启用方式：
//
//	go get github.com/quic-go/quic-go
//	go build -tags quic ./...
func ServeQUIC(addr string, p *RequestProcessor) error {
	return fmt.Errorf(
		"QUIC 模式需要以 -tags quic 构建: go build -tags quic ./...\n" +
			"并先在 go.mod 中添加依赖: go get github.com/quic-go/quic-go")
}
