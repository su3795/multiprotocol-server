// Package gateway 的 KCP 实现。
//
// KCP 是一个纯算法的 ARQ（自动重传请求）可靠传输协议，工作在 UDP 之上，
// 以「牺牲 10%~20% 带宽换取 30%~40% 延迟降低」著称。本实现参考
// skywind3000/kcp 的协议规范，用纯标准库完成，零第三方依赖。
//
// 与 TCP 的关键差异（决定了 KCP 的适用场景）：
//   - RTO 不翻倍：超时后 RTO ×1.5（TCP 是 ×2），重传更激进
//   - 选择性重传：只重传真正丢失的段（TCP 会重传该段之后全部数据）
//   - 快速重传：收到后续段 ACK 累计到阈值就立即重传，不等超时
//   - 非退让流控：可关闭拥塞控制，适合实时性优先的场景
//
// 适用场景：实时对战、音视频信令、弱网下的 RPC。
// 不适用：大文件传输（浪费带宽）、对带宽敏感的公网批量传输。
package gateway

import (
	"encoding/binary"
	"errors"
	"log"
	"net"
	"sync"
	"time"

	"mpc/internal/mpcommon"
)

// KCP 协议常量
const (
	ikcpCmdPush = 81 // 推送数据
	ikcpCmdAck  = 82 // 确认
	ikcpCmdWask = 83 // 窗口探测询问
	ikcpCmdWins = 84 // 窗口大小告知
	// ikcpOverhead 单段头部长度：conv(4) cmd(1) frg(1) wnd(2) ts(4) sn(4) una(4) len(4)
	ikcpOverhead = 24

	ikcpMtuDef       = 1400 // 默认 MTU
	ikcpWndSnd       = 32   // 默认发送窗口（段数）
	ikcpWndRcv       = 128  // 默认接收窗口（段数）
	ikcpRtoMin       = 30   // 最小 RTO (ms)
	ikcpRtoDef       = 200  // 默认 RTO (ms)
	ikcpInterval     = 100  // 默认 update 间隔 (ms)
	ikcpDeadLink     = 20   // 判定链路断开的重传次数
	ikcpFastAckLimit = 3    // 快速重传触发阈值
	ikcpMaxFrg       = 255  // 单条消息最大分片数
)

var (
	// ErrKCPClosed 连接已关闭
	ErrKCPClosed = errors.New("kcp: 连接已关闭")
	// ErrKCPTooLarge 消息超过单个 KCP 连接可承载的分片上限
	ErrKCPTooLarge = errors.New("kcp: 消息过大，分片数超过 255")
	// ErrKCPNoData 暂无完整消息
	ErrKCPNoData = errors.New("kcp: 暂无完整消息")
)

// segment KCP 段
type segment struct {
	conv uint32
	cmd  uint8
	frg  uint8 // 分片序号，从 count-1 递减到 0；0 表示最后一个分片
	wnd  uint16
	ts   uint32
	sn   uint32
	una  uint32
	data []byte

	// 发送侧状态
	rto      uint32
	xmit     uint32 // 已发送次数
	resendts uint32 // 下次重传时间戳
	fastack  uint32 // 收到的后续 ACK 计数
}

// encode 编码为字节（小端序，与 KCP 规范一致）
func (seg *segment) encode() []byte {
	buf := make([]byte, ikcpOverhead+len(seg.data))
	binary.LittleEndian.PutUint32(buf[0:], seg.conv)
	buf[4] = seg.cmd
	buf[5] = seg.frg
	binary.LittleEndian.PutUint16(buf[6:], seg.wnd)
	binary.LittleEndian.PutUint32(buf[8:], seg.ts)
	binary.LittleEndian.PutUint32(buf[12:], seg.sn)
	binary.LittleEndian.PutUint32(buf[16:], seg.una)
	binary.LittleEndian.PutUint32(buf[20:], uint32(len(seg.data)))
	copy(buf[ikcpOverhead:], seg.data)
	return buf
}

// itimediff 计算两个 32 位时间戳的有序差值（处理回绕）
func itimediff(later, earlier uint32) int32 {
	return int32(later - earlier)
}

// kcp KCP 控制块。
//
// 并发约定：所有方法**不是**线程安全的，由调用方保证串行访问。
// 接入层（serveKCP）为每个连接分配专属 goroutine 串行驱动，因此无需加锁。
type KCP struct {
	conv uint32
	mtu  uint32
	mss  uint32 // 最大分片负载 = mtu - overhead

	sndUna uint32 // 最小的未确认序号
	sndNxt uint32 // 下一个待发送序号
	rcvNxt uint32 // 下一个待接收序号

	rto     uint32
	minRto  uint32
	srtt    uint32 // 平滑 RTT
	rttval  uint32 // RTT 方差

	sndWnd uint32 // 本地发送窗口
	rcvWnd uint32 // 本地接收窗口
	rmtWnd uint32 // 远端接收窗口
	cwnd   uint32 // 拥塞窗口

	current  uint32 // 当前时间戳(ms)
	interval uint32 // update 间隔(ms)
	tsFlush  uint32 // 下次 flush 时间戳

	sndBuf   []*segment // 已发送未确认
	rcvBuf   []*segment // 乱序接收缓冲
	sndQueue []*segment // 待发送队列
	rcvQueue []*segment // 有序可交付队列

	ackList [][2]uint32 // 待发送的 ACK：{sn, ts}
	ackCount uint32

	// probe 标志
	probeNeedSend uint32 // 需要发送窗口探测
	probeWait     uint32

	deadLink uint32
	xmit     uint32

	state  uint32 // 0 正常，非 0 已关闭
	output func(buf []byte)

	// fastresend：快速重传阈值，0 表示关闭
	fastResend uint32
	noDelay    uint32
}

// newKCP 创建 KCP 控制块
func NewKCP(conv uint32, output func(buf []byte)) *KCP {
	k := &kcp{
		conv:     conv,
		mtu:      ikcpMtuDef,
		sndWnd:   ikcpWndSnd,
		rcvWnd:   ikcpWndRcv,
		rmtWnd:   ikcpWndRcv,
		cwnd:     0,
		rto:      ikcpRtoDef,
		minRto:   ikcpRtoMin,
		interval: ikcpInterval,
		srtt:     0,
		rttval:   0,
		state:    0,
		output:   output,
		// 默认开启 nodelay：低延迟优先
		noDelay:    1,
		fastResend: ikcpFastAckLimit,
	}
	k.mss = k.mtu - ikcpOverhead
	return k
}

// ---------------- 接收侧 ----------------

// input 处理收到的一个 UDP 数据报（可能包含多个 KCP 段）
func (k *KCP) Input(data []byte) error {
	if k.state != 0 {
		return ErrKCPClosed
	}
	oldUna := k.sndUna

	for len(data) >= ikcpOverhead {
		conv := binary.LittleEndian.Uint32(data[0:4])
		if conv != k.conv {
			return errors.New("kcp: conv 不匹配")
		}
		cmd := data[4]
		frg := data[5]
		wnd := binary.LittleEndian.Uint16(data[6:8])
		ts := binary.LittleEndian.Uint32(data[8:12])
		sn := binary.LittleEndian.Uint32(data[12:16])
		una := binary.LittleEndian.Uint32(data[16:20])
		length := binary.LittleEndian.Uint32(data[20:24])

		if len(data) < ikcpOverhead+int(length) {
			return errors.New("kcp: 数据长度不足")
		}
		payload := make([]byte, length)
		copy(payload, data[ikcpOverhead:ikcpOverhead+int(length)])
		data = data[ikcpOverhead+int(length):]

		// 更新远端窗口与 snd_una
		k.rmtWnd = uint32(wnd)
		k.parseUna(una)

		switch cmd {
		case ikcpCmdAck:
			// 收到 ACK：从 sndBuf 移除对应段，更新 RTT
			if itimediff(sn, k.sndUna) < 0 || itimediff(sn, k.sndNxt) >= 0 {
				continue
			}
			for i, seg := range k.sndBuf {
				if sn == seg.sn {
					k.sndBuf = append(k.sndBuf[:i], k.sndBuf[i+1:]...)
					break
				}
			}
			k.updateRTT(uint32(itimediff(k.current, ts)))
			k.shrinkBuf()

		case ikcpCmdPush:
			// 收到数据：先记录待 ACK，再尝试入接收窗口
			if itimediff(sn, k.rcvNxt+uint32(k.rcvWnd)) < 0 {
				k.ackPush(sn, ts)
			}
			if itimediff(sn, k.rcvNxt) >= 0 {
				// 去重后按 sn 有序插入 rcvBuf
				dup := false
				for _, seg := range k.rcvBuf {
					if seg.sn == sn {
						dup = true
						break
					}
				}
				if !dup {
					seg := &segment{
						conv: conv, cmd: cmd, frg: frg, wnd: wnd,
						ts: ts, sn: sn, una: una, data: payload,
					}
					// 插入排序保持 sn 升序
					pos := len(k.rcvBuf)
					for i, s := range k.rcvBuf {
						if itimediff(sn, s.sn) < 0 {
							pos = i
							break
						}
					}
					k.rcvBuf = append(k.rcvBuf, nil)
					copy(k.rcvBuf[pos+1:], k.rcvBuf[pos:])
					k.rcvBuf[pos] = seg
				}
			}

		case ikcpCmdWask:
			// 对端询问窗口大小，标记需要回应
			k.probeNeedSend = 1

		case ikcpCmdWins:
			// 对端告知窗口大小
			k.rmtWnd = uint32(wnd)

		default:
			return errors.New("kcp: 未知命令")
		}

		// 将 rcvBuf 中连续的段移入 rcvQueue
		k.moveRcvBuf()
	}

	// snd_una 前进说明有段被确认，可扩大拥塞窗口
	if itimediff(k.sndUna, oldUna) > 0 {
		if k.cwnd < k.rmtWnd {
			k.cwnd++
		}
	}

	// 收到数据后尽快 flush，降低 ACK 延迟
	k.tsFlush = k.current
	return nil
}

// parseUna 根据对端 una 移除已确认的发送段
func (k *KCP) parseUna(una uint32) {
	rest := k.sndBuf[:0]
	for _, seg := range k.sndBuf {
		if itimediff(seg.sn, una) < 0 {
			// 已确认
			continue
		}
		rest = append(rest, seg)
	}
	k.sndBuf = rest
	k.sndUna = una
}

// ackPush 记录待发送的 ACK
func (k *KCP) ackPush(sn, ts uint32) {
	k.ackList = append(k.ackList, [2]uint32{sn, ts})
	k.ackCount++
}

// moveRcvBuf 将 rcvBuf 中 sn 连续的段移入 rcvQueue
func (k *KCP) moveRcvBuf() {
	for len(k.rcvBuf) > 0 {
		seg := k.rcvBuf[0]
		if seg.sn == k.rcvNxt && uint32(len(k.rcvQueue)) < k.rcvWnd {
			k.rcvBuf = k.rcvBuf[1:]
			k.rcvQueue = append(k.rcvQueue, seg)
			k.rcvNxt++
		} else {
			break
		}
	}
}

// updateRTT 根据 RTT 样本更新 RTO
func (k *KCP) updateRTT(rtt uint32) {
	if k.srtt == 0 {
		k.srtt = rtt
		k.rttval = rtt / 2
	} else {
		delta := rtt - k.srtt
		if delta < 0 {
			delta = -delta
		}
		k.rttval = (3*k.rttval + delta) / 4
		k.srtt = (7*k.srtt + rtt) / 8
	}
	newRto := k.srtt + maxU32(k.interval, 4*k.rttval)
	if newRto < k.minRto {
		newRto = k.minRto
	}
	k.rto = newRto
}

func maxU32(a, b uint32) uint32 {
	if a > b {
		return a
	}
	return b
}

// shrinkBuf 更新 sndUna 为 sndBuf 中最小的 sn
func (k *KCP) shrinkBuf() {
	if len(k.sndBuf) > 0 {
		k.sndUna = k.sndBuf[0].sn
	} else {
		k.sndUna = k.sndNxt
	}
}

// recv 取出一条完整消息。
// 返回 ErrKCPNoData 表示暂无完整的消息（半包或乱序未补齐）。
func (k *KCP) Recv() ([]byte, error) {
	if k.state != 0 {
		return nil, ErrKCPClosed
	}
	if len(k.rcvQueue) == 0 {
		return nil, ErrKCPNoData
	}

	// 找到第一个 frg==0 的段，确定整条消息的长度
	total := 0
	count := 0
	for _, seg := range k.rcvQueue {
		total += len(seg.data)
		count++
		if seg.frg == 0 {
			break
		}
	}
	if count == 0 || k.rcvQueue[count-1].frg != 0 {
		return nil, ErrKCPNoData // 最后一个分片还没到
	}

	out := make([]byte, 0, total)
	for i := 0; i < count; i++ {
		seg := k.rcvQueue[i]
		out = append(out, seg.data...)
	}
	k.rcvQueue = k.rcvQueue[count:]
	return out, nil
}

// ---------------- 发送侧 ----------------

// send 发送一条消息（自动分片）
func (k *KCP) Send(data []byte) error {
	if k.state != 0 {
		return ErrKCPClosed
	}
	mss := int(k.mss)
	count := (len(data) + mss - 1) / mss
	if count == 0 {
		count = 1
	}
	if count > ikcpMaxFrg {
		return ErrKCPTooLarge
	}

	offset := 0
	for i := 0; i < count; i++ {
		size := mss
		if remain := len(data) - offset; remain < size {
			size = remain
		}
		chunk := make([]byte, size)
		copy(chunk, data[offset:offset+size])
		offset += size

		k.sndQueue = append(k.sndQueue, &segment{
			frg: uint8(count - 1 - i), // 最后一个分片 frg=0
			data: chunk,
		})
	}
	return nil
}

// flush 把待发送数据真正发出（应用层不直接调用，由 update 驱动）
func (k *KCP) Flush() {
	if k.state != 0 {
		return
	}
	current := k.current
	buffer := make([]byte, 0, int(k.mtu))
	change := false

	// 1. 发送 ACK
	for i := range k.ackList {
		sn, ts := k.ackList[i][0], k.ackList[i][1]
		seg := &segment{
			conv: k.conv, cmd: ikcpCmdAck, frg: 0,
			wnd: uint32ForWnd(k.rcvWnd, uint32(len(k.rcvQueue))),
			sn:  sn, ts: ts, una: k.rcvNxt,
		}
		buffer = append(buffer, seg.encode()...)
	}
	k.ackList = k.ackList[:0]
	k.ackCount = 0

	// 2. 窗口探测：若远端窗口为 0，主动询问
	if k.rmtWnd == 0 {
		if k.probeWait == 0 {
			k.probeWait = k.interval
			k.probeNeedSend = 1
		} else {
			k.probeWait--
		}
	} else {
		k.probeWait = 0
	}
	if k.probeNeedSend == 1 {
		seg := &segment{
			conv: k.conv, cmd: ikcpCmdWask,
			wnd: uint32ForWnd(k.rcvWnd, uint32(len(k.rcvQueue))),
			una: k.rcvNxt,
		}
		buffer = append(buffer, seg.encode()...)
		k.probeNeedSend = 0
	}

	// 3. 计算可用窗口
	cwnd := k.sndUna + k.cwnd
	if k.cwnd == 0 {
		cwnd = k.sndUna + 1 // 探测一个段
	}
	if k.rmtWnd > 0 && itimediff(k.sndUna+k.rmtWnd, cwnd) < 0 {
		cwnd = k.sndUna + k.rmtWnd
	}

	// 4. 从 sndQueue 移入 sndBuf（受窗口限制）
	for len(k.sndQueue) > 0 {
		if itimediff(k.sndNxt, cwnd) >= 0 {
			break
		}
		seg := k.sndQueue[0]
		k.sndQueue = k.sndQueue[1:]
		seg.conv = k.conv
		seg.cmd = ikcpCmdPush
		seg.wnd = uint32ForWnd(k.rcvWnd, uint32(len(k.rcvQueue)))
		seg.ts = current
		seg.sn = k.sndNxt
		k.sndNxt++
		seg.una = k.rcvNxt
		seg.rto = k.rto
		seg.resendts = current + k.rto
		seg.fastack = 0
		seg.xmit = 0
		k.sndBuf = append(k.sndBuf, seg)
	}

	// 5. 发送 sndBuf 中需要发出的段（首次发送 / 超时重传 / 快速重传）
	for _, seg := range k.sndBuf {
		needSend := false
		if seg.xmit == 0 {
			// 首次发送
			needSend = true
			seg.rto = k.rto
			seg.resendts = current + k.rto
		} else if itimediff(current, seg.resendts) >= 0 {
			// 超时重传：RTO 按 1.5 倍增长（TCP 是 2 倍，KCP 更激进）
			needSend = true
			seg.rto = seg.rto + seg.rto/2
			if seg.rto > 60000 {
				seg.rto = 60000
			}
			seg.resendts = current + seg.rto
			change = true
			k.xmit++
		} else if k.fastResend > 0 && seg.fastack >= k.fastResend {
			// 快速重传：不等超时，立即重发
			needSend = true
			seg.fastack = 0
			seg.resendts = current + seg.rto
			change = true
		}

		if needSend {
			seg.ts = current
			seg.wnd = uint32ForWnd(k.rcvWnd, uint32(len(k.rcvQueue)))
			seg.una = k.rcvNxt
			seg.xmit++
			if seg.xmit >= k.deadLink && k.deadLink > 0 {
				k.state = 1 // 判定链路断开
			}
			buffer = append(buffer, seg.encode()...)
		}
	}

	// 6. 一次性输出（多个段可打包进一个 UDP 数据报）
	if len(buffer) > 0 && k.output != nil {
		k.output(buffer)
	}

	// 7. 链路断开判定后收缩拥塞窗口
	if change && k.noDelay == 0 {
		// 仅在开启退让流控时收缩
		if k.cwnd > 1 {
			k.cwnd = k.cwnd / 2
			if k.cwnd < 1 {
				k.cwnd = 1
			}
		}
	}
}

// uint32ForWnd 计算通告给对端的剩余接收窗口
func uint32ForWnd(rcvWnd, queued uint32) uint16 {
	avail := int32(rcvWnd) - int32(queued)
	if avail < 0 {
		avail = 0
	}
	if avail > 65535 {
		avail = 65535
	}
	return uint16(avail)
}

// update 驱动 KCP 时钟，应在 interval 周期内被调用
func (k *KCP) Update(current uint32) {
	k.current = current
	if k.tsFlush == 0 {
		k.tsFlush = current
	}
	if itimediff(current, k.tsFlush) >= 0 {
		k.tsFlush = current + k.interval
		k.Flush()
	}
}

// ---------------- KCP over UDP 接入层 ----------------

// kcpConn 一个 KCP 连接：专属 goroutine 串行驱动，无需加锁
type kcpConn struct {
	addr  string
	conv  uint32
	kcp   *KCP
	inbox chan []byte
	proc  *RequestProcessor
	send  func(data []byte) error
	done  chan struct{}
}

// serveKCP 启动 KCP 接入（运行在 UDP 之上）。
//
// 与裸 UDP 的差异：KCP 提供可靠、有序、带重传的字节流，
// 因此上层不再需要担心丢包与乱序，但仍保留 UDP 的低延迟特性
// （无队头阻塞、RTO 增长更温和）。
//
// 连接标识：以对端地址 + conv 作为会话键。
func ServeKCP(addr string, p *RequestProcessor) error {
	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return err
	}
	conn, err := net.ListenUDP("udp", udpAddr)
	if err != nil {
		return err
	}
	conn.SetReadBuffer(4 * 1024 * 1024)
	conn.SetWriteBuffer(4 * 1024 * 1024)
	log.Printf("[gateway] KCP 接入已启动(基于 UDP): %s", addr)

	var mu sync.Mutex
	conns := make(map[string]*kcpConn)

	// 收包循环：按来源地址分发给对应的 KCP 连接
	buf := make([]byte, 2048)
	for {
		n, peer, err := conn.ReadFromUDP(buf)
		if err != nil {
			continue
		}
		raw := make([]byte, n)
		copy(raw, buf[:n])
		key := peer.String()

		mu.Lock()
		c, ok := conns[key]
		if !ok {
			// 首个包：从包头读取 conv 建立连接
			if len(raw) < ikcpOverhead {
				mu.Unlock()
				continue
			}
			conv := binary.LittleEndian.Uint32(raw[0:4])
			c = newKCPConn(peer.String(), conv, p, func(data []byte) error {
				_, err := conn.WriteToUDP(data, peer)
				return err
			})
			conns[key] = c
			go c.run()
		}
		mu.Unlock()

		select {
		case c.inbox <- raw:
		default:
			// 队列满则丢弃，KCP 自身会重传
		}
	}
}

func newKCPConn(addr string, conv uint32, p *RequestProcessor,
	send func(data []byte) error) *kcpConn {
	c := &kcpConn{
		addr:  addr,
		conv:  conv,
		proc:  p,
		send:  send,
		inbox: make(chan []byte, 256),
		done:  make(chan struct{}),
	}
	c.kcp = NewKCP(conv, func(buf []byte) {
		_ = c.send(buf)
	})
	return c
}

// run 串行驱动：收包 → input → recv → 业务处理 → send → 定时 update
func (c *kcpConn) run() {
	defer close(c.done)

	start := time.Now()
	nowMs := func() uint32 { return uint32(time.Since(start).Milliseconds()) }

	ticker := time.NewTicker(10 * time.Millisecond) // 10ms 驱动，低于 interval
	defer ticker.Stop()

	for {
		select {
		case packet := <-c.inbox:
			if err := c.kcp.Input(packet); err != nil {
				continue
			}
			// 尽力取出所有完整消息并处理
			c.drainAndProcess()

		case <-ticker.C:
			c.kcp.Update(nowMs())
			c.drainAndProcess()
		}
	}
}

// drainAndProcess 取出完整消息 → 解码帧 → 业务处理 → 回包
func (c *kcpConn) drainAndProcess() {
	for {
		msg, err := c.kcp.Recv()
		if err != nil {
			return // 无完整消息
		}
		frame, err := mpcommon.Decode(msg)
		if err != nil {
			continue
		}
		resp := c.proc.Process(frame, mpcommon.ProtoKCP)
		out, err := mpcommon.Encode(resp)
		if err != nil {
			continue
		}
		_ = c.kcp.Send(out)
	}
}
