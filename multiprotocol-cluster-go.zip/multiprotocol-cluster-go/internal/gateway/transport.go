package gateway

import (
	"log"
	"net"
	"time"

	"mpc/internal/mpcommon"
	"mpc/internal/observability"
)

const readBufSize = 64 * 1024

// ServeTCP 启动 TCP 接入。
//
// TCP 是字节流，需要处理粘包/半包：每条连接维护累积缓冲，
// 用 TryDecode 逐帧切出。对应 Java 版 FrameDecoder 的职责。
func ServeTCP(addr string, p *RequestProcessor) error {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	log.Printf("[gateway] TCP 接入已启动: %s", addr)

	for {
		conn, err := ln.Accept()
		if err != nil {
			return err
		}
		observability.IncConnections()
		go handleTCPConn(conn, p)
	}
}

func handleTCPConn(conn net.Conn, p *RequestProcessor) {
	defer func() {
		conn.Close()
		observability.DecConnections()
	}()
	if tc, ok := conn.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
		tc.SetKeepAlive(true)
	}

	// 累积缓冲：未消费的字节留到下一轮
	var buf []byte
	tmp := make([]byte, readBufSize)

	for {
		conn.SetReadDeadline(time.Now().Add(5 * time.Minute))
		n, err := conn.Read(tmp)
		if err != nil {
			return
		}
		buf = append(buf, tmp[:n]...)

		// 尽最大可能切出完整帧
		for {
			frame, consumed, err := mpcommon.TryDecode(buf)
			if err == mpcommon.ErrTooShort {
				break // 半包：数据不足，等待下一轮 Read 累积
			}
			if err != nil {
				return // 真协议错误（magic 错 / CRC 错 / 长度非法）直接断连
			}
			buf = buf[consumed:]

			response := p.Process(frame, mpcommon.ProtoTCP)
			if frame.NeedResponse() || response != nil {
				out, err := mpcommon.Encode(response)
				if err != nil {
					return
				}
				conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
				if _, err := conn.Write(out); err != nil {
					return
				}
			}
		}
	}
}

// ServeUDP 启动 UDP 接入。
//
// UDP 是数据报，天然分帧、无队头阻塞，直接整包解码即可。
// 注意：UDP 无连接，回包必须携带发送方地址。
func ServeUDP(addr string, p *RequestProcessor) error {
	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return err
	}
	conn, err := net.ListenUDP("udp", udpAddr)
	if err != nil {
		return err
	}
	conn.SetReadBuffer(4 * 1024 * 1024)
	conn.SetWriteBuffer(4 * 1024 * 1024)
	log.Printf("[gateway] UDP 接入已启动: %s", addr)

	buf := make([]byte, 2048)
	for {
		n, peer, err := conn.ReadFromUDP(buf)
		if err != nil {
			continue
		}
		raw := make([]byte, n)
		copy(raw, buf[:n])

		go func(raw []byte, peer *net.UDPAddr) {
			frame, err := mpcommon.Decode(raw)
			if err != nil {
				return // 坏包静默丢弃
			}
			response := p.Process(frame, mpcommon.ProtoUDP)
			out, err := mpcommon.Encode(response)
			if err != nil {
				return
			}
			conn.WriteToUDP(out, peer)
		}(raw, peer)
	}
}

// ServeCustom 启动自定义协议接入（UDP 变体）。
//
// 这里复用 UDP 承载，payload 层可叠加私有混淆/加密。
// 帧格式保持不变，因此与 Java/Rust 版互通。
func ServeCustom(addr string, p *RequestProcessor) error {
	log.Printf("[gateway] CUSTOM 接入已启动(UDP 变体): %s", addr)
	return ServeUDP(addr, p)
}
