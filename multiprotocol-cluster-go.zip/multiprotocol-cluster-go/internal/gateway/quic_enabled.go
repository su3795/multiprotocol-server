//go:build quic

package gateway

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"errors"
	"log"
	"math/big"
	"time"

	"github.com/quic-go/quic-go"

	"mpc/internal/mpcommon"
	"mpc/internal/observability"
)

// ServeQUIC 启动 QUIC 接入（需 -tags quic 构建）。
//
// # 为什么默认不启用
//
// QUIC 需要 github.com/quic-go/quic-go 及 TLS 证书。
// 为保持默认构建零第三方依赖，本文件通过 build tag 隔离。
//
// # QUIC 相比 TCP 的核心优势
//
//   - 0-RTT / 1-RTT 握手：连接建立延迟显著低于 TCP+TLS
//   - 无队头阻塞：多路复用流相互独立，单流丢包不阻塞其他流
//   - 连接迁移：网络切换（WiFi↔4G）时连接不断开
//
// # 与 TCP 接入的差异
//
// QUIC 以「流（stream）」为单位。本实现为每条流独立解析帧，
// 帧格式与 TCP/UDP/KCP 完全一致，因此上层 RequestProcessor 无需改动。
//
// # 证书
//
// QUIC 强制 TLS 1.3。本实现自动生成自签证书（仅供演示），
// 生产环境请替换为真实证书。
func ServeQUIC(addr string, p *RequestProcessor) error {
	tlsConf, err := generateTLSConfig()
	if err != nil {
		return err
	}

	listener, err := quic.ListenAddr(addr, tlsConf, &quic.Config{
		MaxIdleTimeout:  30 * time.Second,
		KeepAlivePeriod: 10 * time.Second,
		MaxStreamReceiveWindow: 6 * 1024 * 1024,
	})
	if err != nil {
		return err
	}
	log.Printf("[gateway] QUIC 接入已启动: %s (自签证书，仅供演示)", addr)

	for {
		conn, err := listener.Accept(context.Background())
		if err != nil {
			log.Printf("[gateway] QUIC accept 失败: %v", err)
			continue
		}
		observability.IncConnections()
		go handleQuicConn(conn, p)
	}
}

// handleQuicConn 处理一个 QUIC 连接，为每条流分配独立协程
func handleQuicConn(conn quic.Connection, p *RequestProcessor) {
	defer func() {
		conn.CloseWithError(0, "bye")
		observability.DecConnections()
	}()

	for {
		stream, err := conn.AcceptStream(context.Background())
		if err != nil {
			return
		}
		go handleQuicStream(stream, p)
	}
}

// handleQuicStream 在单条 QUIC 流上按帧处理。
//
// QUIC 流是字节流，需要像 TCP 一样处理粘包/半包：
// 维护累积缓冲，用 TryDecode 逐帧切出。
func handleQuicStream(stream quic.Stream, p *RequestProcessor) {
	defer stream.Close()

	var acc []byte
	tmp := make([]byte, 64*1024)

	for {
		stream.SetReadDeadline(time.Now().Add(5 * time.Minute))
		n, err := stream.Read(tmp)
		if err != nil {
			return
		}
		acc = append(acc, tmp[:n]...)

		for {
			frame, consumed, err := mpcommon.TryDecode(acc)
			if err == mpcommon.ErrTooShort {
				break // 半包，等待下一轮 Read 累积
			}
			if err != nil {
				return // 协议错误（magic 错 / CRC 错）
			}
			acc = acc[consumed:]

			resp := p.Process(frame, mpcommon.ProtoQUIC)
			out, err := mpcommon.Encode(resp)
			if err != nil {
				return
			}
			stream.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if _, err := stream.Write(out); err != nil {
				return
			}
		}
	}
}

// generateTLSConfig 生成自签 TLS 证书（QUIC 强制 TLS 1.3）。
//
// 仅供演示：客户端需跳过证书校验（InsecureSkipVerify）。
// 生产环境请使用真实 CA 签发的证书。
func generateTLSConfig() (*tls.Config, error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}

	tmpl := x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "mp-server-quic"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(365 * 24 * time.Hour),
		KeyUsage:     x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		DNSNames:     []string{"localhost"},
		IPAddresses:  nil,
		IsCA:         true,
	}

	der, err := x509.CreateCertificate(rand.Reader, &tmpl, &tmpl, &key.PublicKey, key)
	if err != nil {
		return nil, err
	}
	cert, err := x509.ParseCertificate(der)
	if err != nil {
		return nil, err
	}

	return &tls.Config{
		Certificates: []tls.Certificate{{
			Certificate: [][]byte{der},
			PrivateKey:  key,
			Leaf:        cert,
		}},
		MinVersion: tls.VersionTLS13, // QUIC 强制 TLS 1.3
		NextProtos: []string{"mp"},   // ALPN
	}, nil
}

// ErrQUICNotBuilt 保留错误变量，便于调用方区分
var ErrQUICNotBuilt = errors.New("QUIC 未启用，请以 -tags quic 构建")
