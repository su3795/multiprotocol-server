# 多协议集群服务器 · Rust 版

按统一架构方案实现的**可运行 Demo**。与 [Java 版](../multiprotocol-cluster) 严格对齐：
**帧格式、命令字、响应格式、模块划分全部一致**，因此 Rust 服务端可与 Java / Go 客户端互相通信。

---

## 一、模块结构

```
multiprotocol-cluster-rust/
├── Cargo.toml                   # workspace
├── crates/
│   ├── mp-common/               # 帧格式 + 命令模型（零第三方依赖）
│   ├── mp-consensus/            # Consensus trait + 内存 Raft（零依赖）
│   ├── mp-observability/        # 指标 + Prometheus 文本导出（零依赖）
│   ├── mp-gateway/              # Tokio 接入层（TCP/UDP/CUSTOM）
│   └── mp-server/               # 启动器 + 演示客户端
├── docs/VECTORS.md              # 跨语言测试向量
└── scripts/
```

### 与 Java / Go 版的对应关系

| Java 模块 | Rust crate | Go 包 |
|---|---|---|
| `mp-common` | `mp-common` | `internal/mpcommon` |
| `mp-consensus-api` | `mp-consensus` | `internal/consensus` |
| `mp-observability` | `mp-observability` | `internal/observability` |
| `mp-gateway` | `mp-gateway` | `internal/gateway` |
| `mp-launcher` | `mp-server` | `cmd/server` |

---

## 二、设计要点

### 1. 三个 crate 零第三方依赖

`mp-common` / `mp-consensus` / `mp-observability` **不依赖任何外部 crate**：

- CRC32 自行实现（IEEE 802.3，poly `0xEDB88320`）
- 指标用原子变量 + 分桶直方图自实现
- 共识层用 `std::thread` + `std::sync::mpsc`

只有接入层（`mp-gateway`）与启动器需要 **Tokio**。
这样即便网络受限，核心逻辑也能构建与测试。

### 2. 异步安全：共识调用必须 `spawn_blocking`

共识层的 `propose` 基于 `std::thread`，是**同步阻塞**的。
Tokio 接入层调用时一律用 `spawn_blocking` 包裹：

```rust
tokio::task::spawn_blocking(move || c.propose(cmd)).await
```

**原因**：在 Tokio 任务里直接阻塞会卡住同核上的其他异步任务，
导致 P999 延迟爆炸 —— 这是 Rust 异步服务最容易踩的坑。

### 3. 死锁规避

内存 Raft 的节点间通信遵循「**锁内快照 → 锁外通信 → 锁内更新**」，
绝不在持有锁时等待其他节点响应。

---

## 三、快速开始

### 前置条件

| 组件 | 版本 |
|---|---|
| Rust | **1.70+**（用到 let-else） |
| 网络 | 首次构建需拉取 Tokio |

### 构建

```bash
cd multiprotocol-cluster-rust
cargo build --release      # 或 ./scripts/build.sh
```

产物：`target/release/mp-server`

### 契约自测

```bash
./scripts/test.sh
# 或
cargo test -p mp-common -p mp-consensus
```

验证帧编解码与 Java / Go 版**字节级一致**（见 `docs/VECTORS.md`）。

### 启动

```bash
./scripts/start.sh
# 或
./target/release/mp-server --node-id 0 --tcp 127.0.0.1:9101 \
    --udp 127.0.0.1:9201 --custom 127.0.0.1:9301 --metrics-port 9091
```

### 端到端验证

```bash
./target/release/mp-server client --proto tcp --port 9101
./target/release/mp-server client --proto udp --port 9201
```

预期输出：

```
=== 演示客户端 · TCP → 127.0.0.1:9101 ===
PING       → OK|PONG
PUT        → OK|applied, cost=980us
PUT        → OK|applied, cost=520us
GET        → OK|alice
ROUTE_SET  → OK|applied, cost=740us
ROUTE_GET  → OK|node-3
STATS      → OK|impl=MemoryRaft(Rust), role=LEADER, leader=true, connections=1, kvCount=2, routeCount=1
```

### 查看指标

```bash
curl http://127.0.0.1:9091/metrics | grep ^mp_
```

### 一键演示

```bash
./scripts/e2e.sh    # 构建 → 启动 → TCP/UDP → 抓指标
./scripts/stop.sh   # 停止
```

---

## 四、帧格式

与 Java / Go 版完全一致：

```
┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
│ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
│ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
└────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
```

- `magic` = `0x4D50`，大端序
- `crc32` 覆盖 `[offset 2, 2+18+len)`

### 命令字

| cmd | 名称 | 走共识 | 说明 |
|---|---|---|---|
| 1 | `PUT` | ✅ 写 | 写 KV，仅 Leader 可写 |
| 2 | `GET` | ✅ 线性读 | 线性一致读 |
| 3 | `ROUTE_SET` | ✅ 写 | 设置 `shard → node` |
| 4 | `ROUTE_GET` | 本地读 | 读路由表 |
| 5 | `PING` | ❌ | 测纯接入层延迟 |
| 6 | `STATS` | ❌ | 节点状态 |

---

## 五、与 Java / Go 版的实现差异

| 维度 | Java 版 | Go 版 | Rust 版 |
|---|---|---|---|
| IO 模型 | Netty EventLoop | goroutine-per-conn | Tokio 异步任务 |
| 分帧 | `ByteToMessageDecoder` | `TryDecode` | `try_decode` + `Vec::drain` |
| 共识（生产） | SOFAJRaft | dragonboat | openraft（可扩展） |
| 共识（默认） | - | 内存 Raft | 内存 Raft（`std::thread`） |
| 状态机并发 | 自行决定 | `sync.RWMutex` | `std::sync::RwLock` |
| 依赖 | 多 | 默认零 | 3/5 crate 零依赖 |

---

## 六、扩展新协议

新增协议只需：

1. 实现 `serve_quic` / `serve_kcp` 函数
2. 在 `mp-server/src/main.rs` 中 `tokio::spawn` 启动

`RequestProcessor::process` 只认 `Frame`，不感知底层协议。
`Protocol` 枚举已预留 `Quic` / `Kcp` / `Custom`。

### 接入 openraft（生产路径）

本 demo 默认用内嵌 Raft 保证可运行。若要换成工业级 openraft：

1. 在 `mp-consensus/Cargo.toml` 添加 `openraft = { version = "0.9", features = ["storage-v2"] }`
2. 实现 `RaftNetwork` / `RaftStorage` / `RaftStateMachine`
   （参考 [openraft 官方 example](https://github.com/databendlabs/openraft/tree/main/examples)）
3. 让新实现同样满足 `Consensus` trait

上层 `mp-gateway` 与 `mp-server` **无需任何改动**。

---

## 七、⚠️ 验证状态

**本项目未在真实环境中编译与运行验证。**

生成环境的限制：

| 限制 | 影响 |
|---|---|
| 无 Rust 工具链（无 cargo / rustc） | 无法 `cargo build` / `cargo test` |
| 外网不可达（crates.io / apt 均 403） | 无法安装 Rust |

已完成的自检：

- ✅ 跨 crate 符号引用全部可解析
- ✅ 括号与泛型平衡
- ✅ **CRC32 实现已用独立脚本验证**：与标准 CRC32(IEEE) 在 9 组测试数据上完全一致
- ✅ **帧编码已验证**：用 Python 复刻 Rust 编码逻辑，6 组用例与 Java 基准字节相同
- ✅ 内存 Raft 的锁序已复核（锁内快照 → 锁外通信 → 锁内更新）

**首次构建请按此顺序排查**：

```bash
cargo check                      # 1. 最快暴露编译错误
cargo test -p mp-common          # 2. 零依赖契约测试
cargo build --release            # 3. 全量构建
./scripts/e2e.sh                 # 4. 端到端
```

### 可能需要调整的地方

1. **Rust 版本**：用到了 let-else（`let Some(x) = ... else { ... }`），需 **1.65+**；
   建议 1.70+。
2. **Tokio 特性**：`Cargo.toml` 声明了 `net, rt-multi-thread, sync, time, macros, io-util`。
   若遗漏 `rt-multi-thread`，`spawn_blocking` 无法工作。
3. **未使用变量警告**：部分字段标记了 `#[allow(dead_code)]`（如 `LogEntry::index`、
   `NodeState::leader_id`），这是有意为之——保留字段语义完整性。
4. **Aeron/共享内存**：本版不涉及。若参考 Java Aeron 版，注意 `/dev/shm` 大小。

---

---

## 八、KCP（可靠 UDP）实现说明

> 这是原始需求里明确要求的一项。KCP 不是占位，而是**完整实现**的 ARQ 协议。

### 为什么需要它

| 场景 | TCP | UDP | KCP |
|---|---|---|---|
| 弱网丢包 5% | 队头阻塞，延迟飙升 | 直接丢包 | ✅ 选择性重传，延迟可控 |
| 实时对战/信令 | 太慢 | 不可靠 | ✅ 可靠 + 低延迟 |
| 大文件/带宽敏感 | ✅ 最省 | - | ❌ 多耗 10~20% 带宽 |

**KCP 用带宽换延迟**：RTO 按 ×1.5 增长（TCP 是 ×2）、只重传真正丢失的段
（TCP 会重传该段之后全部数据）、支持快速重传不等超时。

### 实现位置

| 版本 | 文件 |
|---|---|
| Go | `internal/gateway/kcp.go` |
| Rust | `crates/mp-gateway/src/kcp.rs` |

两版**线格式完全一致**（小端序、24 字节段头），因此可互通：
Go 客户端可以直接连 Rust 的 KCP 服务端。

### 验证状态

用 Python 独立复刻同一套算法做了交叉验证：

- ✅ 5000 字节消息自动分为 4 个分片，重组后与原文逐字节相同
- ✅ 连续丢弃 3 轮数据包后，通过重传最终完整恢复（3000 字节）
- ✅ 段格式：小端序 conv、`cmd=81(PUSH)`、24 字节头
- ✅ Go / Rust 两版 12 个协议常量全部一致

### 启动

```bash
--kcp :9401          # Go
--kcp 127.0.0.1:9401 # Rust
```

客户端：

```bash
./bin/mp-client --proto kcp --port 9401                    # Go
./target/release/mp-server client --proto kcp --port 9401  # Rust
```

### 使用要点（容易踩坑）

1. **必须周期性 `update`**：KCP 靠时钟驱动重传与 ACK，接入层用 10ms
   ticker 驱动（`interval=100ms`）。不驱动就等于没有重传。
2. **会话靠 conv 区分**：服务端从接收到的首个包的前 4 字节读取 conv，
   并以「对端地址 + conv」作为会话键。客户端示例固定用 `0x11223344`。
3. **单条消息上限**：分片数最多 255，即约 `255 × 1376 ≈ 345KB`。
   超过返回 `TooLarge`。
4. **不适用大文件**：KCP 以带宽换延迟，批量传输请用 TCP。

---

## 协议支持矩阵（已补全）

| 协议 | Java | Go | Rust | 默认启用 | 说明 |
|---|:---:|:---:|:---:|:---:|---|
| TCP | ✅ | ✅ | ✅ | ✅ | 流式，需处理粘包/半包 |
| UDP | ✅ | ✅ | ✅ | ✅ | 数据报，天然分帧 |
| **KCP** | ✅ 新增 | ✅ | ✅ | ✅ | 可靠 UDP（ARQ），零依赖自实现 |
| **CUSTOM** | ✅ 新增 | ✅ | ✅ | ✅ | UDP 变体 + 可插拔 payload 变换 |
| **QUIC** | ✅ 新增 | ✅ 新增 | ✅ 新增 | ❌ 可选 | 需外部库与 TLS 证书 |

### 统一端口

| 协议 | 端口 |
|---|---|
| TCP | 9101 |
| UDP | 9201 |
| CUSTOM | 9301 |
| KCP | 9401 |
| QUIC | 9501（可选） |
| metrics | 9091 |

### QUIC 为什么默认关闭

QUIC 需要额外依赖与 TLS 1.3 证书，与「默认零依赖、开箱可跑」冲突。
三版均通过**构建开关**隔离，不影响默认构建：

| 版本 | 启用方式 | 依赖 |
|---|---|---|
| Java | `mvn -Pquic clean package` | `netty-incubator-codec-quic` |
| Go | `make build-quic`（`-tags quic`） | `quic-go` |
| Rust | `cargo build --features quic` | `quinn` + `rustls` + `rcgen` |

Java 版未指定 `--quic-port` 时不加载任何 QUIC 代码（反射探测）；
Go/Rust 版未启用开关时给出明确错误提示而非静默失败。

### QUIC 核心优势

- **0-RTT / 1-RTT 握手**：连接建立延迟显著低于 TCP+TLS
- **无队头阻塞**：多路复用流相互独立，单流丢包不阻塞其他流
- **连接迁移**：网络切换（WiFi↔4G）时连接不断开

### 各协议适用场景

| 场景 | 推荐协议 | 理由 |
|---|---|---|
| 常规 RPC / 元数据 | TCP | 最省带宽，生态最成熟 |
| 高频低价值数据（埋点、位置同步） | UDP | 允许少量丢失换低延迟 |
| 弱网实时（对战、音视频信令） | **KCP** | 选择性重传，延迟可控 |
| 移动端 / 需要连接迁移 | **QUIC** | 网络切换不断线 |
| 需私有混淆加密 | **CUSTOM** | 可插拔 payload 变换 |
| 大文件、带宽敏感 | TCP | KCP 多耗 10~20% 带宽，不划算 |

### ⚠️ QUIC 的验证状态

QUIC 是三版中**唯一完全未验证**的部分（连静态检查都覆盖不到，因为
默认构建会跳过它）。原因：

- 需要 `quic-go` / `quinn` / `netty-incubator-codec-quic` 外部库
- 沙盒无工具链、无网络，无法拉取依赖也无法编译

**已知风险点**：

1. **quinn 版本差异**：0.10 与 0.11 的 `Endpoint::server` 签名不同
   （0.10 返回 `(Endpoint, Incoming)`，0.11 改为 `Endpoint::accept`）。
   本实现基于 **0.10**，用 0.11 需对照官方 example 调整。
2. **quic-go API**：`quic.ListenAddr` / `AcceptStream` 在不同版本有变动。
3. **netty QUIC**：`QuicServerCodecBuilder` API 在 0.0.x 各版本间有调整。

启用 QUIC 时请优先对照各库官方 example 核对 API 签名。

## License

参考实现，可自由使用与修改。
