//! mp-common — 统一帧格式与命令模型。
//!
//! 对应 Java 版 `mp-common`，与 Go 版 `internal/mpcommon` 字节级一致。
//!
//! # 帧结构
//!
//! ```text
//! ┌────────┬─────────┬───────┬──────┬──────┬────────┬─────────┬───────┐
//! │ magic  │ version │ flags │ cmd  │ seq  │ length │ payload │ crc32 │
//! │ 2B     │ 1B      │ 1B    │ 4B   │ 8B   │ 4B     │ N B     │ 4B    │
//! └────────┴─────────┴───────┴──────┴──────┴────────┴─────────┴───────┘
//!                         头部固定 20B                      尾部 4B
//! ```
//!
//! - `magic` 固定 `0x4D50`（"MP"），全部整数**大端序**
//! - `crc32` 覆盖 `[offset 2, 2+18+len)`，即从 version 到 payload 结束
//!   （不含 magic 与 crc 本身）
//!
//! **本 crate 零第三方依赖**：CRC32 自行实现，确保离线也能构建与测试。

// ---------------- 帧格式 ----------------

/// 帧起始标记 `'M''P'`
pub const MAGIC: u16 = 0x4D50;
/// 头部固定长度
pub const HEADER_SIZE: usize = 20;
/// 尾部 CRC32 长度
pub const CRC32_SIZE: usize = 4;
/// 协议版本
pub const VERSION: u8 = 1;
/// 单帧 payload 上限 1 MiB
pub const MAX_PAYLOAD: usize = 1 << 20;

/// 标志位：需要响应
pub const FLAG_NEED_RESPONSE: u8 = 0x01;
/// 标志位：已压缩
pub const FLAG_COMPRESSED: u8 = 0x02;
/// 标志位：已加密
pub const FLAG_ENCRYPTED: u8 = 0x04;

// 命令字（与 Java io.mp.gateway.Cmd 一致）
/// 写 KV（走共识，仅 Leader 可写）
pub const CMD_PUT: i32 = 1;
/// 线性一致读 KV
pub const CMD_GET: i32 = 2;
/// 设置分片路由（走共识）
pub const CMD_ROUTE_SET: i32 = 3;
/// 读分片路由
pub const CMD_ROUTE_GET: i32 = 4;
/// 心跳，不走共识
pub const CMD_PING: i32 = 5;
/// 查询节点状态
pub const CMD_STATS: i32 = 6;

// 响应码
/// 成功
pub const CODE_OK: i32 = 0;
/// 非 Leader
pub const CODE_NOT_LEADER: i32 = 1;
/// 请求格式错误
pub const CODE_BAD_REQUEST: i32 = 2;
/// 内部错误
pub const CODE_INTERNAL: i32 = 3;

/// 命令字可读名
pub fn cmd_name(cmd: i32) -> &'static str {
    match cmd {
        CMD_PUT => "PUT",
        CMD_GET => "GET",
        CMD_ROUTE_SET => "ROUTE_SET",
        CMD_ROUTE_GET => "ROUTE_GET",
        CMD_PING => "PING",
        CMD_STATS => "STATS",
        _ => "UNKNOWN",
    }
}

/// 传输协议
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Protocol {
    Tcp,
    Udp,
    Quic,
    Kcp,
    Custom,
}

impl Protocol {
    pub fn as_str(&self) -> &'static str {
        match self {
            Protocol::Tcp => "TCP",
            Protocol::Udp => "UDP",
            Protocol::Quic => "QUIC",
            Protocol::Kcp => "KCP",
            Protocol::Custom => "CUSTOM",
        }
    }
}

/// 一帧
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Frame {
    pub version: u8,
    pub flags: u8,
    pub cmd: i32,
    pub seq: i64,
    pub payload: Vec<u8>,
}

impl Frame {
    /// 构造请求帧
    pub fn new(flags: u8, cmd: i32, seq: i64, payload: Vec<u8>) -> Self {
        Self { version: VERSION, flags, cmd, seq, payload }
    }

    /// 是否需要响应
    pub fn need_response(&self) -> bool { self.flags & FLAG_NEED_RESPONSE != 0 }
    /// 是否压缩
    pub fn compressed(&self) -> bool { self.flags & FLAG_COMPRESSED != 0 }
    /// 是否加密
    pub fn encrypted(&self) -> bool { self.flags & FLAG_ENCRYPTED != 0 }
    /// 编码后总长度
    pub fn encoded_length(&self) -> usize { HEADER_SIZE + self.payload.len() + CRC32_SIZE }
}

// ---------------- CRC32 (IEEE 802.3, poly 0xEDB88320) ----------------

/// 计算 CRC32。与 Java `java.util.zip.CRC32`、Go `crc32.ChecksumIEEE` 结果一致。
pub fn crc32(data: &[u8]) -> u32 {
    let mut crc: u32 = 0xFFFF_FFFF;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            crc = if crc & 1 != 0 { (crc >> 1) ^ 0xEDB8_8320 } else { crc >> 1 };
        }
    }
    !crc
}

// ---------------- 编解码 ----------------

/// 编码错误
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FrameError {
    /// payload 超过上限
    PayloadTooLarge(usize),
}

/// 解码错误
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DecodeError {
    /// 数据不足一整帧（半包）
    TooShort,
    /// magic 不匹配
    BadMagic { want: u16, got: u16 },
    /// payload 长度非法
    BadLength(i64),
    /// CRC32 校验失败
    BadCrc { want: u32, got: u32 },
}

impl std::fmt::Display for DecodeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DecodeError::TooShort => write!(f, "数据不足一整帧"),
            DecodeError::BadMagic { want, got } =>
                write!(f, "magic 不匹配: 期望 {want:#06X} 实际 {got:#06X}"),
            DecodeError::BadLength(n) => write!(f, "payload 长度非法: {n}"),
            DecodeError::BadCrc { want, got } =>
                write!(f, "crc32 校验失败: 期望 {want:#010X} 实际 {got:#010X}"),
        }
    }
}

impl std::error::Error for DecodeError {}

/// 编码为完整字节（含 magic 与 crc32）
pub fn encode(f: &Frame) -> Result<Vec<u8>, FrameError> {
    if f.payload.len() > MAX_PAYLOAD {
        return Err(FrameError::PayloadTooLarge(f.payload.len()));
    }
    let len = f.payload.len();
    let total = HEADER_SIZE + len + CRC32_SIZE;
    let mut buf = vec![0u8; total];

    buf[0..2].copy_from_slice(&MAGIC.to_be_bytes());
    buf[2] = f.version;
    buf[3] = f.flags;
    buf[4..8].copy_from_slice(&(f.cmd as u32).to_be_bytes());
    buf[8..16].copy_from_slice(&(f.seq as u64).to_be_bytes());
    buf[16..20].copy_from_slice(&(len as u32).to_be_bytes());
    buf[HEADER_SIZE..HEADER_SIZE + len].copy_from_slice(&f.payload);

    // 与 Java 一致：覆盖 offset 2 起、长度 18+len
    let crc = crc32(&buf[2..HEADER_SIZE + len]);
    buf[total - CRC32_SIZE..].copy_from_slice(&crc.to_be_bytes());
    Ok(buf)
}

/// 解码一帧（入参须为从 magic 开始的完整帧）
pub fn decode(data: &[u8]) -> Result<Frame, DecodeError> {
    if data.len() < HEADER_SIZE + CRC32_SIZE {
        return Err(DecodeError::TooShort);
    }
    let got_magic = u16::from_be_bytes([data[0], data[1]]);
    if got_magic != MAGIC {
        return Err(DecodeError::BadMagic { want: MAGIC, got: got_magic });
    }
    let payload_len = i32::from_be_bytes([data[16], data[17], data[18], data[19]]) as i64;
    if payload_len < 0 || payload_len as usize > data.len() - HEADER_SIZE - CRC32_SIZE {
        return Err(DecodeError::BadLength(payload_len));
    }
    let len = payload_len as usize;
    let total = HEADER_SIZE + len + CRC32_SIZE;

    let want = u32::from_be_bytes([
        data[total - 4], data[total - 3], data[total - 2], data[total - 1],
    ]);
    let got = crc32(&data[2..HEADER_SIZE + len]);
    if want != got {
        return Err(DecodeError::BadCrc { want, got });
    }

    Ok(Frame {
        version: data[2],
        flags: data[3],
        cmd: i32::from_be_bytes([data[4], data[5], data[6], data[7]]),
        seq: i64::from_be_bytes([
            data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15],
        ]),
        payload: data[HEADER_SIZE..HEADER_SIZE + len].to_vec(),
    })
}

/// 从累积缓冲中尝试切出一帧（TCP 流式分帧）。
///
/// 数据不足返回 `Err(DecodeError::TooShort)`，调用方应继续累积。
pub fn try_decode(acc: &[u8]) -> Result<(Frame, usize), DecodeError> {
    if acc.len() < HEADER_SIZE {
        return Err(DecodeError::TooShort);
    }
    let got_magic = u16::from_be_bytes([acc[0], acc[1]]);
    if got_magic != MAGIC {
        return Err(DecodeError::BadMagic { want: MAGIC, got: got_magic });
    }
    let payload_len = i32::from_be_bytes([acc[16], acc[17], acc[18], acc[19]]) as i64;
    if payload_len < 0 {
        return Err(DecodeError::BadLength(payload_len));
    }
    let total = HEADER_SIZE + payload_len as usize + CRC32_SIZE;
    if acc.len() < total {
        return Err(DecodeError::TooShort);
    }
    let f = decode(&acc[..total])?;
    Ok((f, total))
}

/// 从至少 HEADER_SIZE 字节的缓冲中读出整帧长度
pub fn peek_frame_length(head: &[u8]) -> usize {
    HEADER_SIZE + i32::from_be_bytes([head[16], head[17], head[18], head[19]]) as usize + CRC32_SIZE
}

#[cfg(test)]
mod tests {
    use super::*;

    fn h(v: Vec<u8>) -> String {
        v.iter().map(|b| format!("{b:02X}")).collect::<Vec<_>>().join(" ")
    }

    #[test]
    fn encode_put_matches_java_vector() {
        let f = Frame::new(FLAG_NEED_RESPONSE, CMD_PUT, 1, b"user:1=alice".to_vec());
        let b = encode(&f).unwrap();
        assert_eq!(h(b), "4D 50 01 01 00 00 00 01 00 00 00 00 00 00 00 01 00 00 00 0C \
                          75 73 65 72 3A 31 3D 61 6C 69 63 65 96 17 BE 24");
    }

    #[test]
    fn encode_get_matches_java_vector() {
        let f = Frame::new(FLAG_NEED_RESPONSE, CMD_GET, 2, b"user:1".to_vec());
        let b = encode(&f).unwrap();
        assert_eq!(h(b), "4D 50 01 01 00 00 00 02 00 00 00 00 00 00 00 02 00 00 00 06 \
                          75 73 65 72 3A 31 3C F8 AC F8");
    }

    #[test]
    fn encode_empty_payload_matches_java_vector() {
        let f = Frame::new(FLAG_NEED_RESPONSE, CMD_STATS, 4, vec![]);
        let b = encode(&f).unwrap();
        assert_eq!(h(b), "4D 50 01 01 00 00 00 06 00 00 00 00 00 00 00 04 \
                          00 00 00 00 5A 8A CB F2");
    }

    #[test]
    fn encode_large_seq_is_big_endian() {
        let f = Frame::new(FLAG_NEED_RESPONSE, CMD_PUT, 0x0102_0304_0506_0708, b"k=v".to_vec());
        let b = encode(&f).unwrap();
        assert_eq!(h(b), "4D 50 01 01 00 00 00 01 01 02 03 04 05 06 07 08 \
                          00 00 00 03 6B 3D 76 BD FC 19 D7");
    }

    #[test]
    fn decode_round_trip() {
        let orig = Frame::new(FLAG_NEED_RESPONSE | FLAG_COMPRESSED, CMD_ROUTE_SET, 99,
                              b"7=node-3".to_vec());
        let b = encode(&orig).unwrap();
        let got = decode(&b).unwrap();
        assert_eq!(got, orig);
        assert!(got.compressed() && got.need_response());
        assert!(!got.encrypted());
    }

    #[test]
    fn decode_rejects_bad_magic() {
        let mut b = encode(&Frame::new(0, CMD_PING, 1, b"x".to_vec())).unwrap();
        b[0] = 0x00;
        assert!(matches!(decode(&b), Err(DecodeError::BadMagic { .. })));
    }

    #[test]
    fn decode_rejects_corrupted_payload() {
        let mut b = encode(&Frame::new(0, CMD_PING, 1, b"hello".to_vec())).unwrap();
        b[HEADER_SIZE] ^= 0xFF;
        assert!(matches!(decode(&b), Err(DecodeError::BadCrc { .. })));
    }

    #[test]
    fn try_decode_half_packet() {
        let b = encode(&Frame::new(0, CMD_PUT, 1, b"half packet".to_vec())).unwrap();
        assert!(matches!(try_decode(&b[..HEADER_SIZE + 3]), Err(DecodeError::TooShort)));
    }

    #[test]
    fn try_decode_sticky_packet() {
        let a = encode(&Frame::new(0, CMD_PUT, 1, b"a=1".to_vec())).unwrap();
        let b = encode(&Frame::new(0, CMD_GET, 2, b"a".to_vec())).unwrap();
        let mut stream = a.clone();
        stream.extend_from_slice(&b);

        let (f1, n1) = try_decode(&stream).unwrap();
        assert_eq!(f1.seq, 1);
        assert_eq!(n1, a.len());

        let (f2, n2) = try_decode(&stream[n1..]).unwrap();
        assert_eq!(f2.seq, 2);
        assert_eq!(n2, b.len());
    }

    #[test]
    fn crc32_matches_known_values() {
        // CRC32("") = 0, CRC32("a") = 0xE8B7BE43, CRC32("123456789") = 0xCBF43926
        assert_eq!(crc32(b""), 0x0000_0000);
        assert_eq!(crc32(b"a"), 0xE8B7_BE43);
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    }
}

#[cfg(test)]
mod golden;
