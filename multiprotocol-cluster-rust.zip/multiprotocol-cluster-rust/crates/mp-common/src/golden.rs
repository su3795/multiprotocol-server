//! golden 向量测试 —— 由参考实现（Node.js）生成，经 Python 独立复刻交叉验证。
//!
//! 用例来源: reference-impl/golden/frames.json
//! 三版（Java/Go/Rust）编码结果必须逐字节一致。

#[cfg(test)]
mod golden {
    use super::*;

    #[test]
    fn golden_empty_ping() {
        let f = Frame::new(0x01, 5, 1, b"".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d500101000000050000000000000001000000002fa0284c", "golden 向量 empty_ping 不匹配");
        let _ = "4d 50 01 01 00 00 00 05 00 00 00 00 00 00 00 01 00 00 00 00 2f a0 28 4c";
    }

    #[test]
    fn golden_ping_hello() {
        let f = Frame::new(0x01, 5, 2, b"hello".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d5001010000000500000000000000020000000568656c6c6fbe0bdba2", "golden 向量 ping_hello 不匹配");
        let _ = "4d 50 01 01 00 00 00 05 00 00 00 00 00 00 00 02 00 00 00 05 68 65 6c 6c 6f be 0b db a2";
    }

    #[test]
    fn golden_put_kv() {
        let f = Frame::new(0x01, 1, 3, b"user:1=alice".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d5001010000000100000000000000030000000c757365723a313d616c696365422b2ee3", "golden 向量 put_kv 不匹配");
        let _ = "4d 50 01 01 00 00 00 01 00 00 00 00 00 00 00 03 00 00 00 0c 75 73 65 72 3a 31 3d 61 6c 69 63 65 42 2b 2e e3";
    }

    #[test]
    fn golden_get_key() {
        let f = Frame::new(0x01, 2, 4, b"user:1".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010100000002000000000000000400000006757365723a31d44d66bb", "golden 向量 get_key 不匹配");
        let _ = "4d 50 01 01 00 00 00 02 00 00 00 00 00 00 00 04 00 00 00 06 75 73 65 72 3a 31 d4 4d 66 bb";
    }

    #[test]
    fn golden_route_set() {
        let f = Frame::new(0x01, 3, 5, b"7=node-3".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010100000003000000000000000500000008373d6e6f64652d333a115965", "golden 向量 route_set 不匹配");
        let _ = "4d 50 01 01 00 00 00 03 00 00 00 00 00 00 00 05 00 00 00 08 37 3d 6e 6f 64 65 2d 33 3a 11 59 65";
    }

    #[test]
    fn golden_route_get() {
        let f = Frame::new(0x01, 4, 6, b"7".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010100000004000000000000000600000001378ceb079e", "golden 向量 route_get 不匹配");
        let _ = "4d 50 01 01 00 00 00 04 00 00 00 00 00 00 00 06 00 00 00 01 37 8c eb 07 9e";
    }

    #[test]
    fn golden_stats() {
        let f = Frame::new(0x01, 6, 7, b"".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d500101000000060000000000000007000000001d2ab122", "golden 向量 stats 不匹配");
        let _ = "4d 50 01 01 00 00 00 06 00 00 00 00 00 00 00 07 00 00 00 00 1d 2a b1 22";
    }

    #[test]
    fn golden_utf8_chinese() {
        let f = Frame::new(0x01, 1, 8, b"\u540d\u5b57=\u5f20\u4e09".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d5001010000000100000000000000080000000de5908de5ad973de5bca0e4b8899fb3a2ea", "golden 向量 utf8_chinese 不匹配");
        let _ = "4d 50 01 01 00 00 00 01 00 00 00 00 00 00 00 08 00 00 00 0d e5 90 8d e5 ad 97 3d e5 bc a0 e4 b8 89 9f b3 a2 ea";
    }

    #[test]
    fn golden_large_seq() {
        let f = Frame::new(0x01, 2, 9007199254740991, b"k".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010100000002001fffffffffffff000000016b5cab6f88", "golden 向量 large_seq 不匹配");
        let _ = "4d 50 01 01 00 00 00 02 00 1f ff ff ff ff ff ff 00 00 00 01 6b 5c ab 6f 88";
    }

    #[test]
    fn golden_binary_payload() {
        let f = Frame::new(0x01, 1, 9, b"a\x00b\xffc".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010100000001000000000000000900000006610062c3bf63006087cf", "golden 向量 binary_payload 不匹配");
        let _ = "4d 50 01 01 00 00 00 01 00 00 00 00 00 00 00 09 00 00 00 06 61 00 62 c3 bf 63 00 60 87 cf";
    }

    #[test]
    fn golden_flag_compressed() {
        let f = Frame::new(0x02, 5, 10, b"x".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010200000005000000000000000a00000001786ac3a7f0", "golden 向量 flag_compressed 不匹配");
        let _ = "4d 50 01 02 00 00 00 05 00 00 00 00 00 00 00 0a 00 00 00 01 78 6a c3 a7 f0";
    }

    #[test]
    fn golden_flag_all() {
        let f = Frame::new(0x07, 5, 11, b"y".to_vec());
        let b = encode(&f).unwrap();
        let got: String = b.iter().map(|x| format!("{:02x}", x)).collect();
        assert_eq!(got, "4d50010700000005000000000000000b000000017932622524", "golden 向量 flag_all 不匹配");
        let _ = "4d 50 01 07 00 00 00 05 00 00 00 00 00 00 00 0b 00 00 00 01 79 32 62 25 24";
    }

}