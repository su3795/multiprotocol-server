//! 命令模型与状态机。
//!
//! 对应 Java 版 `io.mp.common.model.Command` / `RouteTable`。

use std::collections::HashMap;
use std::sync::RwLock;

/// 命令类型
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum CommandType {
    /// shard -> node 路由更新
    UpsertRoute = 1,
    /// 全局配置更新
    UpdateConfig = 2,
    /// 会话归属迁移
    TransferOwner = 3,
    /// 通用 KV 写入（演示线性一致读）
    PutKv = 4,
}

impl CommandType {
    pub fn from_u8(b: u8) -> Option<Self> {
        match b {
            1 => Some(CommandType::UpsertRoute),
            2 => Some(CommandType::UpdateConfig),
            3 => Some(CommandType::TransferOwner),
            4 => Some(CommandType::PutKv),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            CommandType::UpsertRoute => "UPSERT_ROUTE",
            CommandType::UpdateConfig => "UPDATE_CONFIG",
            CommandType::TransferOwner => "TRANSFER_OWNER",
            CommandType::PutKv => "PUT_KV",
        }
    }
}

/// 上共识层的命令。
///
/// **只承载元数据**（路由表、配置、会话归属、少量 KV）；
/// 业务数据流绝不进入共识层，否则 Raft 会成为吞吐天花板。
///
/// 序列化格式与 Java `DataOutputStream` 兼容：
/// `type(1) + key1(8) + key2(len:2 + UTF8) + value(len:2 + UTF8)`
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Command {
    pub r#type: CommandType,
    /// UpsertRoute: shardId ; TransferOwner: connId
    pub key1: i64,
    /// UpsertRoute: node ; UpdateConfig/PutKv: key
    pub key2: String,
    /// UpdateConfig/PutKv: value
    pub value: String,
}

impl Command {
    /// 路由更新命令
    pub fn upsert_route(shard_id: i64, node: &str) -> Self {
        Self { r#type: CommandType::UpsertRoute, key1: shard_id, key2: node.to_string(), value: String::new() }
    }

    /// 配置更新命令
    pub fn update_config(key: &str, value: &str) -> Self {
        Self { r#type: CommandType::UpdateConfig, key1: 0, key2: key.to_string(), value: value.to_string() }
    }

    /// KV 写入命令
    pub fn put_kv(key: &str, value: &str) -> Self {
        Self { r#type: CommandType::PutKv, key1: 0, key2: key.to_string(), value: value.to_string() }
    }

    /// 序列化
    pub fn serialize(&self) -> Vec<u8> {
        let k2 = self.key2.as_bytes();
        let v = self.value.as_bytes();
        let mut buf = Vec::with_capacity(1 + 8 + 2 + k2.len() + 2 + v.len());
        buf.push(self.r#type as u8);
        buf.extend_from_slice(&self.key1.to_be_bytes());
        buf.extend_from_slice(&(k2.len() as u16).to_be_bytes());
        buf.extend_from_slice(k2);
        buf.extend_from_slice(&(v.len() as u16).to_be_bytes());
        buf.extend_from_slice(v);
        buf
    }

    /// 反序列化
    pub fn deserialize(data: &[u8]) -> Option<Self> {
        if data.len() < 9 {
            return None;
        }
        let r#type = CommandType::from_u8(data[0])?;
        let key1 = i64::from_be_bytes([
            data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
        ]);
        let (key2, pos) = read_utf(data, 9)?;
        let (value, _) = read_utf(data, pos)?;
        Some(Self { r#type, key1, key2, value })
    }
}

/// 读取 2B 长度前缀 + UTF8 字节（兼容 Java `readUTF`）
fn read_utf(data: &[u8], pos: usize) -> Option<(String, usize)> {
    if pos + 2 > data.len() {
        return None;
    }
    let n = u16::from_be_bytes([data[pos], data[pos + 1]]) as usize;
    let start = pos + 2;
    if start + n > data.len() {
        return None;
    }
    let s = String::from_utf8(data[start..start + n].to_vec()).ok()?;
    Some((s, start + n))
}

/// 解析 `"key=value"`，返回 (key, value)
pub fn parse_key_value(s: &str) -> Option<(String, String)> {
    let idx = s.find('=')?;
    if idx == 0 {
        return None;
    }
    Some((s[..idx].to_string(), s[idx + 1..].to_string()))
}

// ---------------- 状态机 ----------------

/// 状态机持有的共享状态：路由表 + 配置 + 演示用 KV。
///
/// 约定：
/// - 写操作只能经由共识层 apply（保证所有副本顺序一致）
/// - 所有变更必须**幂等** —— Raft 在重放与重试时会重复 apply 同一条日志
#[derive(Debug, Default)]
pub struct RouteTable {
    routes: RwLock<HashMap<i64, String>>,
    config: RwLock<HashMap<String, String>>,
    owners: RwLock<HashMap<i64, String>>,
    kv: RwLock<HashMap<String, String>>,
}

impl RouteTable {
    pub fn new() -> Self { Self::default() }

    /// 应用一条命令（幂等）
    pub fn apply(&self, c: &Command) {
        match c.r#type {
            CommandType::UpsertRoute => {
                self.routes.write().unwrap().insert(c.key1, c.key2.clone());
            }
            CommandType::UpdateConfig => {
                self.config.write().unwrap().insert(c.key2.clone(), c.value.clone());
            }
            CommandType::TransferOwner => {
                self.owners.write().unwrap().insert(c.key1, c.key2.clone());
            }
            CommandType::PutKv => {
                self.kv.write().unwrap().insert(c.key2.clone(), c.value.clone());
            }
        }
    }

    /// 查询路由
    pub fn route(&self, shard_id: i64) -> Option<String> {
        self.routes.read().unwrap().get(&shard_id).cloned()
    }

    /// 查询 KV
    pub fn kv(&self, key: &str) -> Option<String> {
        self.kv.read().unwrap().get(key).cloned()
    }

    /// 路由条目数
    pub fn route_count(&self) -> usize { self.routes.read().unwrap().len() }

    /// KV 条目数
    pub fn kv_count(&self) -> usize { self.kv.read().unwrap().len() }

    /// 快照序列化：`"R:k=v\n"` 文本格式，与 Java / Go 版一致
    pub fn snapshot(&self) -> Vec<u8> {
        let mut out = String::new();
        for (k, v) in self.routes.read().unwrap().iter() {
            out.push_str(&format!("R:{k}={v}\n"));
        }
        for (k, v) in self.config.read().unwrap().iter() {
            out.push_str(&format!("C:{k}={v}\n"));
        }
        for (k, v) in self.kv.read().unwrap().iter() {
            out.push_str(&format!("K:{k}={v}\n"));
        }
        out.into_bytes()
    }

    /// 快照反序列化
    pub fn load_snapshot(&self, data: &[u8]) {
        let text = String::from_utf8_lossy(data);
        let mut routes = HashMap::new();
        let mut config = HashMap::new();
        let mut kv = HashMap::new();

        for line in text.lines() {
            if line.len() < 3 {
                continue;
            }
            let kind = line.as_bytes()[0];
            let rest = &line[2..];
            if let Some(eq) = rest.find('=') {
                let k = &rest[..eq];
                let v = &rest[eq + 1..];
                match kind {
                    b'R' => { if let Ok(id) = k.parse::<i64>() { routes.insert(id, v.to_string()); } }
                    b'C' => { config.insert(k.to_string(), v.to_string()); }
                    b'K' => { kv.insert(k.to_string(), v.to_string()); }
                    _ => {}
                }
            }
        }
        *self.routes.write().unwrap() = routes;
        *self.config.write().unwrap() = config;
        *self.kv.write().unwrap() = kv;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn command_round_trip() {
        let c = Command::upsert_route(7, "node-3");
        let back = Command::deserialize(&c.serialize()).unwrap();
        assert_eq!(back.r#type, CommandType::UpsertRoute);
        assert_eq!(back.key1, 7);
        assert_eq!(back.key2, "node-3");
    }

    #[test]
    fn command_put_kv_round_trip() {
        let c = Command::put_kv("user:1", "alice");
        let back = Command::deserialize(&c.serialize()).unwrap();
        assert_eq!(back.r#type, CommandType::PutKv);
        assert_eq!(back.key2, "user:1");
        assert_eq!(back.value, "alice");
    }

    #[test]
    fn command_deserialize_rejects_truncated() {
        assert!(Command::deserialize(&[1u8, 0, 0]).is_none());
    }

    #[test]
    fn route_table_apply_and_snapshot() {
        let rt = RouteTable::new();
        rt.apply(&Command::put_kv("k1", "v1"));
        rt.apply(&Command::upsert_route(3, "node-9"));
        assert_eq!(rt.kv("k1").as_deref(), Some("v1"));
        assert_eq!(rt.route(3).as_deref(), Some("node-9"));

        let snap = rt.snapshot();
        let rt2 = RouteTable::new();
        rt2.load_snapshot(&snap);
        assert_eq!(rt2.kv("k1").as_deref(), Some("v1"));
        assert_eq!(rt2.kv_count(), 1);
        assert_eq!(rt2.route_count(), 1);
    }

    #[test]
    fn parse_key_value_works() {
        let (k, v) = parse_key_value("user:1=alice").unwrap();
        assert_eq!(k, "user:1");
        assert_eq!(v, "alice");
        assert!(parse_key_value("novalue").is_none());
    }
}
