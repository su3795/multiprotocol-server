//! mp-common — 统一帧格式与命令模型（零第三方依赖）。
//!
//! 对应 Java 版 `mp-common`，与 Go 版 `internal/mpcommon` **字节级一致**。
//! 三语言共用同一套帧格式与命令字，因此可互相通信。

pub mod frame;
pub mod model;

pub use frame::{
    cmd_name, decode, encode, peek_frame_length, try_decode, DecodeError, Frame, FrameError,
    Protocol, CODE_BAD_REQUEST, CODE_INTERNAL, CODE_NOT_LEADER, CODE_OK, CMD_GET, CMD_PING,
    CMD_PUT, CMD_ROUTE_GET, CMD_ROUTE_SET, CMD_STATS, CRC32_SIZE, FLAG_COMPRESSED,
    FLAG_ENCRYPTED, FLAG_NEED_RESPONSE, HEADER_SIZE, MAGIC, MAX_PAYLOAD, VERSION,
};
pub use model::{parse_key_value, Command, CommandType, RouteTable};
