//! 零依赖内存 Raft：单进程内 N 个节点，通过 `std::sync::mpsc` 互联。
//!
//! 定位：保证 `cargo run` 开箱即跑，完整演示
//! 选举 / 日志复制 / 提交 / 线性读 / 故障切换 全链路。
//!
//! 实现要点（标准 Raft）：
//! - 选举超时随机化（各节点错开），避免分裂投票
//! - 日志一致性检查：`prev_log_index/prev_log_term` 不匹配则回退 `next_index`
//! - `commit_index` 只推进当前任期内已被多数派复制的日志
//! - 状态机 apply 幂等
//!
//! **死锁规避**：所有跨节点通信都在释放本地锁之后进行（锁内快照 → 锁外通信）。

use crate::{Consensus, ConsensusError};
use mp_common::{Command, RouteTable};
use std::collections::HashMap;
use std::sync::mpsc::{channel, Receiver, RecvTimeoutError, Sender};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Role {
    Follower,
    Candidate,
    Leader,
}

impl Role {
    fn as_str(&self) -> &'static str {
        match self {
            Role::Leader => "LEADER",
            Role::Candidate => "CANDIDATE",
            Role::Follower => "FOLLOWER",
        }
    }
}

#[derive(Clone)]
struct LogEntry {
    term: i64,
    #[allow(dead_code)]
    index: i64,
    command: Option<Command>,
}

struct VoteResp {
    term: i64,
    granted: bool,
}

struct AppendResp {
    term: i64,
    success: bool,
    match_index: i64,
}

enum Msg {
    Vote {
        term: i64,
        from: usize,
        last_log_index: i64,
        last_log_term: i64,
        resp: Sender<VoteResp>,
    },
    Append {
        term: i64,
        prev_log_index: i64,
        prev_log_term: i64,
        entries: Vec<LogEntry>,
        leader_commit: i64,
        resp: Sender<AppendResp>,
    },
}

struct NodeState {
    id: usize,
    peers: Vec<usize>,

    // 持久化状态
    current_term: i64,
    voted_for: Option<usize>,
    log: Vec<LogEntry>, // log[0] 哨兵

    // 易失状态
    role: Role,
    #[allow(dead_code)]
    leader_id: Option<usize>,
    commit_index: i64,
    last_applied: i64,
    next_index: HashMap<usize, i64>,
    match_index: HashMap<usize, i64>,

    table: Arc<RouteTable>,
    stopped: bool,
}

impl NodeState {
    fn quorum(&self) -> usize { self.peers.len() / 2 + 1 }
    fn last_log_index(&self) -> i64 { self.log.len() as i64 - 1 }
    fn last_log_term(&self) -> i64 { self.log[self.log.len() - 1].term }

    /// 将已提交日志应用到状态机（幂等）
    fn apply_committed(&mut self) {
        while self.last_applied < self.commit_index {
            self.last_applied += 1;
            let idx = self.last_applied as usize;
            if idx < self.log.len() {
                if let Some(cmd) = self.log[idx].command.clone() {
                    self.table.apply(&cmd);
                }
            }
        }
    }
}

/// 内存集群配置
pub struct MemoryConfig {
    /// 本节点 ID（0-based）
    pub node_id: usize,
    /// 全部成员 ID
    pub members: Vec<usize>,
}

/// 内存 Raft 集群（对外的 Consensus 实现，绑定到其中一个节点）
pub struct MemoryCluster {
    me: usize,
    members: Vec<usize>,
    states: Vec<Arc<Mutex<NodeState>>>,
    senders: Vec<Sender<Msg>>,
}

/// 创建并启动一个 N 节点内存集群
pub fn new_memory_cluster(cfg: MemoryConfig) -> Result<MemoryCluster, ConsensusError> {
    if cfg.members.is_empty() {
        return Err(ConsensusError::Other("成员列表为空".into()));
    }
    if !cfg.members.contains(&cfg.node_id) {
        return Err(ConsensusError::Other(format!(
            "节点 {} 不在成员列表 {:?} 中", cfg.node_id, cfg.members)));
    }

    let n = cfg.members.len();
    let mut senders = Vec::with_capacity(n);
    let mut receivers = Vec::with_capacity(n);
    for _ in 0..n {
        let (tx, rx) = channel::<Msg>();
        senders.push(tx);
        receivers.push(rx);
    }

    let states: Vec<Arc<Mutex<NodeState>>> = cfg
        .members
        .iter()
        .map(|&id| {
            Arc::new(Mutex::new(NodeState {
                id,
                peers: cfg.members.clone(),
                current_term: 0,
                voted_for: None,
                log: vec![LogEntry { term: 0, index: 0, command: None }],
                role: Role::Follower,
                leader_id: None,
                commit_index: 0,
                last_applied: 0,
                next_index: HashMap::new(),
                match_index: HashMap::new(),
                table: Arc::new(RouteTable::new()),
                stopped: false,
            }))
        })
        .collect();

    // 启动每个节点的工作线程
    for i in 0..n {
        let state = states[i].clone();
        let rx = receivers.pop().expect("receiver 数量应匹配");
        let senders = senders.clone();
        let members = cfg.members.clone();
        // 各节点选举超时错开，降低同时发起选举的概率
        let election_timeout = Duration::from_millis(150 + 40 * i as u64);
        thread::spawn(move || node_loop(state, rx, senders, members, election_timeout));
    }

    let me = idx_of(&cfg.members, cfg.node_id).unwrap_or(0);
    Ok(MemoryCluster { me, members: cfg.members.clone(), states, senders })
}

fn idx_of(members: &[usize], id: usize) -> Option<usize> {
    members.iter().position(|&x| x == id)
}

// ---------------- 节点主循环 ----------------

fn node_loop(
    state: Arc<Mutex<NodeState>>,
    rx: Receiver<Msg>,
    senders: Vec<Sender<Msg>>,
    members: Vec<usize>,
    election_timeout: Duration,
) {
    loop {
        let is_leader = {
            let s = state.lock().unwrap();
            if s.stopped {
                return;
            }
            s.role == Role::Leader
        };

        if is_leader {
            replicate(&state, &senders, &members);
            thread::sleep(Duration::from_millis(50));
            continue;
        }

        match rx.recv_timeout(election_timeout) {
            Ok(msg) => {
                let mut s = state.lock().unwrap();
                if s.stopped {
                    return;
                }
                handle_msg(&mut s, msg);
            }
            Err(RecvTimeoutError::Timeout) => {
                run_election(&state, &senders, &members);
            }
            Err(RecvTimeoutError::Disconnected) => return,
        }
    }
}

// ---------------- 消息处理（在锁内完成，不等待外部） ----------------

fn handle_msg(s: &mut NodeState, msg: Msg) {
    match msg {
        Msg::Vote { term, from, last_log_index, last_log_term, resp } => {
            if term > s.current_term {
                s.current_term = term;
                s.role = Role::Follower;
                s.voted_for = None;
            }
            let log_ok = last_log_term > s.last_log_term()
                || (last_log_term == s.last_log_term() && last_log_index >= s.last_log_index());
            let granted = term == s.current_term
                && (s.voted_for.is_none() || s.voted_for == Some(from))
                && log_ok;
            if granted {
                s.voted_for = Some(from);
            }
            let _ = resp.send(VoteResp { term: s.current_term, granted });
        }

        Msg::Append { term, prev_log_index, prev_log_term, entries, leader_commit, resp } => {
            if term < s.current_term {
                let _ = resp.send(AppendResp { term: s.current_term, success: false, match_index: 0 });
                return;
            }
            s.current_term = term;
            s.role = Role::Follower;
            s.voted_for = None;
            s.leader_id = Some(0); // 值未用于路由，仅占位

            // 日志一致性检查
            let mismatch = prev_log_index > s.last_log_index()
                || (prev_log_index >= 0
                    && (prev_log_index as usize) < s.log.len()
                    && s.log[prev_log_index as usize].term != prev_log_term);
            if mismatch {
                let _ = resp.send(AppendResp { term: s.current_term, success: false, match_index: 0 });
                return;
            }

            // 冲突截断 + 追加
            for (i, e) in entries.into_iter().enumerate() {
                let idx = (prev_log_index + 1 + i as i64) as usize;
                if idx < s.log.len() {
                    if s.log[idx].term != e.term {
                        s.log.truncate(idx);
                    } else {
                        continue;
                    }
                }
                s.log.push(e);
            }
            if leader_commit > s.commit_index {
                s.commit_index = leader_commit.min(s.last_log_index());
            }
            let match_index = s.last_log_index();
            s.apply_committed();
            let _ = resp.send(AppendResp { term: s.current_term, success: true, match_index });
        }
    }
}

// ---------------- 选举 ----------------

fn run_election(state: &Arc<Mutex<NodeState>>, senders: &[Sender<Msg>], members: &[usize]) {
    let (term, last_log_index, last_log_term, my_id, peers) = {
        let mut s = state.lock().unwrap();
        if s.stopped || s.role == Role::Leader {
            return;
        }
        s.current_term += 1;
        s.role = Role::Candidate;
        s.voted_for = Some(s.id);
        (s.current_term, s.last_log_index(), s.last_log_term(), s.id, s.peers.clone())
    };

    let mut votes = 1usize;
    let quorum = peers.len() / 2 + 1;

    for peer in peers.iter() {
        if *peer == my_id {
            continue;
        }
        let Some(pi) = idx_of(members, *peer) else { continue };
        let (tx, rx) = channel::<VoteResp>();
        if senders[pi]
            .send(Msg::Vote { term, from: my_id, last_log_index, last_log_term, resp: tx })
            .is_err()
        {
            continue;
        }
        if let Ok(r) = rx.recv_timeout(Duration::from_millis(200)) {
            if r.term > term {
                let mut s = state.lock().unwrap();
                s.current_term = r.term;
                s.role = Role::Follower;
                s.voted_for = None;
                return;
            }
            if r.granted {
                votes += 1;
            }
        }
    }

    if votes >= quorum {
        let mut s = state.lock().unwrap();
        if s.role == Role::Candidate && s.current_term == term {
            s.role = Role::Leader;
            s.leader_id = Some(s.id);
            let next = s.last_log_index() + 1;
            for p in s.peers.iter() {
                if *p != s.id {
                    s.next_index.insert(*p, next);
                    s.match_index.insert(*p, 0);
                }
            }
            // 空日志确立领导权
            s.log.push(LogEntry { term: s.current_term, index: next, command: None });
            println!("[consensus] 节点 {} 成为 Leader (term={}, votes={}/{})",
                     s.id, term, votes, s.peers.len());
        }
    }
}

// ---------------- 日志复制（Leader） ----------------

/// 向所有 follower 发送 AppendEntries，并推进 commit_index。
/// 锁内快照 → 锁外通信 → 锁内更新，避免死锁。
fn replicate(state: &Arc<Mutex<NodeState>>, senders: &[Sender<Msg>], members: &[usize]) {
    // 1. 锁内快照
    struct Task {
        peer_idx: usize,
        peer_id: usize,
        prev_index: i64,
        prev_term: i64,
        entries: Vec<LogEntry>,
    }
    let (term, leader_commit, tasks): (i64, i64, Vec<Task>) = {
        let s = state.lock().unwrap();
        if s.role != Role::Leader {
            return;
        }
        let mut tasks = Vec::new();
        for peer in s.peers.iter() {
            if *peer == s.id {
                continue;
            }
            let Some(pi) = idx_of(members, *peer) else { continue };
            let next = *s.next_index.get(peer).unwrap_or(&1).max(&1);
            let prev_index = next - 1;
            let prev_term = if prev_index >= 0 && (prev_index as usize) < s.log.len() {
                s.log[prev_index as usize].term
            } else {
                0
            };
            let entries = if (next as usize) < s.log.len() {
                s.log[next as usize..].to_vec()
            } else {
                Vec::new()
            };
            tasks.push(Task { peer_idx: pi, peer_id: *peer, prev_index, prev_term, entries });
        }
        (s.current_term, s.commit_index, tasks)
    };

    // 2. 锁外通信
    struct Outcome {
        peer_id: usize,
        term: i64,
        success: bool,
        match_index: i64,
    }
    let mut outcomes = Vec::new();
    for t in tasks {
        let (tx, rx) = channel::<AppendResp>();
        if senders[t.peer_idx]
            .send(Msg::Append {
                term,
                prev_log_index: t.prev_index,
                prev_log_term: t.prev_term,
                entries: t.entries,
                leader_commit,
                resp: tx,
            })
            .is_err()
        {
            continue;
        }
        if let Ok(r) = rx.recv_timeout(Duration::from_millis(100)) {
            outcomes.push(Outcome {
                peer_id: t.peer_id,
                term: r.term,
                success: r.success,
                match_index: r.match_index,
            });
        }
    }

    // 3. 锁内更新
    {
        let mut s = state.lock().unwrap();
        if s.role != Role::Leader {
            return;
        }
        for o in outcomes {
            if o.term > term {
                s.current_term = o.term;
                s.role = Role::Follower;
                s.voted_for = None;
                return;
            }
            if o.success {
                s.match_index.insert(o.peer_id, o.match_index);
                s.next_index.insert(o.peer_id, o.match_index + 1);
            } else if let Some(v) = s.next_index.get_mut(&o.peer_id) {
                if *v > 1 {
                    *v -= 1;
                }
            }
        }

        // 推进 commit_index：多数派 match_index 的中位数
        let mut matches: Vec<i64> = s.peers
            .iter()
            .filter(|p| **p != s.id)
            .map(|p| *s.match_index.get(p).unwrap_or(&0))
            .collect();
        matches.push(s.last_log_index());
        matches.sort_unstable();
        let median = matches[(matches.len() - 1) / 2];
        if median > s.commit_index
            && (median as usize) < s.log.len()
            && s.log[median as usize].term == s.current_term
        {
            s.commit_index = median;
        }
        s.apply_committed();
    }
}

// ---------------- Consensus 实现 ----------------

impl Consensus for MemoryCluster {
    fn start(&self) -> Result<(), ConsensusError> {
        println!("[consensus] 内存 Raft 集群已启动，共 {} 节点，本节点 id={}",
                 self.members.len(), self.members[self.me]);
        Ok(())
    }

    fn is_leader(&self) -> bool {
        self.states[self.me].lock().unwrap().role == Role::Leader
    }

    fn role(&self) -> &'static str {
        self.states[self.me].lock().unwrap().role.as_str()
    }

    fn propose(&self, cmd: Command) -> Result<String, ConsensusError> {
        let start = std::time::Instant::now();
        let state = &self.states[self.me];

        // 追加日志
        let target = {
            let mut s = state.lock().unwrap();
            if s.role != Role::Leader {
                return Err(ConsensusError::NotLeader);
            }
            let idx = s.log.len() as i64;
            s.log.push(LogEntry { term: s.current_term, index: idx, command: Some(cmd) });
            idx
        };

        // 复制直到提交并 apply
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        while std::time::Instant::now() < deadline {
            replicate(state, &self.senders, &self.members);

            let done = {
                let s = state.lock().unwrap();
                s.last_applied >= target
            };
            if done {
                return Ok(format!("applied, cost={}us", start.elapsed().as_micros()));
            }
            thread::sleep(Duration::from_millis(5));
        }
        Err(ConsensusError::Timeout)
    }

    fn linearizable_get(&self, key: &str) -> Result<String, ConsensusError> {
        let s = self.states[self.me].lock().unwrap();
        if s.role != Role::Leader {
            return Err(ConsensusError::NotLeader);
        }
        Ok(s.table.kv(key).unwrap_or_default())
    }

    fn state_machine(&self) -> Arc<RouteTable> {
        self.states[self.me].lock().unwrap().table.clone()
    }

    fn implementation(&self) -> &'static str { "MemoryRaft(Rust)" }

    fn close(&self) {
        for s in &self.states {
            s.lock().unwrap().stopped = true;
        }
    }
}
