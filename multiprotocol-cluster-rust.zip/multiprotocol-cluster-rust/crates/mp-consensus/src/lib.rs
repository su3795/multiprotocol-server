//! 共识层抽象（对应 Java 版 `mp-consensus-api`）。
//!
//! # 三条硬约束
//!
//! 1. **只有元数据上共识层**，业务数据流不进 Raft
//! 2. **状态机 apply 必须幂等**（日志会被重放与重试）
//! 3. **线性读不得返回旧值**
//!
//! # 设计说明
//!
//! 本 crate 的 trait 是**同步**的（不依赖 async-trait），
//! 因为内嵌 Raft 用 `std::thread` + `std::sync::mpsc` 实现，零第三方依赖。
//! Tokio 接入层调用 `propose` 时须用 `spawn_blocking` 包裹，
//! 避免阻塞异步 worker —— 这是 Rust 异步服务最容易踩的坑。

use mp_common::{Command, RouteTable};
use std::sync::Arc;

pub mod memory;

pub use memory::{new_memory_cluster, MemoryCluster, MemoryConfig};

/// 共识错误
#[derive(Debug)]
pub enum ConsensusError {
    /// 本节点非 Leader
    NotLeader,
    /// 超时
    Timeout,
    /// 其他错误
    Other(String),
}

impl std::fmt::Display for ConsensusError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ConsensusError::NotLeader => write!(f, "本节点非 Leader"),
            ConsensusError::Timeout => write!(f, "共识操作超时"),
            ConsensusError::Other(s) => write!(f, "{s}"),
        }
    }
}

impl std::error::Error for ConsensusError {}

/// 共识层统一抽象，与 Java `io.mp.consensus.Consensus` 对应
pub trait Consensus: Send + Sync {
    /// 启动本节点的共识服务
    fn start(&self) -> Result<(), ConsensusError>;
    /// 当前节点是否为 Leader
    fn is_leader(&self) -> bool;
    /// 当前角色（LEADER / FOLLOWER / CANDIDATE）
    fn role(&self) -> &'static str;
    /// 提交一条命令，阻塞至多数派复制并提交
    fn propose(&self, cmd: Command) -> Result<String, ConsensusError>;
    /// 线性一致读
    fn linearizable_get(&self, key: &str) -> Result<String, ConsensusError>;
    /// 本地状态机（非 Leader 也可用，但为最终一致）
    fn state_machine(&self) -> Arc<RouteTable>;
    /// 实现名称
    fn implementation(&self) -> &'static str;
    /// 关闭
    fn close(&self);
}
