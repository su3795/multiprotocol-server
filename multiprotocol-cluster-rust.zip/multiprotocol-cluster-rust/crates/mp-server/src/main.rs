//! mp-server — Rust 版多协议集群服务器（对应 Java 版 `ServerMain` + `DemoClient`）。
//!
//! # 用法
//!
//! ```bash
//! # 启动服务端（内存 Raft，单进程 3 副本）
//! cargo run --release -- --tcp 127.0.0.1:9101 --udp 127.0.0.1:9201 --metrics-port 9091
//!
//! # 演示客户端
//! cargo run --release -- client --proto tcp --port 9101
//! cargo run --release -- client --proto udp --port 9201
//! ```
//!
//! 依赖只有 Tokio（共识层与协议层均零第三方依赖）。

use mp_common::{
    cmd_name, decode, encode, peek_frame_length, Frame, Protocol, CMD_GET, CMD_PING, CMD_PUT,
    CMD_ROUTE_GET, CMD_ROUTE_SET, CMD_STATS, FLAG_NEED_RESPONSE, HEADER_SIZE,
};
use mp_consensus::{new_memory_cluster, Consensus, MemoryConfig};
use mp_gateway::kcp::Kcp;
use mp_gateway::{serve_custom, serve_kcp, serve_tcp, serve_udp, RequestProcessor};
#[cfg(feature = "quic")]
use mp_gateway::quic::serve_quic;
use mp_observability::metrics;
use std::sync::Arc;
use std::time::{Duration, Instant};

// ---------------- 极简参数解析（避免引入 clap） ----------------

struct Args {
    node_id: usize,
    members: Vec<usize>,
    tcp: String,
    udp: String,
    custom: Option<String>,
    kcp: Option<String>,
    quic: Option<String>,
    metrics_port: u16,
}

impl Default for Args {
    fn default() -> Self {
        Self {
            node_id: 0,
            members: vec![0, 1, 2],
            tcp: "127.0.0.1:9101".into(),
            udp: "127.0.0.1:9201".into(),
            custom: None,
            kcp: None,
            quic: None,
            metrics_port: 9091,
        }
    }
}

fn parse_members(s: &str) -> Vec<usize> {
    s.split(',')
        .filter_map(|p| p.trim().parse::<usize>().ok())
        .collect()
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let argv: Vec<String> = std::env::args().collect();

    // 子命令：client
    if argv.len() > 1 && argv[1] == "client" {
        return run_client(&argv[2..]).await;
    }

    let mut args = Args::default();
    let mut i = 1;
    while i < argv.len() {
        match argv[i].as_str() {
            "--node-id" if i + 1 < argv.len() => { args.node_id = argv[i + 1].parse().unwrap_or(0); i += 2; }
            "--members" if i + 1 < argv.len() => { args.members = parse_members(&argv[i + 1]); i += 2; }
            "--tcp" if i + 1 < argv.len() => { args.tcp = argv[i + 1].clone(); i += 2; }
            "--udp" if i + 1 < argv.len() => { args.udp = argv[i + 1].clone(); i += 2; }
            "--custom" if i + 1 < argv.len() => { args.custom = Some(argv[i + 1].clone()); i += 2; }
            "--kcp" if i + 1 < argv.len() => { args.kcp = Some(argv[i + 1].clone()); i += 2; }
            "--quic" if i + 1 < argv.len() => { args.quic = Some(argv[i + 1].clone()); i += 2; }
            "--metrics-port" if i + 1 < argv.len() => {
                args.metrics_port = argv[i + 1].parse().unwrap_or(9091); i += 2;
            }
            _ => i += 1,
        }
    }

    println!("========== 多协议集群服务器 · Rust 版 ==========");
    println!("共识模式 = memory (零依赖内嵌 Raft), nodeID = {}", args.node_id);

    // ---------- 1. 共识层 ----------
    let cluster = new_memory_cluster(MemoryConfig {
        node_id: args.node_id,
        members: args.members.clone(),
    })?;
    cluster.start()?;
    let consensus: Arc<dyn Consensus> = Arc::new(cluster);

    // ---------- 2. 多协议接入 ----------
    let proc = Arc::new(RequestProcessor::new(consensus.clone()));

    let tcp_addr = args.tcp.clone();
    let p1 = proc.clone();
    tokio::spawn(async move {
        if let Err(e) = serve_tcp(&tcp_addr, p1).await {
            eprintln!("[gateway] TCP 服务失败: {e}");
        }
    });

    let udp_addr = args.udp.clone();
    let p2 = proc.clone();
    tokio::spawn(async move {
        if let Err(e) = serve_udp(&udp_addr, p2).await {
            eprintln!("[gateway] UDP 服务失败: {e}");
        }
    });

    if let Some(custom_addr) = args.custom.clone() {
        let p3 = proc.clone();
        tokio::spawn(async move {
            if let Err(e) = serve_custom(&custom_addr, p3).await {
                eprintln!("[gateway] CUSTOM 服务失败: {e}");
            }
        });
    }
    if let Some(kcp_addr) = args.kcp.clone() {
        let p4 = proc.clone();
        tokio::spawn(async move {
            if let Err(e) = serve_kcp(&kcp_addr, p4).await {
                eprintln!("[gateway] KCP 服务失败: {e}");
            }
        });
    }
    start_quic_if_enabled(&args.quic, &proc);

    // ---------- 3. 指标端点（手写 HTTP，避免额外依赖） ----------
    let metrics_port = args.metrics_port;
    tokio::spawn(async move { serve_metrics(metrics_port).await; });
    println!("指标端点: http://0.0.0.0:{}/metrics", args.metrics_port);

    // 等待选举
    tokio::time::sleep(Duration::from_millis(1200)).await;
    println!("--------------------------------------------------");
    println!("节点就绪 | 实现={} | 角色={} | TCP={} | UDP={} | KCP={} | QUIC={}",
             consensus.implementation(), consensus.role(), args.tcp, args.udp,
             args.kcp.clone().unwrap_or_else(|| "-".into()),
             args.quic.clone().unwrap_or_else(|| "-".into()));
    println!("--------------------------------------------------");

    // ---------- 4. 优雅退出 ----------
    tokio::signal::ctrl_c().await?;
    println!("\n正在关闭节点...");
    consensus.close();
    println!("节点已关闭");
    Ok(())
}

/// 极简 HTTP 服务：只响应 /metrics 与 /healthz
async fn serve_metrics(port: u16) {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpListener;

    let addr = format!("0.0.0.0:{port}");
    let listener = match TcpListener::bind(&addr).await {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[metrics] 监听 {addr} 失败: {e}");
            return;
        }
    };

    loop {
        let Ok((mut socket, _)) = listener.accept().await else { continue };
        tokio::spawn(async move {
            let mut buf = vec![0u8; 4096];
            let Ok(n) = socket.read(&mut buf).await else { return };
            if n == 0 {
                return;
            }
            let req = String::from_utf8_lossy(&buf[..n]).to_string();
            let line = req.lines().next().unwrap_or("");

            let (status, body) = if line.contains("/metrics") {
                ("200 OK", metrics().render())
            } else if line.contains("/healthz") {
                ("200 OK", "ok\n".to_string())
            } else {
                ("200 OK", "mp-server (rust)\nendpoints: /metrics /healthz\n".to_string())
            };

            let resp = format!(
                "HTTP/1.1 {status}\r\nContent-Type: text/plain; version=0.0.4; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                body.len(),
                body
            );
            let _ = socket.write_all(resp.as_bytes()).await;
        });
    }
}

// ---------------- 演示客户端 ----------------

async fn run_client(argv: &[String]) -> Result<(), Box<dyn std::error::Error>> {
    let mut proto = "tcp".to_string();
    let mut host = "127.0.0.1".to_string();
    let mut port = 9101u16;

    let mut i = 0;
    while i < argv.len() {
        match argv[i].as_str() {
            "--proto" if i + 1 < argv.len() => { proto = argv[i + 1].clone(); i += 2; }
            "--host" if i + 1 < argv.len() => { host = argv[i + 1].clone(); i += 2; }
            "--port" if i + 1 < argv.len() => { port = argv[i + 1].parse().unwrap_or(9101); i += 2; }
            _ => i += 1,
        }
    }

    println!("=== 演示客户端 · {} → {}:{} ===", proto.to_uppercase(), host, port);

    match proto.as_str() {
        "udp" => run_udp(&host, port).await,
        "kcp" => run_kcp(&host, port).await,
        "quic" => run_quic(&host, port).await,
        _ => run_tcp(&host, port).await,
    }
}

async fn run_tcp(host: &str, port: u16) -> Result<(), Box<dyn std::error::Error>> {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpStream;

    let mut sock = TcpStream::connect(format!("{host}:{port}")).await?;
    sock.set_nodelay(true)?;

    for (cmd, payload) in [
        (CMD_PING, "hello"),
        (CMD_PUT, "user:1=alice"),
        (CMD_PUT, "user:2=bob"),
        (CMD_GET, "user:1"),
        (CMD_ROUTE_SET, "7=node-3"),
        (CMD_ROUTE_GET, "7"),
        (CMD_STATS, ""),
    ] {
        let req = Frame::new(FLAG_NEED_RESPONSE, cmd, next_seq(), payload.as_bytes().to_vec());
        let out = encode(&req)?;
        sock.write_all(&out).await?;

        // 先读头部，再按长度读余下部分（处理半包）
        let mut head = vec![0u8; HEADER_SIZE];
        if sock.read_exact(&mut head).await.is_err() {
            println!("{}: 读取失败", cmd_name(cmd));
            continue;
        }
        let total = peek_frame_length(&head);
        let mut rest = vec![0u8; total - HEADER_SIZE];
        if sock.read_exact(&mut rest).await.is_err() {
            println!("{}: 读取失败", cmd_name(cmd));
            continue;
        }
        let mut full = head;
        full.extend_from_slice(&rest);
        match decode(&full) {
            Ok(resp) => println!("{:10} → {}", cmd_name(cmd),
                                 String::from_utf8_lossy(&resp.payload)),
            Err(e) => println!("{:10} → 解码失败: {e}", cmd_name(cmd)),
        }
    }
    Ok(())
}

async fn run_udp(host: &str, port: u16) -> Result<(), Box<dyn std::error::Error>> {
    use tokio::net::UdpSocket;

    let sock = UdpSocket::bind("0.0.0.0:0").await?;
    sock.connect(format!("{host}:{port}")).await?;

    for (cmd, payload) in [
        (CMD_PING, "hello"),
        (CMD_PUT, "user:3=carol"),
        (CMD_GET, "user:3"),
        (CMD_STATS, ""),
    ] {
        let req = Frame::new(FLAG_NEED_RESPONSE, cmd, next_seq(), payload.as_bytes().to_vec());
        let out = encode(&req)?;
        sock.send(&out).await?;

        let mut buf = vec![0u8; 4096];
        match tokio::time::timeout(Duration::from_secs(3), sock.recv(&mut buf)).await {
            Ok(Ok(n)) => match decode(&buf[..n]) {
                Ok(resp) => println!("{:10} → {}", cmd_name(cmd),
                                     String::from_utf8_lossy(&resp.payload)),
                Err(e) => println!("{:10} → 解码失败: {e}", cmd_name(cmd)),
            },
            _ => println!("{:10} → 超时 (UDP 可能丢包，重试即可)", cmd_name(cmd)),
        }
    }
    Ok(())
}

use std::sync::atomic::{AtomicI64, Ordering};
static SEQ: AtomicI64 = AtomicI64::new(1);

fn next_seq() -> i64 { SEQ.fetch_add(1, Ordering::Relaxed) }

/// 确保 Protocol 在本 crate 中被引用（供未来扩展使用）
#[allow(dead_code)]
fn _assert_protocol_used(p: Protocol) -> &'static str { p.as_str() }

/// 启动 QUIC 接入（仅在 --features quic 构建时可用）
#[cfg(feature = "quic")]
fn start_quic_if_enabled(addr: &Option<String>, proc: &Arc<RequestProcessor>) {
    if let Some(addr) = addr.clone() {
        let p = proc.clone();
        tokio::spawn(async move {
            if let Err(e) = serve_quic(&addr, p).await {
                eprintln!("[gateway] QUIC 服务失败: {e}");
            }
        });
    }
}

/// 未以 quic feature 构建时的占位：给出明确提示
#[cfg(not(feature = "quic"))]
fn start_quic_if_enabled(addr: &Option<String>, _proc: &Arc<RequestProcessor>) {
    if addr.is_some() {
        eprintln!("[gateway] 已指定 --quic 但未以 --features quic 构建，QUIC 不可用");
    }
}

/// KCP 客户端：需周期性驱动 Kcp::update 并把 UDP 数据报喂给 Kcp::input
async fn run_kcp(host: &str, port: u16) -> Result<(), Box<dyn std::error::Error>> {
    use tokio::net::UdpSocket;
    use tokio::sync::mpsc;

    let sock = Arc::new(UdpSocket::bind("0.0.0.0:0").await?);
    sock.connect(format!("{host}:{port}")).await?;

    let conv = 0x1122_3344u32; // 会话标识，服务端从包头读取
    let mut kcp = Kcp::new(conv);
    let start = Instant::now();

    // 收包任务：UDP 数据报 → channel，主流程串行消费，无需加锁
    let (tx, mut rx) = mpsc::channel::<Vec<u8>>(256);
    let sock2 = sock.clone();
    tokio::spawn(async move {
        let mut buf = vec![0u8; 2048];
        loop {
            match sock2.recv(&mut buf).await {
                Ok(n) => {
                    if tx.send(buf[..n].to_vec()).await.is_err() {
                        break;
                    }
                }
                Err(_) => break,
            }
        }
    });

    for (cmd, payload) in [
        (CMD_PING, "hello"),
        (CMD_PUT, "user:1=alice"),
        (CMD_PUT, "user:2=bob"),
        (CMD_GET, "user:1"),
        (CMD_ROUTE_SET, "7=node-3"),
        (CMD_ROUTE_GET, "7"),
        (CMD_STATS, ""),
    ] {
        let req = Frame::new(FLAG_NEED_RESPONSE, cmd, next_seq(), payload.as_bytes().to_vec());
        let out = encode(&req)?;
        kcp.send(&out)?;

        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            // 非阻塞取包交给 KCP
            if let Ok(pkt) = rx.try_recv() {
                let _ = kcp.input(&pkt);
            }
            // 驱动时钟（内部会在需要时 flush，触发重传与 ACK）
            let now = start.elapsed().as_millis() as u32;
            let out = kcp.update(now);
            if !out.is_empty() {
                let _ = sock.send(&out).await;
            }

            if let Some(msg) = kcp.recv() {
                match decode(&msg) {
                    Ok(resp) => println!("{:10} → {}", cmd_name(cmd),
                                         String::from_utf8_lossy(&resp.payload)),
                    Err(e) => println!("{:10} → 解码失败: {e}", cmd_name(cmd)),
                }
                break;
            }
            if Instant::now() > deadline {
                println!("{:10} → 超时（KCP 重传仍未收到响应）", cmd_name(cmd));
                break;
            }
            tokio::time::sleep(Duration::from_millis(2)).await;
        }
    }
    Ok(())
}

/// QUIC 演示客户端（需 --features quic）
#[cfg(feature = "quic")]
async fn run_quic(host: &str, port: u16) -> Result<(), Box<dyn std::error::Error>> {
    use mp_common::try_decode;
    use std::net::SocketAddr;

    let remote: SocketAddr = format!("{host}:{port}").parse()?;

    // 服务端使用自签证书，客户端跳过校验
    let crypto = std::sync::Arc::new(
        rustls::ClientConfig::builder()
            .with_safe_defaults()
            .with_custom_certificate_verifier(std::sync::Arc::new(SkipVerify))
            .with_no_client_auth(),
    );
    let mut cfg = quinn::ClientConfig::new(crypto);
    cfg.transport = std::sync::Arc::new(quinn::TransportConfig::default());

    let mut endpoint = quinn::Endpoint::client("0.0.0.0:0".parse()?)?;
    endpoint.set_default_client_config(cfg);

    let conn = endpoint.connect(remote, "localhost")?.await?;
    println!("QUIC 已连接 {remote}");

    for (cmd, payload) in [
        (CMD_PING, "hello"),
        (CMD_PUT, "user:1=alice"),
        (CMD_GET, "user:1"),
        (CMD_STATS, ""),
    ] {
        let (mut send, mut recv) = conn.open_bi().await?;
        let req = Frame::new(FLAG_NEED_RESPONSE, cmd, next_seq(), payload.as_bytes().to_vec());
        let out = encode(&req)?;
        send.write_all(&out).await?;
        send.finish().await?;

        // 先读头部，再按长度读余下部分（QUIC 流是字节流，需处理半包）
        use tokio::io::AsyncReadExt;
        let mut head = vec![0u8; HEADER_SIZE];
        if recv.read_exact(&mut head).await.is_err() {
            println!("{:10} → 读取失败", cmd_name(cmd));
            continue;
        }
        let total = peek_frame_length(&head);
        let mut rest = vec![0u8; total - HEADER_SIZE];
        if recv.read_exact(&mut rest).await.is_err() {
            println!("{:10} → 读取失败", cmd_name(cmd));
            continue;
        }
        let mut full = head;
        full.extend_from_slice(&rest);
        match try_decode(&full) {
            Ok((resp, _)) => println!("{:10} → {}", cmd_name(cmd),
                                      String::from_utf8_lossy(&resp.payload)),
            Err(e) => println!("{:10} → 解码失败: {e}", cmd_name(cmd)),
        }
    }
    Ok(())
}

/// 未以 quic feature 构建时的占位：给出明确提示
#[cfg(not(feature = "quic"))]
async fn run_quic(host: &str, port: u16) -> Result<(), Box<dyn std::error::Error>> {
    println!("QUIC 模式需要以 --features quic 构建: cargo build --release --features quic");
    println!("（目标 {host}:{port} 未连接）");
    Ok(())
}

/// 演示用证书校验器：跳过全部校验（仅供自签证书场景）
#[cfg(feature = "quic")]
struct SkipVerify;

#[cfg(feature = "quic")]
impl rustls::client::ServerCertVerifier for SkipVerify {
    fn verify_server_cert(
        &self,
        _end_entity: &rustls::Certificate,
        _intermediates: &[rustls::Certificate],
        _server_name: &rustls::ServerName,
        _scts: &mut dyn Iterator<Item = &[u8]>,
        _ocsp_response: &[u8],
        _now: std::time::SystemTime,
    ) -> Result<rustls::client::ServerCertVerified, rustls::Error> {
        Ok(rustls::client::ServerCertVerified::assertion())
    }
}
