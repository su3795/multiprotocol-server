//! 指标采集与 Prometheus 文本导出（对应 Java 版 `mp-observability`）。
//!
//! **零第三方依赖**：用原子变量 + 分桶直方图自行实现，
//! 确保离线也能构建。生产环境可替换为 `prometheus` crate，
//! 只需改动本 crate，业务埋点代码不变。
//!
//! 关键约束：埋点只做原子累加，绝不阻塞关键路径。

use std::collections::HashMap;
use std::sync::atomic::{AtomicI64, AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};
use std::time::Instant;

/// 耗时分桶边界（秒）
const BUCKETS: [f64; 12] = [
    0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5,
];

/// 原子计数器
#[derive(Default)]
pub struct Counter {
    v: AtomicI64,
}

impl Counter {
    pub fn inc(&self) { self.v.fetch_add(1, Ordering::Relaxed); }
    pub fn get(&self) -> i64 { self.v.load(Ordering::Relaxed) }
}

/// 可增减的瞬时值
#[derive(Default)]
pub struct Gauge {
    v: AtomicI64,
}

impl Gauge {
    pub fn inc(&self) { self.v.fetch_add(1, Ordering::Relaxed); }
    pub fn dec(&self) { self.v.fetch_sub(1, Ordering::Relaxed); }
    pub fn get(&self) -> i64 { self.v.load(Ordering::Relaxed) }
}

/// 分桶直方图
pub struct Histogram {
    counts: Vec<AtomicI64>,
    sum_ns: AtomicU64,
    count: AtomicI64,
}

impl Histogram {
    pub fn new() -> Self {
        Self {
            counts: (0..BUCKETS.len()).map(|_| AtomicI64::new(0)).collect(),
            sum_ns: AtomicU64::new(0),
            count: AtomicI64::new(0),
        }
    }

    /// 观测一次耗时（秒）
    pub fn observe(&self, secs: f64) {
        for (i, b) in BUCKETS.iter().enumerate() {
            if secs <= *b {
                self.counts[i].fetch_add(1, Ordering::Relaxed);
            }
        }
        self.count.fetch_add(1, Ordering::Relaxed);
        self.sum_ns.fetch_add((secs * 1e9) as u64, Ordering::Relaxed);
    }
}

impl Default for Histogram {
    fn default() -> Self { Self::new() }
}

/// 指标注册表
pub struct Metrics {
    counters: Mutex<HashMap<String, &'static Counter>>,
    gauges: Mutex<HashMap<String, &'static Gauge>>,
    hists: Mutex<HashMap<String, &'static Histogram>>,
    start: Instant,
}

fn leak<T>(v: T) -> &'static T { Box::leak(Box::new(v)) }

impl Metrics {
    fn new() -> Self {
        Self {
            counters: Mutex::new(HashMap::new()),
            gauges: Mutex::new(HashMap::new()),
            hists: Mutex::new(HashMap::new()),
            start: Instant::now(),
        }
    }

    pub fn counter(&self, key: &str) -> &'static Counter {
        let mut m = self.counters.lock().unwrap();
        *m.entry(key.to_string()).or_insert_with(|| leak(Counter::default()))
    }

    pub fn gauge(&self, key: &str) -> &'static Gauge {
        let mut m = self.gauges.lock().unwrap();
        *m.entry(key.to_string()).or_insert_with(|| leak(Gauge::default()))
    }

    pub fn hist(&self, key: &str) -> &'static Histogram {
        let mut m = self.hists.lock().unwrap();
        *m.entry(key.to_string()).or_insert_with(|| leak(Histogram::new()))
    }

    /// 生成 Prometheus 文本格式
    pub fn render(&self) -> String {
        let mut out = String::new();

        let counters = self.counters.lock().unwrap();
        let mut keys: Vec<_> = counters.keys().cloned().collect();
        keys.sort();
        for k in keys {
            let (name, labels) = split_key(&k);
            out.push_str(&format!("# TYPE {name} counter\n{name}{labels} {}\n",
                                  counters[&k].get()));
        }
        drop(counters);

        let gauges = self.gauges.lock().unwrap();
        let mut keys: Vec<_> = gauges.keys().cloned().collect();
        keys.sort();
        for k in keys {
            let (name, labels) = split_key(&k);
            out.push_str(&format!("# TYPE {name} gauge\n{name}{labels} {}\n",
                                  gauges[&k].get()));
        }
        drop(gauges);

        let hists = self.hists.lock().unwrap();
        let mut keys: Vec<_> = hists.keys().cloned().collect();
        keys.sort();
        for k in keys {
            let (name, labels) = split_key(&k);
            let h = hists[&k];
            out.push_str(&format!("# TYPE {name} histogram\n"));
            for (i, b) in BUCKETS.iter().enumerate() {
                out.push_str(&format!("{name}_bucket{},le=\"{b}\"}} {}\n",
                                      trim_labels(&labels), h.counts[i].load(Ordering::Relaxed)));
            }
            let sum_ns = h.sum_ns.load(Ordering::Relaxed);
            out.push_str(&format!("{name}_sum{labels} {}\n", sum_ns as f64 / 1e9));
            out.push_str(&format!("{name}_count{labels} {}\n",
                                  h.count.load(Ordering::Relaxed)));
        }
        drop(hists);

        out.push_str(&format!("# TYPE mp_uptime_seconds gauge\nmp_uptime_seconds {:.3}\n",
                              self.start.elapsed().as_secs_f64()));
        out
    }
}

fn split_key(k: &str) -> (String, String) {
    match k.find('{') {
        Some(i) => (k[..i].to_string(), k[i..].to_string()),
        None => (k.to_string(), String::new()),
    }
}

/// 把 `{a="b"}` 变成 `{a="b",`，用于追加 le 标签
fn trim_labels(labels: &str) -> String {
    if labels.is_empty() {
        return "{".to_string();
    }
    if labels.ends_with('}') {
        return format!("{},", &labels[..labels.len() - 1]);
    }
    labels.to_string()
}

/// 全局指标注册器
pub fn metrics() -> &'static Metrics {
    static M: OnceLock<Metrics> = OnceLock::new();
    M.get_or_init(Metrics::new)
}

// ---------------- 埋点 API ----------------

/// 请求计数，按协议与命令维度
pub fn inc_requests(proto: &str, cmd: &str) {
    metrics().counter(&format!("mp_requests_total{{proto=\"{proto}\",cmd=\"{cmd}\"}}")).inc();
}

/// 请求耗时（秒）
pub fn observe_request_duration(proto: &str, secs: f64) {
    metrics().hist(&format!("mp_request_duration{{proto=\"{proto}\"}}")).observe(secs);
}

/// 共识提交耗时（秒）
pub fn observe_propose_duration(secs: f64) {
    metrics().hist("mp_consensus_propose_duration").observe(secs);
}

/// 共识写失败计数
pub fn inc_propose_errors() {
    metrics().counter("mp_consensus_propose_errors_total").inc();
}

/// 连接建立
pub fn inc_connections() { metrics().gauge("mp_connections_active").inc(); }

/// 连接断开
pub fn dec_connections() { metrics().gauge("mp_connections_active").dec(); }

/// 当前连接数
pub fn connection_count() -> i64 { metrics().gauge("mp_connections_active").get() }
