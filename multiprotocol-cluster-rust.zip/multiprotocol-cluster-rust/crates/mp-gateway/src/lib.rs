//! Tokio 多协议接入层（对应 Java 版 `mp-gateway`）。
//!
//! 与 Java 版的差异：Java 用 Netty 的 EventLoop；Rust 用 Tokio 的
//! 异步任务 + work-stealing 调度器，天然支撑高并发长连接。
//! 分层保持一致：**分帧 → 路由 → 业务 → 回包**。
//!
//! 协议差异全部收敛在本层：上层 `RequestProcessor` 只见 `Frame`，
//! 新增协议（QUIC/KCP）只需实现对应的 `serve_*` 函数。
//!
//! ⚠️ **关键**：共识层的 `propose` 是同步阻塞的（基于 `std::thread`），
//! 必须用 `spawn_blocking` 包裹，否则会卡住同核上的其他异步任务，
//! 导致 P999 延迟爆炸。这是 Rust 异步服务最容易踩的坑。

pub mod kcp;
pub mod quic;

use crate::kcp::{Kcp, IKCP_OVERHEAD};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Mutex;
use std::time::{Duration, Instant};
use tokio::sync::mpsc;

use mp_common::{
    cmd_name, decode, encode, parse_key_value, Command, Frame, Protocol, CODE_BAD_REQUEST,
    CODE_INTERNAL, CODE_NOT_LEADER, CODE_OK, CMD_GET, CMD_PING, CMD_PUT, CMD_ROUTE_GET,
    CMD_ROUTE_SET, CMD_STATS, FLAG_NEED_RESPONSE, HEADER_SIZE,
};
use mp_consensus::Consensus;
use mp_observability::{
    connection_count, inc_propose_errors, inc_requests, observe_propose_duration,
    observe_request_duration,
};
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, UdpSocket};

/// 协议无关的业务处理器
pub struct RequestProcessor {
    consensus: Arc<dyn Consensus>,
}

impl RequestProcessor {
    pub fn new(consensus: Arc<dyn Consensus>) -> Self {
        Self { consensus }
    }

    /// 处理一帧，返回响应帧
    pub async fn process(&self, req: &Frame, proto: Protocol) -> Frame {
        let start = Instant::now();
        let p = proto.as_str();
        inc_requests(p, cmd_name(req.cmd));

        let resp = match req.cmd {
            CMD_PING => ok(req, "PONG"),

            CMD_PUT => {
                if !self.consensus.is_leader() {
                    err(req, CODE_NOT_LEADER, "not leader, retry on leader")
                } else {
                    let text = String::from_utf8_lossy(&req.payload).to_string();
                    match parse_key_value(&text) {
                        None => err(req, CODE_BAD_REQUEST, "expect key=value"),
                        Some((k, v)) => self.do_propose(req, Command::put_kv(&k, &v)).await,
                    }
                }
            }

            CMD_GET => {
                let key = String::from_utf8_lossy(&req.payload).to_string();
                let c = self.consensus.clone();
                match tokio::task::spawn_blocking(move || c.linearizable_get(&key)).await {
                    Ok(Ok(v)) => ok(req, &v),
                    Ok(Err(_)) => err(req, CODE_NOT_LEADER, "not leader"),
                    Err(_) => err(req, CODE_INTERNAL, "internal error"),
                }
            }

            CMD_ROUTE_SET => {
                if !self.consensus.is_leader() {
                    err(req, CODE_NOT_LEADER, "not leader")
                } else {
                    let text = String::from_utf8_lossy(&req.payload).to_string();
                    match parse_key_value(&text)
                        .and_then(|(k, v)| k.trim().parse::<i64>().ok().map(|id| (id, v)))
                    {
                        None => err(req, CODE_BAD_REQUEST, "expect shardId=node"),
                        Some((shard, node)) => {
                            self.do_propose(req, Command::upsert_route(shard, &node)).await
                        }
                    }
                }
            }

            CMD_ROUTE_GET => {
                let text = String::from_utf8_lossy(&req.payload).to_string();
                match text.trim().parse::<i64>() {
                    Err(_) => err(req, CODE_BAD_REQUEST, "shardId 必须为整数"),
                    Ok(shard) => match self.consensus.state_machine().route(shard) {
                        Some(node) => ok(req, &node),
                        None => ok(req, ""),
                    },
                }
            }

            CMD_STATS => {
                let stats = format!(
                    "impl={}, role={}, leader={}, connections={}, kvCount={}, routeCount={}",
                    self.consensus.implementation(),
                    self.consensus.role(),
                    self.consensus.is_leader(),
                    connection_count(),
                    self.consensus.state_machine().kv_count(),
                    self.consensus.state_machine().route_count(),
                );
                ok(req, &stats)
            }

            _ => err(req, CODE_BAD_REQUEST, &format!("unknown cmd {}", req.cmd)),
        };

        observe_request_duration(p, start.elapsed().as_secs_f64());
        resp
    }

    /// 提交到共识层（阻塞操作放到专用线程池）
    async fn do_propose(&self, req: &Frame, cmd: Command) -> Frame {
        let start = Instant::now();
        let c = self.consensus.clone();
        match tokio::task::spawn_blocking(move || c.propose(cmd)).await {
            Ok(Ok(msg)) => {
                observe_propose_duration(start.elapsed().as_secs_f64());
                ok(req, &msg)
            }
            Ok(Err(e)) => {
                inc_propose_errors();
                err(req, CODE_INTERNAL, &e.to_string())
            }
            Err(_) => {
                inc_propose_errors();
                err(req, CODE_INTERNAL, "task join error")
            }
        }
    }
}

/// 构造成功响应，格式与 Java/Go 一致："OK|body"
fn ok(req: &Frame, body: &str) -> Frame {
    Frame::new(FLAG_NEED_RESPONSE, CODE_OK, req.seq,
               format!("OK|{body}").into_bytes())
}

/// 构造错误响应："ERR|body"
fn err(req: &Frame, code: i32, body: &str) -> Frame {
    Frame::new(FLAG_NEED_RESPONSE, code, req.seq,
               format!("ERR|{body}").into_bytes())
}

// ---------------- TCP ----------------

/// 启动 TCP 接入。
///
/// TCP 是字节流，需处理粘包/半包：每条连接维护累积缓冲，用 `try_decode` 逐帧切出。
pub async fn serve_tcp(addr: &str, proc: Arc<RequestProcessor>) -> std::io::Result<()> {
    let listener = TcpListener::bind(addr).await?;
    println!("[gateway] TCP 接入已启动: {addr}");

    loop {
        let (mut socket, peer) = listener.accept().await?;
        let proc = proc.clone();
        mp_observability::inc_connections();

        tokio::spawn(async move {
            if let Err(e) = socket.set_nodelay(true) {
                eprintln!("[gateway] set_nodelay 失败: {e}");
            }
            let mut acc: Vec<u8> = Vec::with_capacity(8192);
            let mut tmp = vec![0u8; 64 * 1024];

            loop {
                match socket.read(&mut tmp).await {
                    Ok(0) => break,             // 对端关闭
                    Ok(n) => {
                        acc.extend_from_slice(&tmp[..n]);

                        // 尽最大可能切出完整帧
                        loop {
                            match mp_common::try_decode(&acc) {
                                Ok((frame, consumed)) => {
                                    acc.drain(..consumed);
                                    let resp = proc.process(&frame, Protocol::Tcp).await;
                                    if frame.need_response() {
                                        if let Ok(out) = encode(&resp) {
                                            if socket.write_all(&out).await.is_err() {
                                                break;
                                            }
                                        }
                                    }
                                }
                                Err(mp_common::DecodeError::TooShort) => break, // 半包，继续读
                                Err(_) => {                                     // 协议错误，断连
                                    eprintln!("[gateway] 协议错误，断开 {peer}");
                                    return;
                                }
                            }
                        }
                    }
                    Err(_) => break,
                }
            }
            mp_observability::dec_connections();
        });
    }
}

// ---------------- UDP ----------------

/// 启动 UDP 接入。
///
/// UDP 是数据报，天然分帧、无队头阻塞，直接整包解码即可。
/// 注意：UDP 无连接，回包必须携带发送方地址。
pub async fn serve_udp(addr: &str, proc: Arc<RequestProcessor>) -> std::io::Result<()> {
    let socket = Arc::new(UdpSocket::bind(addr).await?);
    println!("[gateway] UDP 接入已启动: {addr}");

    let mut buf = vec![0u8; 2048];
    loop {
        let (n, peer) = match socket.recv_from(&mut buf).await {
            Ok(v) => v,
            Err(_) => continue,
        };
        let raw = buf[..n].to_vec();
        let proc = proc.clone();
        let socket = socket.clone();

        tokio::spawn(async move {
            let frame = match decode(&raw) {
                Ok(f) => f,
                Err(_) => return, // 坏包静默丢弃
            };
            let resp = proc.process(&frame, Protocol::Udp).await;
            if let Ok(out) = encode(&resp) {
                let _ = socket.send_to(&out, peer).await;
            }
        });
    }
}

/// 启动自定义协议接入（UDP 变体）。
///
/// 复用 UDP 承载，payload 层可叠加私有混淆/加密。
/// 帧格式保持不变，因此与 Java / Go 版互通。
pub async fn serve_custom(addr: &str, proc: Arc<RequestProcessor>) -> std::io::Result<()> {
    println!("[gateway] CUSTOM 接入已启动(UDP 变体): {addr}");
    serve_udp(addr, proc).await
}

/// 解析地址字符串（辅助）
#[allow(dead_code)]
pub fn parse_addr(s: &str) -> Option<SocketAddr> {
    s.parse().ok()
}

/// 头部长度（辅助，供客户端使用）
#[allow(dead_code)]
pub fn header_size() -> usize { HEADER_SIZE }

// ---------------- KCP（可靠 UDP） ----------------

/// 启动 KCP 接入（运行在 UDP 之上）。
///
/// 与裸 UDP 的差异：KCP 提供**可靠、有序、带重传**的字节流，
/// 上层不再需要关心丢包与乱序，但仍保留 UDP 的低延迟特性
/// （无队头阻塞、RTO 增长更温和）。
///
/// 会话键：对端地址 + 包内 conv。
pub async fn serve_kcp(addr: &str, proc: Arc<RequestProcessor>) -> std::io::Result<()> {
    let socket = Arc::new(UdpSocket::bind(addr).await?);
    println!("[gateway] KCP 接入已启动(基于 UDP): {addr}");

    // 对端地址 → 会话任务的消息通道
    let sessions: Arc<Mutex<HashMap<SocketAddr, mpsc::Sender<Vec<u8>>>>> =
        Arc::new(Mutex::new(HashMap::new()));

    let mut buf = vec![0u8; 2048];
    loop {
        let (n, peer) = match socket.recv_from(&mut buf).await {
            Ok(v) => v,
            Err(_) => continue,
        };
        let raw = buf[..n].to_vec();

        let tx = {
            let mut m = sessions.lock().unwrap();
            if let Some(tx) = m.get(&peer) {
                tx.clone()
            } else {
                // 首个包：从包头读取 conv 建立会话
                if raw.len() < IKCP_OVERHEAD {
                    continue;
                }
                let conv = u32::from_le_bytes([raw[0], raw[1], raw[2], raw[3]]);
                let (tx, rx) = mpsc::channel(256);
                m.insert(peer, tx.clone());
                tokio::spawn(run_kcp_session(peer, conv, rx, socket.clone(), proc.clone()));
                tx
            }
        };

        // 队列满则丢弃，KCP 自身会重传
        let _ = tx.try_send(raw);
    }
}

/// 单个 KCP 会话：专属任务串行驱动，避免锁竞争
async fn run_kcp_session(
    peer: SocketAddr,
    conv: u32,
    mut rx: mpsc::Receiver<Vec<u8>>,
    socket: Arc<UdpSocket>,
    proc: Arc<RequestProcessor>,
) {
    let mut kcp = Kcp::new(conv);
    let start = Instant::now();
    let mut ticker = tokio::time::interval(Duration::from_millis(10)); // 10ms 驱动

    loop {
        tokio::select! {
            // 收到 UDP 数据报 → 交给 KCP
            Some(pkt) = rx.recv() => {
                if kcp.input(&pkt).is_ok() {
                    drain_and_process(&mut kcp, &proc).await;
                }
                let out = kcp.flush();
                if !out.is_empty() {
                    let _ = socket.send_to(&out, peer).await;
                }
            }
            // 定时驱动时钟（触发重传与 ACK）
            _ = ticker.tick() => {
                let now = start.elapsed().as_millis() as u32;
                let out = kcp.update(now);
                if !out.is_empty() {
                    let _ = socket.send_to(&out, peer).await;
                }
                drain_and_process(&mut kcp, &proc).await;
            }
        }
    }
}

/// 取出完整消息 → 解码帧 → 业务处理 → 回包
async fn drain_and_process(kcp: &mut Kcp, proc: &Arc<RequestProcessor>) {
    while let Some(msg) = kcp.recv() {
        if let Ok(frame) = decode(&msg) {
            let resp = proc.process(&frame, Protocol::Kcp).await;
            if let Ok(out) = encode(&resp) {
                let _ = kcp.send(&out);
            }
        }
    }
}
