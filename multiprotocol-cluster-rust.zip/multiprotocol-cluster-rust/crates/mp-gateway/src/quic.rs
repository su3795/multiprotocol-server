//! QUIC 接入（需 feature `quic`，基于 quinn）。
//!
//! # 为什么默认不启用
//!
//! QUIC 需要 `quinn` + `rustls` + `rcgen` 三组依赖，且涉及 TLS 1.3
//! 与异步握手。为保持默认构建轻量，本模块通过 feature 隔离：
//!
//! ```bash
//! cargo build --release --features quic
//! ```
//!
//! # QUIC 相比 TCP 的核心优势
//!
//! - **0-RTT / 1-RTT 握手**：连接建立延迟显著低于 TCP+TLS
//! - **无队头阻塞**：多路复用流相互独立，单流丢包不阻塞其他流
//! - **连接迁移**：网络切换（WiFi↔4G）时连接不断开
//!
//! # 与 TCP 接入的差异
//!
//! QUIC 以「流（stream）」为单位。本实现为每条双向流独立解析帧，
//! 帧格式与 TCP/UDP/KCP **完全一致**，因此上层 `RequestProcessor` 无需改动。
//!
//! ⚠️ **版本提示**：quinn 0.10 与 0.11 的 `Endpoint::server` 签名不同
//! （0.10 返回 `(Endpoint, Incoming)`，0.11 改为 `Endpoint::accept`）。
//! 本实现基于 **quinn 0.10**，若使用 0.11 请对照官方 example 调整。

#![cfg(feature = "quic")]

use crate::RequestProcessor;
use mp_common::{decode, encode, try_decode, DecodeError, Protocol};
use std::net::SocketAddr;
use std::sync::Arc;

/// 启动 QUIC 接入
pub async fn serve_quic(addr: &str, proc: Arc<RequestProcessor>) -> std::io::Result<()> {
    let bind: SocketAddr = addr.parse().map_err(std::io::Error::other)?;

    let (endpoint, mut incoming) = {
        let config = server_config()?;
        quinn::Endpoint::server(config, bind)
            .map_err(|e| std::io::Error::other(format!("QUIC 端点创建失败: {e}")))?
    };
    println!("[gateway] QUIC 接入已启动: {addr} (自签证书，仅供演示)");

    while let Some(conn) = incoming.next().await {
        let proc = proc.clone();
        tokio::spawn(async move {
            match conn.await {
                Ok(connection) => {
                    mp_observability::inc_connections();
                    handle_connection(connection, proc).await;
                    mp_observability::dec_connections();
                }
                Err(e) => eprintln!("[gateway] QUIC 连接失败: {e}"),
            }
        });
    }
    Ok(())
}

/// 处理一个 QUIC 连接：为每条双向流分配独立任务
async fn handle_connection(connection: quinn::Connection, proc: Arc<RequestProcessor>) {
    loop {
        match connection.accept_bi().await {
            Ok((send, recv)) => {
                let proc = proc.clone();
                tokio::spawn(async move { handle_stream(send, recv, proc).await });
            }
            Err(quinn::ConnectionError::ApplicationClosed { .. }) => break,
            Err(e) => {
                eprintln!("[gateway] QUIC 流接受失败: {e}");
                break;
            }
        }
    }
}

/// 在单条双向流上按帧处理。
///
/// QUIC 流是字节流，需要像 TCP 一样处理粘包/半包：
/// 维护累积缓冲，用 `try_decode` 逐帧切出。
async fn handle_stream(
    mut send: quinn::SendStream,
    mut recv: quinn::RecvStream,
    proc: Arc<RequestProcessor>,
) {
    let mut acc: Vec<u8> = Vec::with_capacity(8192);
    let mut tmp = vec![0u8; 64 * 1024];

    loop {
        match recv.read(&mut tmp).await {
            Ok(Some(n)) => {
                acc.extend_from_slice(&tmp[..n]);

                loop {
                    match try_decode(&acc) {
                        Ok((frame, consumed)) => {
                            acc.drain(..consumed);
                            let resp = proc.process(&frame, Protocol::Quic).await;
                            if let Ok(out) = encode(&resp) {
                                if send.write_all(&out).await.is_err() {
                                    return;
                                }
                            }
                        }
                        Err(DecodeError::TooShort) => break, // 半包，继续读
                        Err(_) => return,                    // 协议错误
                    }
                }
            }
            Ok(None) => break, // 流结束
            Err(_) => break,
        }
    }
    let _ = send.finish().await;
}

/// 构造 QUIC 服务端配置（自签证书，仅供演示）
fn server_config() -> std::io::Result<quinn::ServerConfig> {
    // 生成自签证书：QUIC 强制 TLS 1.3
    let cert = rcgen::generate_simple_self_signed(vec!["localhost".to_string()])
        .map_err(std::io::Error::other)?;
    let cert_der = cert.cert.der().to_vec();
    let key_der = cert.key_pair.serialize_der();

    let cert_chain = vec![rustls::Certificate(cert_der)];
    let key = rustls::PrivateKey(key_der);

    let mut server_crypto = rustls::ServerConfig::builder()
        .with_safe_defaults()
        .with_no_client_auth()
        .with_single_cert(cert_chain, key)
        .map_err(|e| std::io::Error::other(format!("TLS 配置失败: {e}")))?;

    // QUIC 强制 TLS 1.3
    server_crypto.alpn_protocols = vec![b"mp".to_vec()];

    let mut transport = quinn::TransportConfig::default();
    transport.max_idle_timeout(Some(
        std::time::Duration::from_secs(30)
            .try_into()
            .map_err(std::io::Error::other)?,
    ));

    let mut cfg = quinn::ServerConfig::with_crypto(Arc::new(server_crypto));
    cfg.transport = Arc::new(transport);
    Ok(cfg)
}

/// 确认 decode 在本模块被引用（避免 unused import 警告）
#[allow(dead_code)]
fn _assert_decode_used(b: &[u8]) -> Option<mp_common::Frame> {
    decode(b).ok()
}
