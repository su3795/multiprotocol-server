//! KCP 协议实现（纯算法 ARQ，运行在 UDP 之上，零第三方依赖）。
//!
//! KCP 是一个**纯算法**的可靠传输协议：不依赖任何系统调用，只做
//! 分片 / 编号 / 确认 / 重传 / 重组。它以「多花 10%~20% 带宽换取
//! 30%~40% 延迟降低」著称。
//!
//! # 与 TCP 的关键差异（决定适用场景）
//!
//! | 机制 | TCP | KCP |
//! |---|---|---|
//! | RTO 增长 | ×2 | ×1.5（重传更激进） |
//! | 丢包重传 | 重传该段之后全部 | **选择性重传**，只重传丢失段 |
//! | 快速重传 | 依赖 dup ACK | 累计阈值即触发，不等超时 |
//! | 拥塞控制 | 强制退让 | 可关闭（实时优先） |
//!
//! **适用**：实时对战、音视频信令、弱网 RPC。
//! **不适用**：大文件传输、带宽敏感的公网批量传输。
//!
//! 线格式与 Go 版完全一致，两版可互通。

/// 推送数据
pub const IKCP_CMD_PUSH: u8 = 81;
/// 确认
pub const IKCP_CMD_ACK: u8 = 82;
/// 窗口探测询问
pub const IKCP_CMD_WASK: u8 = 83;
/// 窗口大小告知
pub const IKCP_CMD_WINS: u8 = 84;
/// 单段头部长度
pub const IKCP_OVERHEAD: usize = 24;

const IKCP_MTU_DEF: u32 = 1400;
const IKCP_WND_SND: u32 = 32;
const IKCP_WND_RCV: u32 = 128;
const IKCP_RTO_MIN: u32 = 30;
const IKCP_RTO_DEF: u32 = 200;
const IKCP_INTERVAL: u32 = 100;
const IKCP_DEAD_LINK: u32 = 20;
const IKCP_FAST_ACK_LIMIT: u32 = 3;
const IKCP_MAX_FRG: usize = 255;

/// KCP 错误
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum KcpError {
    /// 连接已关闭
    Closed,
    /// 消息过大，分片数超过 255
    TooLarge,
    /// conv 不匹配
    BadConv,
    /// 数据报长度不足
    Truncated,
    /// 未知命令
    UnknownCmd(u8),
}

impl std::fmt::Display for KcpError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            KcpError::Closed => write!(f, "kcp: 连接已关闭"),
            KcpError::TooLarge => write!(f, "kcp: 消息过大，分片数超过 255"),
            KcpError::BadConv => write!(f, "kcp: conv 不匹配"),
            KcpError::Truncated => write!(f, "kcp: 数据报长度不足"),
            KcpError::UnknownCmd(c) => write!(f, "kcp: 未知命令 {c}"),
        }
    }
}

impl std::error::Error for KcpError {}

/// 计算两个 32 位时间戳的有序差值（正确处理回绕）
#[inline]
pub fn itimediff(later: u32, earlier: u32) -> i32 { later.wrapping_sub(earlier) as i32 }

/// KCP 段
#[derive(Clone)]
pub struct Segment {
    pub conv: u32,
    pub cmd: u8,
    /// 分片序号，从 count-1 递减到 0；0 表示最后一个分片
    pub frg: u8,
    pub wnd: u16,
    pub ts: u32,
    pub sn: u32,
    pub una: u32,
    pub data: Vec<u8>,

    // 发送侧状态
    pub rto: u32,
    pub xmit: u32,
    pub resendts: u32,
    pub fastack: u32,
}

impl Segment {
    /// 编码为字节（小端序，与 KCP 规范、Go 版一致）
    pub fn encode(&self) -> Vec<u8> {
        let mut b = Vec::with_capacity(IKCP_OVERHEAD + self.data.len());
        b.extend_from_slice(&self.conv.to_le_bytes());
        b.push(self.cmd);
        b.push(self.frg);
        b.extend_from_slice(&self.wnd.to_le_bytes());
        b.extend_from_slice(&self.ts.to_le_bytes());
        b.extend_from_slice(&self.sn.to_le_bytes());
        b.extend_from_slice(&self.una.to_le_bytes());
        b.extend_from_slice(&(self.data.len() as u32).to_le_bytes());
        b.extend_from_slice(&self.data);
        b
    }
}

/// KCP 控制块。
///
/// 并发约定：方法非线程安全，由调用方保证串行访问。
/// 接入层为每个会话分配专属任务串行驱动，因此外部用 `Mutex` 包一层即可。
pub struct Kcp {
    conv: u32,
    #[allow(dead_code)]
    mtu: u32,
    mss: u32,

    snd_una: u32,
    snd_nxt: u32,
    rcv_nxt: u32,

    rto: u32,
    min_rto: u32,
    srtt: u32,
    rttval: u32,

    snd_wnd: u32,
    rcv_wnd: u32,
    rmt_wnd: u32,
    cwnd: u32,

    current: u32,
    interval: u32,
    ts_flush: u32,

    snd_buf: Vec<Segment>,
    rcv_buf: Vec<Segment>,
    snd_queue: Vec<Segment>,
    rcv_queue: Vec<Segment>,

    ack_list: Vec<(u32, u32)>,

    probe_need_send: u32,
    probe_wait: u32,

    dead_link: u32,
    #[allow(dead_code)]
    xmit: u32,
    state: u32,
    fast_resend: u32,
    #[allow(dead_code)]
    no_delay: u32,
}

impl Kcp {
    /// 创建 KCP 控制块（默认开启 nodelay：低延迟优先）
    pub fn new(conv: u32) -> Self {
        Self {
            conv,
            mtu: IKCP_MTU_DEF,
            mss: IKCP_MTU_DEF - IKCP_OVERHEAD as u32,
            snd_una: 0,
            snd_nxt: 0,
            rcv_nxt: 0,
            rto: IKCP_RTO_DEF,
            min_rto: IKCP_RTO_MIN,
            srtt: 0,
            rttval: 0,
            snd_wnd: IKCP_WND_SND,
            rcv_wnd: IKCP_WND_RCV,
            rmt_wnd: IKCP_WND_RCV,
            cwnd: 0,
            current: 0,
            interval: IKCP_INTERVAL,
            ts_flush: 0,
            snd_buf: Vec::new(),
            rcv_buf: Vec::new(),
            snd_queue: Vec::new(),
            rcv_queue: Vec::new(),
            ack_list: Vec::new(),
            probe_need_send: 0,
            probe_wait: 0,
            dead_link: IKCP_DEAD_LINK,
            xmit: 0,
            state: 0,
            fast_resend: IKCP_FAST_ACK_LIMIT,
            no_delay: 1,
        }
    }

    /// 是否已关闭
    pub fn is_closed(&self) -> bool { self.state != 0 }

    /// 剩余可通告的接收窗口
    fn wnd_avail(&self) -> u16 {
        let avail = self.rcv_wnd as i32 - self.rcv_queue.len() as i32;
        if avail < 0 { 0 } else if avail > 65535 { 65535 } else { avail as u16 }
    }

    // ---------------- 接收侧 ----------------

    /// 处理收到的一个 UDP 数据报（可能含多个 KCP 段）
    pub fn input(&mut self, data: &[u8]) -> Result<(), KcpError> {
        if self.state != 0 {
            return Err(KcpError::Closed);
        }
        let old_una = self.snd_una;
        let mut offset = 0usize;

        while offset + IKCP_OVERHEAD <= data.len() {
            let d = &data[offset..];
            let conv = u32::from_le_bytes([d[0], d[1], d[2], d[3]]);
            if conv != self.conv {
                return Err(KcpError::BadConv);
            }
            let cmd = d[4];
            let frg = d[5];
            let wnd = u16::from_le_bytes([d[6], d[7]]);
            let ts = u32::from_le_bytes([d[8], d[9], d[10], d[11]]);
            let sn = u32::from_le_bytes([d[12], d[13], d[14], d[15]]);
            let una = u32::from_le_bytes([d[16], d[17], d[18], d[19]]);
            let len = u32::from_le_bytes([d[20], d[21], d[22], d[23]]) as usize;

            if d.len() < IKCP_OVERHEAD + len {
                return Err(KcpError::Truncated);
            }
            let payload = d[IKCP_OVERHEAD..IKCP_OVERHEAD + len].to_vec();
            offset += IKCP_OVERHEAD + len;

            self.rmt_wnd = wnd as u32;
            self.parse_una(una);

            match cmd {
                IKCP_CMD_ACK => {
                    if itimediff(sn, self.snd_una) < 0 || itimediff(sn, self.snd_nxt) >= 0 {
                        continue;
                    }
                    self.snd_buf.retain(|s| s.sn != sn);
                    let rtt = itimediff(self.current, ts) as u32;
                    self.update_rtt(rtt);
                    self.shrink_buf();
                }

                IKCP_CMD_PUSH => {
                    if itimediff(sn, self.rcv_nxt + self.rcv_wnd) < 0 {
                        self.ack_list.push((sn, ts));
                    }
                    if itimediff(sn, self.rcv_nxt) >= 0 {
                        let dup = self.rcv_buf.iter().any(|s| s.sn == sn);
                        if !dup {
                            let seg = Segment {
                                conv, cmd, frg, wnd, ts, sn, una,
                                data: payload,
                                rto: 0, xmit: 0, resendts: 0, fastack: 0,
                            };
                            // 按 sn 升序插入，保持有序
                            let pos = self
                                .rcv_buf
                                .iter()
                                .position(|s| itimediff(sn, s.sn) < 0)
                                .unwrap_or(self.rcv_buf.len());
                            self.rcv_buf.insert(pos, seg);
                        }
                    }
                }

                IKCP_CMD_WASK => { self.probe_need_send = 1; }

                IKCP_CMD_WINS => { self.rmt_wnd = wnd as u32; }

                other => return Err(KcpError::UnknownCmd(other)),
            }

            self.move_rcv_buf();
        }

        if itimediff(self.snd_una, old_una) > 0 && self.cwnd < self.rmt_wnd {
            self.cwnd += 1;
        }

        // 收到数据后尽快 flush，降低 ACK 延迟
        self.ts_flush = self.current;
        Ok(())
    }

    fn parse_una(&mut self, una: u32) {
        self.snd_buf.retain(|s| itimediff(s.sn, una) >= 0);
        self.snd_una = una;
    }

    fn shrink_buf(&mut self) {
        self.snd_una = self.snd_buf.first().map(|s| s.sn).unwrap_or(self.snd_nxt);
    }

    fn update_rtt(&mut self, rtt: u32) {
        if self.srtt == 0 {
            self.srtt = rtt;
            self.rttval = rtt / 2;
        } else {
            let delta = if rtt > self.srtt { rtt - self.srtt } else { self.srtt - rtt };
            self.rttval = (3 * self.rttval + delta) / 4;
            self.srtt = (7 * self.srtt + rtt) / 8;
        }
        let mut rto = self.srtt + self.interval.max(4 * self.rttval);
        if rto < self.min_rto {
            rto = self.min_rto;
        }
        self.rto = rto;
    }

    /// 将 rcv_buf 中 sn 连续的段移入 rcv_queue
    fn move_rcv_buf(&mut self) {
        while let Some(seg) = self.rcv_buf.first() {
            if seg.sn == self.rcv_nxt && (self.rcv_queue.len() as u32) < self.rcv_wnd {
                let seg = self.rcv_buf.remove(0);
                self.rcv_queue.push(seg);
                self.rcv_nxt = self.rcv_nxt.wrapping_add(1);
            } else {
                break;
            }
        }
    }

    /// 取出一条完整消息；返回 `None` 表示暂无完整消息（半包或乱序未补齐）
    pub fn recv(&mut self) -> Option<Vec<u8>> {
        if self.state != 0 || self.rcv_queue.is_empty() {
            return None;
        }
        // 找到第一个 frg==0 的段，确定整条消息边界
        let mut count = 0usize;
        let mut found = false;
        for seg in self.rcv_queue.iter() {
            count += 1;
            if seg.frg == 0 {
                found = true;
                break;
            }
        }
        if !found {
            return None; // 最后一个分片还没到
        }

        let mut out = Vec::new();
        for seg in self.rcv_queue.iter().take(count) {
            out.extend_from_slice(&seg.data);
        }
        self.rcv_queue.drain(..count);
        Some(out)
    }

    // ---------------- 发送侧 ----------------

    /// 发送一条消息（自动分片）
    pub fn send(&mut self, data: &[u8]) -> Result<(), KcpError> {
        if self.state != 0 {
            return Err(KcpError::Closed);
        }
        let mss = self.mss as usize;
        let mut count = (data.len() + mss - 1) / mss;
        if count == 0 {
            count = 1;
        }
        if count > IKCP_MAX_FRG {
            return Err(KcpError::TooLarge);
        }

        let mut offset = 0usize;
        for i in 0..count {
            let size = mss.min(data.len() - offset);
            let chunk = data[offset..offset + size].to_vec();
            offset += size;
            self.snd_queue.push(Segment {
                conv: self.conv,
                cmd: IKCP_CMD_PUSH,
                frg: (count - 1 - i) as u8, // 最后一个分片 frg=0
                wnd: 0,
                ts: 0,
                sn: 0,
                una: 0,
                data: chunk,
                rto: 0, xmit: 0, resendts: 0, fastack: 0,
            });
        }
        Ok(())
    }

    /// 把待发送数据打包；返回待发出的字节（可能为空）。
    /// 由调用方负责实际发送（这样避免了回调的所有权问题）。
    pub fn flush(&mut self) -> Vec<u8> {
        if self.state != 0 {
            return Vec::new();
        }
        let current = self.current;
        let mut buffer = Vec::new();

        // 1. 发送 ACK
        let acks: Vec<(u32, u32)> = self.ack_list.drain(..).collect();
        for (sn, ts) in acks {
            let seg = Segment {
                conv: self.conv,
                cmd: IKCP_CMD_ACK,
                frg: 0,
                wnd: self.wnd_avail(),
                ts,
                sn,
                una: self.rcv_nxt,
                data: Vec::new(),
                rto: 0, xmit: 0, resendts: 0, fastack: 0,
            };
            buffer.extend_from_slice(&seg.encode());
        }

        // 2. 窗口探测
        if self.rmt_wnd == 0 {
            if self.probe_wait == 0 {
                self.probe_wait = self.interval;
                self.probe_need_send = 1;
            } else {
                self.probe_wait -= 1;
            }
        } else {
            self.probe_wait = 0;
        }
        if self.probe_need_send == 1 {
            let seg = Segment {
                conv: self.conv,
                cmd: IKCP_CMD_WASK,
                frg: 0,
                wnd: self.wnd_avail(),
                ts: 0, sn: 0,
                una: self.rcv_nxt,
                data: Vec::new(),
                rto: 0, xmit: 0, resendts: 0, fastack: 0,
            };
            buffer.extend_from_slice(&seg.encode());
            self.probe_need_send = 0;
        }

        // 3. 计算可用窗口
        let mut cwnd = self.snd_una.wrapping_add(self.cwnd);
        if self.cwnd == 0 {
            cwnd = self.snd_una.wrapping_add(1); // 探测一个段
        }
        if self.rmt_wnd > 0 && itimediff(self.snd_una.wrapping_add(self.rmt_wnd), cwnd) < 0 {
            cwnd = self.snd_una.wrapping_add(self.rmt_wnd);
        }

        // 4. 从 snd_queue 移入 snd_buf（受窗口限制）
        while !self.snd_queue.is_empty() {
            if itimediff(self.snd_nxt, cwnd) >= 0 {
                break;
            }
            let mut seg = self.snd_queue.remove(0);
            seg.conv = self.conv;
            seg.cmd = IKCP_CMD_PUSH;
            seg.wnd = self.wnd_avail();
            seg.ts = current;
            seg.sn = self.snd_nxt;
            self.snd_nxt = self.snd_nxt.wrapping_add(1);
            seg.una = self.rcv_nxt;
            seg.rto = self.rto;
            seg.resendts = current.wrapping_add(self.rto);
            seg.fastack = 0;
            seg.xmit = 0;
            self.snd_buf.push(seg);
        }

        // 5. 发送 snd_buf 中需要发出的段
        let fast_resend = self.fast_resend;
        let mut to_send: Vec<usize> = Vec::new();
        for (i, seg) in self.snd_buf.iter_mut().enumerate() {
            let mut need = false;
            if seg.xmit == 0 {
                need = true;
                seg.rto = self.rto;
                seg.resendts = current.wrapping_add(self.rto);
            } else if itimediff(current, seg.resendts) >= 0 {
                // 超时重传：RTO ×1.5（TCP 是 ×2，KCP 更激进）
                need = true;
                seg.rto = seg.rto + seg.rto / 2;
                if seg.rto > 60000 {
                    seg.rto = 60000;
                }
                seg.resendts = current.wrapping_add(seg.rto);
            } else if fast_resend > 0 && seg.fastack >= fast_resend {
                // 快速重传：不等超时立即重发
                need = true;
                seg.fastack = 0;
                seg.resendts = current.wrapping_add(seg.rto);
            }
            if need {
                seg.ts = current;
                seg.wnd = self.wnd_avail();
                seg.una = self.rcv_nxt;
                seg.xmit += 1;
                if self.dead_link > 0 && seg.xmit >= self.dead_link {
                    self.state = 1; // 判定链路断开
                }
                to_send.push(i);
            }
        }
        for i in to_send {
            buffer.extend_from_slice(&self.snd_buf[i].encode());
        }

        buffer
    }

    /// 驱动 KCP 时钟，返回待发送的字节（可能为空）
    pub fn update(&mut self, current: u32) -> Vec<u8> {
        self.current = current;
        if self.ts_flush == 0 {
            self.ts_flush = current;
        }
        if itimediff(current, self.ts_flush) >= 0 {
            self.ts_flush = current.wrapping_add(self.interval);
            self.flush()
        } else {
            Vec::new()
        }
    }

    /// 当前时间戳（ms）
    pub fn current(&self) -> u32 { self.current }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 用一对 KCP 实例模拟双向传输（A → B 单向验证）
    #[test]
    fn basic_send_recv() {
        let mut a = Kcp::new(1);
        let mut b = Kcp::new(1);
        let msg = b"hello kcp";
        a.send(msg).unwrap();

        let out = a.update(0);
        assert!(!out.is_empty(), "应有数据待发送");

        b.input(&out).unwrap();
        let got = b.recv().expect("应收到完整消息");
        assert_eq!(got, msg);
    }

    #[test]
    fn large_message_fragments_and_reassembles() {
        let mut a = Kcp::new(2);
        let mut b = Kcp::new(2);
        // 造一条超过单个 MSS 的消息（mss = 1400-24 = 1376）
        let msg: Vec<u8> = (0..5000u32).map(|i| (i % 251) as u8).collect();
        a.send(&msg).unwrap();

        let mut collected = Vec::new();
        for t in 0..50u32 {
            let out = a.update(t * 10);
            if !out.is_empty() {
                b.input(&out).unwrap();
            }
            while let Some(m) = b.recv() {
                collected.extend_from_slice(&m);
            }
            if collected.len() >= msg.len() {
                break;
            }
        }
        assert_eq!(collected.len(), msg.len());
        assert_eq!(collected, msg);
    }

    #[test]
    fn packet_loss_is_recovered_by_retransmit() {
        let mut a = Kcp::new(3);
        let mut b = Kcp::new(3);
        let msg: Vec<u8> = (0..3000u32).map(|i| (i % 251) as u8).collect();
        a.send(&msg).unwrap();

        let mut collected = Vec::new();
        let mut t = 0u32;
        // 前 3 次 flush 全部丢弃（模拟连续丢包），之后正常送达
        for round in 0..80u32 {
            let out = a.update(t);
            if !out.is_empty() && round >= 3 {
                b.input(&out).unwrap();
            }
            // B 的 ACK 需要回给 A（单向测试中手动回灌）
            let back = b.update(t);
            if !back.is_empty() && round >= 3 {
                a.input(&back).unwrap();
            }
            while let Some(m) = b.recv() {
                collected.extend_from_slice(&m);
            }
            if collected.len() >= msg.len() {
                break;
            }
            t += 20;
        }
        assert_eq!(collected.len(), msg.len(), "丢包后应通过重传补齐");
        assert_eq!(collected, msg);
    }

    #[test]
    fn rejects_wrong_conv() {
        let mut a = Kcp::new(10);
        let mut b = Kcp::new(11);
        a.send(b"x").unwrap();
        let out = a.update(0);
        assert_eq!(b.input(&out), Err(KcpError::BadConv));
    }

    #[test]
    fn rejects_oversized_message() {
        let mut a = Kcp::new(12);
        let huge = vec![0u8; 1376 * 256]; // 分片数超过 255
        assert_eq!(a.send(&huge), Err(KcpError::TooLarge));
    }

    #[test]
    fn segment_encode_is_little_endian_24byte_header() {
        let seg = Segment {
            conv: 0x11223344, cmd: IKCP_CMD_PUSH, frg: 0, wnd: 32,
            ts: 1000, sn: 7, una: 5, data: b"ab".to_vec(),
            rto: 0, xmit: 0, resendts: 0, fastack: 0,
        };
        let b = seg.encode();
        assert_eq!(b.len(), 24 + 2);
        assert_eq!(&b[0..4], &[0x44, 0x33, 0x22, 0x11]); // conv 小端
        assert_eq!(b[4], IKCP_CMD_PUSH);
        assert_eq!(&b[20..24], &[2, 0, 0, 0]); // len=2 小端
        assert_eq!(&b[24..], b"ab");
    }

    #[test]
    fn itimediff_handles_wraparound() {
        // 跨越 2^32 回绕仍应得到正确符号
        assert!(itimediff(5, 3) > 0);
        assert!(itimediff(3, 5) < 0);
        assert!(itimediff(2, u32::MAX) > 0, "回绕后 2 应晚于 u32::MAX");
    }
}
