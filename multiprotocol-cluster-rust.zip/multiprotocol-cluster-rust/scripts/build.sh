#!/usr/bin/env bash
# 构建 Rust 版（需要 Rust 1.70+ 与联网拉取 tokio）
set -euo pipefail
cd "$(dirname "$0")/.."
echo ">>> 构建 multiprotocol-cluster-rust ..."
cargo build --release
echo ">>> 产物:"
ls -lh target/release/mp-server
