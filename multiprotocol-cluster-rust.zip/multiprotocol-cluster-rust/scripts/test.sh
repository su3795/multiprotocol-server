#!/usr/bin/env bash
# 契约自测：帧编解码必须与 Java / Go 版字节级一致
set -euo pipefail
cd "$(dirname "$0")/.."
cargo test -p mp-common -p mp-consensus -- --nocapture
