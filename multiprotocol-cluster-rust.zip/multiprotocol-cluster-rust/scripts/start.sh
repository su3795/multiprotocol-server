#!/usr/bin/env bash
# 启动单节点（内存 Raft 集群，单进程内 3 副本）
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs

echo ">>> 启动节点: TCP=9101 UDP=9201 CUSTOM=9301 KCP=9401 metrics=9091"
nohup ./target/release/mp-server \
    --node-id 0 \
    --members 0,1,2 \
    --tcp 127.0.0.1:9101 \
    --udp 127.0.0.1:9201 \
    --custom 127.0.0.1:9301 \
    --kcp 127.0.0.1:9401 \
    --metrics-port 9091 \
    > logs/server.log 2>&1 &
echo $! > logs/server.pid

echo ">>> 提示: QUIC 需 --features quic 构建，启用后加 --quic 127.0.0.1:9501"
echo ">>>      cargo build --release --features quic"
echo ">>> 等待选举完成..."
sleep 3
grep -E "成为 Leader|节点就绪" logs/server.log || tail -20 logs/server.log
