package io.mp.gateway.kcp;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * KCP 协议单元测试。
 *
 * <p>验证目标：与 Go 版 {@code internal/gateway/kcp.go}、
 * Rust 版 {@code crates/mp-gateway/src/kcp.rs} 行为一致。
 * 三版共用同一套常量与算法，测试场景也应覆盖相同用例。
 */
class KcpControlTest {

    /** 驱动 A 发送、B 接收，直到 B 收满 expectedLen 字节或超过 maxRounds */
    private static byte[] pump(KcpControl a, KcpControl b, int expectedLen,
                               int maxRounds, int dropBeforeRound) {
        byte[] got = new byte[0];
        for (int round = 0; round < maxRounds; round++) {
            long now = (long) round * KcpControl.IKCP_INTERVAL;

            byte[] out = a.update(now);
            if (out.length > 0 && round >= dropBeforeRound) {
                b.input(out);
            }
            // B 的 ACK 需要回灌给 A（单向测试中手动完成）
            byte[] back = b.update(now);
            if (back.length > 0 && round >= dropBeforeRound) {
                a.input(back);
            }
            byte[] m;
            while ((m = b.recv()) != null) {
                byte[] merged = new byte[got.length + m.length];
                System.arraycopy(got, 0, merged, 0, got.length);
                System.arraycopy(m, 0, merged, got.length, m.length);
                got = merged;
            }
            if (got.length >= expectedLen) {
                break;
            }
        }
        return got;
    }

    @Test
    void basicSendRecv() {
        KcpControl a = new KcpControl(1);
        KcpControl b = new KcpControl(1);
        byte[] msg = "hello kcp".getBytes();

        a.send(msg);
        byte[] out = a.update(0);
        assertTrue(out.length > 0, "应有数据待发送");

        b.input(out);
        assertArrayEquals(msg, b.recv());
    }

    @Test
    void largeMessageFragmentsAndReassembles() {
        KcpControl a = new KcpControl(2);
        KcpControl b = new KcpControl(2);

        // 构造超过单个 MSS (1400-24=1376) 的消息
        byte[] msg = new byte[5000];
        for (int i = 0; i < msg.length; i++) {
            msg[i] = (byte) (i % 251);
        }

        a.send(msg);
        byte[] got = pump(a, b, msg.length, 60, 0);
        assertArrayEquals(msg, got, "分片重组后应与原文逐字节相同");
    }

    @Test
    void packetLossIsRecoveredByRetransmit() {
        KcpControl a = new KcpControl(3);
        KcpControl b = new KcpControl(3);

        byte[] msg = new byte[3000];
        for (int i = 0; i < msg.length; i++) {
            msg[i] = (byte) (i % 251);
        }

        a.send(msg);
        // 前 3 轮的数据包全部丢弃，验证重传能补齐
        byte[] got = pump(a, b, msg.length, 120, 3);
        assertArrayEquals(msg, got, "丢包后应通过重传完整恢复");
    }

    @Test
    void outOfOrderDeliveryIsBuffered() {
        KcpControl a = new KcpControl(4);
        KcpControl b = new KcpControl(4);

        byte[] msg = new byte[4000];
        for (int i = 0; i < msg.length; i++) {
            msg[i] = (byte) (i % 197);
        }
        a.send(msg);

        // 收集若干轮的输出，然后逆序投递，模拟严重乱序
        List<byte[]> packets = new ArrayList<>();
        for (int r = 0; r < 8; r++) {
            byte[] out = a.update((long) r * KcpControl.IKCP_INTERVAL);
            if (out.length > 0) {
                packets.add(out);
            }
        }
        assertFalse(packets.isEmpty(), "应有数据产生");

        for (int i = packets.size() - 1; i >= 0; i--) {
            try {
                b.input(packets.get(i));
            } catch (KcpException ignored) {
                // 乱序时 conv/长度校验可能失败，忽略继续
            }
        }
        // 乱序段会暂存在 rcvBuf，等待缺失段补齐后才交付
        // 这里只断言不抛异常且状态可查询
        assertNotNull(b.toString());
    }

    @Test
    void rejectsWrongConv() {
        KcpControl a = new KcpControl(10);
        KcpControl b = new KcpControl(11); // conv 不一致
        a.send("x".getBytes());
        byte[] out = a.update(0);
        assertThrows(KcpException.class, () -> b.input(out));
    }

    @Test
    void rejectsOversizedMessage() {
        KcpControl a = new KcpControl(12);
        int mss = KcpControl.IKCP_MTU_DEF - KcpSegment.IKCP_OVERHEAD;
        byte[] huge = new byte[mss * 256]; // 分片数超过 255
        assertThrows(KcpException.class, () -> a.send(huge));
    }

    @Test
    void segmentEncodeIsLittleEndianWith24ByteHeader() {
        KcpSegment s = KcpSegment.data((byte) 0, "ab".getBytes());
        s.conv = 0x11223344;
        s.wnd = 32;
        s.ts = 1000;
        s.sn = 7;
        s.una = 5;
        byte[] b = s.encode();

        assertEquals(KcpSegment.IKCP_OVERHEAD + 2, b.length, "段长度应为头部+负载");
        assertArrayEquals(new byte[]{0x44, 0x33, 0x22, 0x11},
                new byte[]{b[0], b[1], b[2], b[3]}, "conv 应为小端序");
        assertEquals(KcpSegment.IKCP_CMD_PUSH, b[4]);
        assertEquals(0, b[5], "frg=0 表示最后一个分片");
        assertEquals(32, KcpSegment.readUint16(b, 6));
        assertEquals(1000L, KcpSegment.readUint32(b, 8));
        assertEquals(7L, KcpSegment.readUint32(b, 12));
        assertEquals(5L, KcpSegment.readUint32(b, 16));
        assertEquals(2L, KcpSegment.readUint32(b, 20), "len 字段应为 2");
        assertArrayEquals("ab".getBytes(), new byte[]{b[24], b[25]});
    }

    @Test
    void segmentDecodeRoundTrip() {
        KcpSegment s = KcpSegment.data((byte) 3, "payload".getBytes());
        s.conv = 0xAABBCCDD;
        s.wnd = 64;
        s.ts = 123456;
        s.sn = 99;
        s.una = 98;
        KcpSegment back = KcpSegment.decode(s.encode(), 0);

        assertEquals(s.conv, back.conv);
        assertEquals(s.cmd, back.cmd);
        assertEquals(s.frg, back.frg);
        assertEquals(s.wnd, back.wnd);
        assertEquals(s.ts, back.ts);
        assertEquals(s.sn, back.sn);
        assertEquals(s.una, back.una);
        assertArrayEquals(s.data, back.data);
    }

    @Test
    void itimediffHandlesWraparound() {
        // 跨越 2^32 回绕仍应得到正确符号
        assertTrue(KcpControl.itimediff(5, 3) > 0);
        assertTrue(KcpControl.itimediff(3, 5) < 0);
        assertTrue(KcpControl.itimediff(2, 0xFFFFFFFFL) > 0,
                "回绕后 2 应晚于 0xFFFFFFFF");
    }

    @Test
    void recvReturnsNullWhenNoCompleteMessage() {
        KcpControl b = new KcpControl(20);
        assertNull(b.recv(), "无数据时应返回 null 而非抛异常");
    }
}
