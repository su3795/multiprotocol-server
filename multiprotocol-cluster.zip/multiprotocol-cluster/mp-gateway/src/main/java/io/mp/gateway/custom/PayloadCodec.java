package io.mp.gateway.custom;

/**
 * CUSTOM 协议的 payload 变换接口。
 *
 * <p>用于在帧编解码之外叠加一层私有变换（混淆 / 压缩 / 加密），
 * 使 CUSTOM 协议真正区别于裸 UDP，同时保持上层业务处理不变。
 *
 * <p><b>互通性约束</b>：默认实现 {@link #noop()} 为恒等变换，
 * 保证 Java / Go / Rust 三版 CUSTOM 端口直接互通。
 * 一旦启用自定义变换，<b>三版必须使用相同算法</b>才能互通。
 */
public interface PayloadCodec {

    /**
     * 发送前变换。
     *
     * @param plain 帧编码后的原始字节
     * @return 变换后的字节
     */
    byte[] encode(byte[] plain);

    /**
     * 接收后还原。
     *
     * @param wire 线上收到的字节
     * @return 还原为帧编码后的原始字节
     */
    byte[] decode(byte[] wire);

    /** @return 恒等变换：不做任何处理，保证跨语言互通 */
    static PayloadCodec noop() {
        return NoOp.INSTANCE;
    }

    /**
     * 创建一个滚动密钥 XOR 混淆器（示例实现）。
     *
     * <p>算法：{@code out[i] = in[i] ^ key[i % key.length] ^ (i & 0xFF)}
     * 位置参与运算可避免相同明文字节产生相同密文。
     *
     * <p><b>这不是加密</b>，仅用于演示扩展点；生产环境请替换为
     * AES-GCM 等真正的 AEAD 算法。
     *
     * @param key 密钥，长度建议不少于 16 字节
     * @return XOR 混淆器
     */
    static PayloadCodec xor(byte[] key) {
        return new XorCodec(key);
    }

    /** 恒等变换实现 */
    final class NoOp implements PayloadCodec {
        static final NoOp INSTANCE = new NoOp();

        private NoOp() {
        }

        @Override
        public byte[] encode(byte[] plain) {
            return plain;
        }

        @Override
        public byte[] decode(byte[] wire) {
            return wire;
        }
    }

    /** 滚动密钥 XOR 混淆实现 */
    final class XorCodec implements PayloadCodec {
        private final byte[] key;

        XorCodec(byte[] key) {
            if (key == null || key.length == 0) {
                throw new IllegalArgumentException("密钥不能为空");
            }
            this.key = key.clone();
        }

        @Override
        public byte[] encode(byte[] plain) {
            return transform(plain);
        }

        @Override
        public byte[] decode(byte[] wire) {
            // XOR 是对合运算，编码与解码相同
            return transform(wire);
        }

        private byte[] transform(byte[] in) {
            byte[] out = new byte[in.length];
            for (int i = 0; i < in.length; i++) {
                out[i] = (byte) (in[i] ^ key[i % key.length] ^ (i & 0xFF));
            }
            return out;
        }
    }
}
