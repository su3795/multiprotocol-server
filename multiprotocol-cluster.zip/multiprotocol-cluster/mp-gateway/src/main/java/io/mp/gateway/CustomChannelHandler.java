package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.mp.common.codec.Protocol;
import io.mp.gateway.custom.PayloadCodec;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.socket.DatagramPacket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 自定义协议 Handler（UDP 变体）。
 *
 * <p>CUSTOM 承载在 UDP 之上，帧格式与 TCP/UDP <b>完全一致</b>，
 * 因此默认可与 Go / Rust 版互通。它的价值在于提供了一个
 * <b>payload 变换扩展点</b>：可在此叠加私有混淆、压缩或加密，
 * 而不影响上层业务处理与跨语言互通性。
 *
 * <h3>为什么默认不做变换</h3>
 * <p>{@link PayloadCodec} 默认实现为 {@link PayloadCodec#noop()}（恒等变换），
 * 这样 Java / Go / Rust 三版的 CUSTOM 端口可以直接互通。
 * 需要私有变换时，注入自定义 {@code PayloadCodec} 即可 ——
 * 但注意此时<b>三版必须使用相同的变换算法</b>才能互通。
 */
public class CustomChannelHandler extends SimpleChannelInboundHandler<DatagramPacket> {

    private static final Logger log = LoggerFactory.getLogger(CustomChannelHandler.class);

    private final RequestProcessor processor;
    private final PayloadCodec codec;

    /**
     * 使用恒等变换（与 UDP 等价，保证跨语言互通）。
     *
     * @param processor 业务处理器
     */
    public CustomChannelHandler(RequestProcessor processor) {
        this(processor, PayloadCodec.noop());
    }

    /**
     * @param processor 业务处理器
     * @param codec     payload 变换器，null 时按恒等处理
     */
    public CustomChannelHandler(RequestProcessor processor, PayloadCodec codec) {
        this.processor = processor;
        this.codec = codec == null ? PayloadCodec.noop() : codec;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, DatagramPacket packet) {
        ByteBuf content = packet.content();
        byte[] raw = new byte[content.readableBytes()];
        content.getBytes(content.readerIndex(), raw);

        byte[] data;
        try {
            data = codec.decode(raw);
        } catch (RuntimeException e) {
            log.warn("CUSTOM payload 变换失败（可能是密钥不匹配或版本不一致）: {}", e.getMessage());
            return;
        }

        Frame req;
        try {
            req = FrameCodec.decode(data);
        } catch (IllegalArgumentException e) {
            log.warn("CUSTOM 帧解析失败: {}", e.getMessage());
            return;
        }

        Frame resp = processor.process(req, Protocol.CUSTOM);
        byte[] out;
        try {
            out = codec.encode(FrameCodec.encode(resp));
        } catch (RuntimeException e) {
            log.warn("CUSTOM payload 回包变换失败: {}", e.getMessage());
            return;
        }

        ByteBuf buf = ctx.alloc().buffer(out.length);
        buf.writeBytes(out);
        ctx.writeAndFlush(new DatagramPacket(buf, packet.sender()));
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.warn("CUSTOM 异常: {}", cause.getMessage());
    }
}
