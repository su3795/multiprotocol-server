package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.Protocol;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.mp.observability.Metrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** TCP 业务 Handler：收 Frame → 处理 → 回 Frame */
@ChannelHandler.Sharable
public class TcpChannelHandler extends ChannelInboundHandlerAdapter {

    private static final Logger log = LoggerFactory.getLogger(TcpChannelHandler.class);

    private final RequestProcessor processor;

    public TcpChannelHandler(RequestProcessor processor) {
        this.processor = processor;
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        Metrics.get().incConnection();
        log.debug("TCP 连接建立: {}", ctx.channel().remoteAddress());
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        Metrics.get().decConnection();
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        if (!(msg instanceof Frame)) {
            ctx.fireChannelRead(msg);
            return;
        }
        Frame req = (Frame) msg;
        Frame resp = processor.process(req, Protocol.TCP);
        if (req.needResponse() || resp != null) {
            ctx.writeAndFlush(resp);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.warn("TCP 连接异常: {}", cause.getMessage());
        ctx.close();
    }
}
