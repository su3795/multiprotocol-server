package io.mp.gateway;

/** 命令字定义。网关与客户端共用。 */
public final class Cmd {

    /** 写 KV（走共识层，仅 Leader 可写） */
    public static final int PUT = 1;
    /** 线性一致读 KV */
    public static final int GET = 2;
    /** 设置分片路由（走共识层） */
    public static final int ROUTE_SET = 3;
    /** 读分片路由 */
    public static final int ROUTE_GET = 4;
    /** 心跳，不走共识，本地立即响应 */
    public static final int PING = 5;
    /** 查询节点状态（角色 / 连接数 / KV 数量） */
    public static final int STATS = 6;

    public static final int OK = 0;
    public static final int ERR_NOT_LEADER = 1;
    public static final int ERR_BAD_REQUEST = 2;
    public static final int ERR_INTERNAL = 3;

    private Cmd() {
    }

    public static String name(int cmd) {
        switch (cmd) {
            case PUT: return "PUT";
            case GET: return "GET";
            case ROUTE_SET: return "ROUTE_SET";
            case ROUTE_GET: return "ROUTE_GET";
            case PING: return "PING";
            case STATS: return "STATS";
            default: return "UNKNOWN(" + cmd + ")";
        }
    }
}
