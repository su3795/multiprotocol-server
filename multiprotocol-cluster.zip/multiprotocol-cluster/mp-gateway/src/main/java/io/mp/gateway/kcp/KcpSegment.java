package io.mp.gateway.kcp;

/**
 * KCP 段（Segment）。
 *
 * <p>KCP 是一个纯算法的 ARQ（自动重传请求）协议，工作在 UDP 之上，
 * 以「牺牲 10%~20% 带宽换取 30%~40% 延迟降低」著称。
 *
 * <p><b>线格式</b>（小端序，固定 24 字节头部）：
 * <pre>
 *   0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |     conv      |cmd|frg|    wnd     |    ts     |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |      sn       |     una      |      len        |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |                   data ...                     |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * </pre>
 *
 * <ul>
 *   <li>{@code conv} 会话标识，双方必须一致</li>
 *   <li>{@code cmd}  81=PUSH 82=ACK 83=WASK 84=WINS</li>
 *   <li>{@code frg}  分片序号，从 count-1 递减到 0；<b>0 表示最后一个分片</b></li>
 *   <li>{@code wnd}  本端剩余接收窗口</li>
 *   <li>{@code ts}   发送时间戳，用于计算 RTT</li>
 *   <li>{@code sn}   段序号</li>
 *   <li>{@code una}  本端已收到的最小连续序号（即期望接收的下一个）</li>
 * </ul>
 *
 * <p>本实现与 Go 版 {@code internal/gateway/kcp.go}、
 * Rust 版 {@code crates/mp-gateway/src/kcp.rs} 线格式完全一致，三版可互通。
 */
public final class KcpSegment {

    /** 推送数据 */
    public static final byte IKCP_CMD_PUSH = 81;
    /** 确认 */
    public static final byte IKCP_CMD_ACK = 82;
    /** 窗口探测询问 */
    public static final byte IKCP_CMD_WASK = 83;
    /** 窗口大小告知 */
    public static final byte IKCP_CMD_WINS = 84;
    /** 单段头部长度 */
    public static final int IKCP_OVERHEAD = 24;

    /** conv 4 + cmd 1 + frg 1 + wnd 2 + ts 4 + sn 4 + una 4 + len 4 */
    public int conv;
    /** 命令字 */
    public byte cmd;
    /** 分片序号，0 表示最后一个分片 */
    public byte frg;
    /** 剩余接收窗口 */
    public int wnd;
    /** 发送时间戳 */
    public long ts;
    /** 段序号 */
    public long sn;
    /** 期望接收的下一个序号 */
    public long una;
    /** 负载 */
    public byte[] data;

    // ---------- 发送侧内部状态 ----------

    /** 该段的重传超时时间 */
    long rto;
    /** 已发送次数 */
    long xmit;
    /** 下次重传时间戳 */
    long resendts;
    /** 收到的后续 ACK 计数，达阈值触发快速重传 */
    long fastack;

    /** 构造空段 */
    public KcpSegment() {
        this.data = new byte[0];
    }

    /**
     * 构造数据段。
     *
     * @param frg  分片序号（0 表示最后一个分片）
     * @param data 负载，内部会拷贝一份
     */
    public static KcpSegment data(byte frg, byte[] data) {
        KcpSegment s = new KcpSegment();
        s.cmd = IKCP_CMD_PUSH;
        s.frg = frg;
        s.data = data == null ? new byte[0] : data.clone();
        return s;
    }

    /** 构造 ACK 段 */
    public static KcpSegment ack(long sn, long ts) {
        KcpSegment s = new KcpSegment();
        s.cmd = IKCP_CMD_ACK;
        s.sn = sn;
        s.ts = ts;
        s.data = new byte[0];
        return s;
    }

    /** 构造窗口探测段 */
    public static KcpSegment wask() {
        KcpSegment s = new KcpSegment();
        s.cmd = IKCP_CMD_WASK;
        s.data = new byte[0];
        return s;
    }

    /**
     * 编码为字节（小端序）。
     *
     * <p>所有整数字段一律用 long 承载并按 32 位无符号语义处理，
     * 写入时截断低 32 位，保证与 Go/Rust 版逐字节一致。
     */
    public byte[] encode() {
        byte[] buf = new byte[IKCP_OVERHEAD + data.length];
        writeUint32(buf, 0, conv);
        buf[4] = cmd;
        buf[5] = frg;
        writeUint16(buf, 6, wnd);
        writeUint32(buf, 8, ts);
        writeUint32(buf, 12, sn);
        writeUint32(buf, 16, una);
        writeUint32(buf, 20, data.length);
        System.arraycopy(data, 0, buf, IKCP_OVERHEAD, data.length);
        return buf;
    }

    /**
     * 从字节解码一个段。
     *
     * @param buf  缓冲区
     * @param off  起始偏移
     * @return 解码出的段
     * @throws KcpException 长度不足时抛出
     */
    public static KcpSegment decode(byte[] buf, int off) {
        if (buf.length - off < IKCP_OVERHEAD) {
            throw new KcpException("KCP 段长度不足: " + (buf.length - off));
        }
        KcpSegment s = new KcpSegment();
        s.conv = (int) readUint32(buf, off + 0);
        s.cmd = buf[off + 4];
        s.frg = buf[off + 5];
        s.wnd = readUint16(buf, off + 6);
        s.ts = readUint32(buf, off + 8);
        s.sn = readUint32(buf, off + 12);
        s.una = readUint32(buf, off + 16);
        int len = (int) readUint32(buf, off + 20);
        if (len < 0 || buf.length - off - IKCP_OVERHEAD < len) {
            throw new KcpException("KCP 段负载长度非法: " + len);
        }
        s.data = new byte[len];
        System.arraycopy(buf, off + IKCP_OVERHEAD, s.data, 0, len);
        return s;
    }

    // ---------- 小端序读写工具 ----------

    static void writeUint16(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
    }

    static void writeUint32(byte[] b, int off, long v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
        b[off + 2] = (byte) ((v >>> 16) & 0xFF);
        b[off + 3] = (byte) ((v >>> 24) & 0xFF);
    }

    static int readUint16(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
    }

    static long readUint32(byte[] b, int off) {
        return (b[off] & 0xFFL)
                | ((b[off + 1] & 0xFFL) << 8)
                | ((b[off + 2] & 0xFFL) << 16)
                | ((b[off + 3] & 0xFFL) << 24);
    }

    @Override
    public String toString() {
        return "KcpSegment{cmd=" + cmd + ", frg=" + frg + ", sn=" + sn
                + ", una=" + una + ", len=" + data.length + '}';
    }
}
