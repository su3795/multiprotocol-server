package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

import java.util.List;

/**
 * 自定义帧解码器：处理 TCP 字节流的粘包 / 半包问题。
 *
 * <p>UDP 是数据报，天然分帧，不需要本处理器（直接按整包解码即可）。
 * 新增协议时只需替换这一层，业务 Handler 完全无感。
 */
public class FrameDecoder extends ByteToMessageDecoder {

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
        // 至少需要头部才能知道整帧长度
        if (in.readableBytes() < Frame.HEADER_SIZE) {
            return;
        }
        in.markReaderIndex();

        short magic = in.readShort();
        if (magic != Frame.MAGIC) {
            // 非法流，断开连接避免持续错位
            in.resetReaderIndex();
            ctx.close();
            throw new IllegalStateException(
                    String.format("magic 不匹配: 期望 0x%04X 实际 0x%04X", Frame.MAGIC, magic));
        }
        in.readByte();  // version
        in.readByte();  // flags
        in.readInt();   // cmd
        in.readLong();  // seq
        int payloadLen = in.readInt();
        in.resetReaderIndex();

        if (payloadLen < 0) {
            ctx.close();
            throw new IllegalStateException("payload 长度为负: " + payloadLen);
        }

        int total = Frame.HEADER_SIZE + payloadLen + Frame.CRC_SIZE;
        if (in.readableBytes() < total) {
            // 半包：等待更多数据，ByteToMessageDecoder 会自动累积
            return;
        }

        byte[] data = new byte[total];
        in.readBytes(data);
        out.add(FrameCodec.decode(data));
    }
}
