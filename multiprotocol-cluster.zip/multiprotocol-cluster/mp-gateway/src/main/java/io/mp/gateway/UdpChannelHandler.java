package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.mp.common.codec.Protocol;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.socket.DatagramPacket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * UDP Handler：数据报天然分帧，无需累积解码。
 *
 * <p>需要注意：UDP 无连接，回包必须携带发送方地址（DatagramPacket.sender()）。
 */
public class UdpChannelHandler extends ChannelInboundHandlerAdapter {

    private static final Logger log = LoggerFactory.getLogger(UdpChannelHandler.class);

    private final RequestProcessor processor;

    public UdpChannelHandler(RequestProcessor processor) {
        this.processor = processor;
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        if (!(msg instanceof DatagramPacket)) {
            ctx.fireChannelRead(msg);
            return;
        }
        DatagramPacket packet = (DatagramPacket) msg;
        ByteBuf content = packet.content();
        byte[] data = new byte[content.readableBytes()];
        content.getBytes(content.readerIndex(), data);

        Frame req;
        try {
            req = FrameCodec.decode(data);
        } catch (IllegalArgumentException e) {
            log.warn("UDP 帧解析失败: {}", e.getMessage());
            return;
        }

        Frame resp = processor.process(req, Protocol.UDP);
        byte[] out = FrameCodec.encode(resp);
        ByteBuf buf = ctx.alloc().buffer(out.length);
        buf.writeBytes(out);
        ctx.writeAndFlush(new DatagramPacket(buf, packet.sender()));
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.warn("UDP 异常: {}", cause.getMessage());
    }
}
