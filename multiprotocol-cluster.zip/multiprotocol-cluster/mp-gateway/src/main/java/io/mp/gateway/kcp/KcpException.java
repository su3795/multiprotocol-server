package io.mp.gateway.kcp;

/**
 * KCP 异常。
 */
public class KcpException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public KcpException(String message) {
        super(message);
    }

    public KcpException(String message, Throwable cause) {
        super(message, cause);
    }
}
