package io.mp.gateway.kcp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * KCP 控制块：纯算法 ARQ，不依赖任何系统调用，只做
 * 分片 / 编号 / 确认 / 重传 / 重组。
 *
 * <h3>与 TCP 的关键差异（决定适用场景）</h3>
 * <table>
 *   <caption>KCP 与 TCP 机制对比</caption>
 *   <tr><th>机制</th><th>TCP</th><th>KCP</th></tr>
 *   <tr><td>RTO 增长</td><td>×2</td><td>×1.5（重传更激进）</td></tr>
 *   <tr><td>丢包重传</td><td>重传该段之后全部</td><td>选择性重传，只补丢失段</td></tr>
 *   <tr><td>快速重传</td><td>依赖 dup ACK</td><td>累计阈值即触发，不等超时</td></tr>
 *   <tr><td>拥塞控制</td><td>强制退让</td><td>可关闭（实时优先）</td></tr>
 * </table>
 *
 * <p><b>适用</b>：实时对战、音视频信令、弱网 RPC。
 * <b>不适用</b>：大文件传输、带宽敏感的公网批量传输。
 *
 * <p><b>并发约定</b>：本类<b>非线程安全</b>，由调用方保证串行访问。
 * 接入层为每个会话分配单线程驱动，因此无需加锁。
 *
 * <p>时间戳字段（ts / sn / una 等）一律用 {@code long} 承载 32 位无符号值，
 * 与 Go / Rust 版语义一致，避免 Java 无无符号类型带来的符号陷阱。
 */
public final class KcpControl {

    // ---------- 协议常量（与 Go/Rust 版必须一致） ----------

    /** 默认 MTU */
    public static final int IKCP_MTU_DEF = 1400;
    /** 默认发送窗口（段数） */
    public static final int IKCP_WND_SND = 32;
    /** 默认接收窗口（段数） */
    public static final int IKCP_WND_RCV = 128;
    /** 最小 RTO (ms) */
    public static final int IKCP_RTO_MIN = 30;
    /** 默认 RTO (ms) */
    public static final int IKCP_RTO_DEF = 200;
    /** 默认 update 间隔 (ms) */
    public static final int IKCP_INTERVAL = 100;
    /** 判定链路断开的重传次数 */
    public static final int IKCP_DEAD_LINK = 20;
    /** 快速重传触发阈值 */
    public static final int IKCP_FAST_ACK_LIMIT = 3;
    /** 单条消息最大分片数 */
    public static final int IKCP_MAX_FRG = 255;

    private static final long UINT32_MASK = 0xFFFFFFFFL;

    private final int conv;
    private final int mtu;
    private final int mss;

    // ---------- 序号状态 ----------
    private long sndUna;
    private long sndNxt;
    private long rcvNxt;

    // ---------- RTT / RTO ----------
    private long rto;
    private final long minRto;
    private long srtt;
    private long rttval;

    // ---------- 窗口 ----------
    private final long sndWnd;
    private final long rcvWnd;
    private long rmtWnd;
    private long cwnd;

    // ---------- 时钟 ----------
    private long current;
    private final long interval;
    private long tsFlush;

    // ---------- 队列 ----------
    private final List<KcpSegment> sndBuf = new ArrayList<>();
    private final List<KcpSegment> rcvBuf = new ArrayList<>();
    private final List<KcpSegment> sndQueue = new ArrayList<>();
    private final List<KcpSegment> rcvQueue = new ArrayList<>();
    private final List<long[]> ackList = new ArrayList<>();

    // ---------- 探测与状态 ----------
    private long probeNeedSend;
    private long probeWait;
    private final long deadLink;
    private long state;
    private final long fastResend;
    private final long noDelay;

    /**
     * 创建 KCP 控制块（默认开启 nodelay：低延迟优先）。
     *
     * @param conv 会话标识，通信双方必须一致
     */
    public KcpControl(int conv) {
        this(conv, IKCP_MTU_DEF);
    }

    /**
     * 创建 KCP 控制块。
     *
     * @param conv 会话标识
     * @param mtu  最大传输单元
     */
    public KcpControl(int conv, int mtu) {
        this.conv = conv;
        this.mtu = mtu;
        this.mss = mtu - KcpSegment.IKCP_OVERHEAD;
        this.sndUna = 0;
        this.sndNxt = 0;
        this.rcvNxt = 0;
        this.rto = IKCP_RTO_DEF;
        this.minRto = IKCP_RTO_MIN;
        this.srtt = 0;
        this.rttval = 0;
        this.sndWnd = IKCP_WND_SND;
        this.rcvWnd = IKCP_WND_RCV;
        this.rmtWnd = IKCP_WND_RCV;
        this.cwnd = 0;
        this.current = 0;
        this.interval = IKCP_INTERVAL;
        this.tsFlush = 0;
        this.deadLink = IKCP_DEAD_LINK;
        this.state = 0;
        this.fastResend = IKCP_FAST_ACK_LIMIT;
        this.noDelay = 1;
    }

    /** 是否已关闭（链路断开） */
    public boolean isClosed() {
        return state != 0;
    }

    // ================= 接收侧 =================

    /**
     * 处理收到的一个 UDP 数据报（可能包含多个 KCP 段）。
     *
     * @param data 原始数据
     * @throws KcpException conv 不匹配 / 长度非法 / 未知命令
     */
    public void input(byte[] data) {
        if (state != 0) {
            throw new KcpException("KCP 连接已关闭");
        }
        long oldUna = sndUna;
        int offset = 0;

        while (data.length - offset >= KcpSegment.IKCP_OVERHEAD) {
            KcpSegment seg = KcpSegment.decode(data, offset);
            offset += KcpSegment.IKCP_OVERHEAD + seg.data.length;

            if (seg.conv != conv) {
                throw new KcpException("KCP conv 不匹配: 期望 " + conv + " 实际 " + seg.conv);
            }

            rmtWnd = seg.wnd;
            parseUna(seg.una);

            if (seg.cmd == KcpSegment.IKCP_CMD_ACK) {
                // 收到 ACK：移除对应段，更新 RTT
                if (itimediff(seg.sn, sndUna) < 0 || itimediff(seg.sn, sndNxt) >= 0) {
                    continue;
                }
                for (int i = 0; i < sndBuf.size(); i++) {
                    if (sndBuf.get(i).sn == seg.sn) {
                        sndBuf.remove(i);
                        break;
                    }
                }
                long rtt = itimediff(current, seg.ts);
                updateRtt(rtt < 0 ? 0 : rtt);
                shrinkBuf();

            } else if (seg.cmd == KcpSegment.IKCP_CMD_PUSH) {
                // 收到数据：先记录待 ACK，再尝试入接收窗口
                if (itimediff(seg.sn, (rcvNxt + rcvWnd) & UINT32_MASK) < 0) {
                    ackList.add(new long[]{seg.sn, seg.ts});
                }
                if (itimediff(seg.sn, rcvNxt) >= 0) {
                    boolean dup = false;
                    for (KcpSegment s : rcvBuf) {
                        if (s.sn == seg.sn) {
                            dup = true;
                            break;
                        }
                    }
                    if (!dup) {
                        // 按 sn 升序插入，保持有序
                        int pos = rcvBuf.size();
                        for (int i = 0; i < rcvBuf.size(); i++) {
                            if (itimediff(seg.sn, rcvBuf.get(i).sn) < 0) {
                                pos = i;
                                break;
                            }
                        }
                        rcvBuf.add(pos, seg);
                    }
                }

            } else if (seg.cmd == KcpSegment.IKCP_CMD_WASK) {
                probeNeedSend = 1;

            } else if (seg.cmd == KcpSegment.IKCP_CMD_WINS) {
                rmtWnd = seg.wnd;

            } else {
                throw new KcpException("KCP 未知命令: " + seg.cmd);
            }

            moveRcvBuf();
        }

        // snd_una 前进说明有段被确认，可扩大拥塞窗口
        if (itimediff(sndUna, oldUna) > 0 && cwnd < rmtWnd) {
            cwnd++;
        }

        // 收到数据后尽快 flush，降低 ACK 延迟
        tsFlush = current;
    }

    /**
     * 取出一条完整消息。
     *
     * @return 完整消息；{@code null} 表示暂无完整消息（半包或乱序未补齐）
     */
    public byte[] recv() {
        if (state != 0 || rcvQueue.isEmpty()) {
            return null;
        }
        // 找到第一个 frg==0 的段，确定整条消息边界
        int count = 0;
        boolean found = false;
        for (KcpSegment s : rcvQueue) {
            count++;
            if (s.frg == 0) {
                found = true;
                break;
            }
        }
        if (!found) {
            return null; // 最后一个分片还没到
        }

        int total = 0;
        for (int i = 0; i < count; i++) {
            total += rcvQueue.get(i).data.length;
        }
        byte[] out = new byte[total];
        int pos = 0;
        for (int i = 0; i < count; i++) {
            byte[] d = rcvQueue.get(i).data;
            System.arraycopy(d, 0, out, pos, d.length);
            pos += d.length;
        }
        // 移除已消费的段
        for (int i = 0; i < count; i++) {
            rcvQueue.remove(0);
        }
        return out;
    }

    /** 根据对端 una 移除已确认的发送段 */
    private void parseUna(long una) {
        sndBuf.removeIf(seg -> itimediff(seg.sn, una) < 0);
        sndUna = una;
    }

    /** 将 rcvBuf 中 sn 连续的段移入 rcvQueue */
    private void moveRcvBuf() {
        while (!rcvBuf.isEmpty()) {
            KcpSegment seg = rcvBuf.get(0);
            if (seg.sn == rcvNxt && rcvQueue.size() < rcvWnd) {
                rcvBuf.remove(0);
                rcvQueue.add(seg);
                rcvNxt = (rcvNxt + 1) & UINT32_MASK;
            } else {
                break;
            }
        }
    }

    /** 根据 RTT 样本更新 RTO */
    private void updateRtt(long rtt) {
        if (srtt == 0) {
            srtt = rtt;
            rttval = rtt / 2;
        } else {
            long delta = rtt > srtt ? rtt - srtt : srtt - rtt;
            rttval = (3 * rttval + delta) / 4;
            srtt = (7 * srtt + rtt) / 8;
        }
        long rtoNew = srtt + Math.max(interval, 4 * rttval);
        if (rtoNew < minRto) {
            rtoNew = minRto;
        }
        rto = rtoNew;
    }

    /** 更新 sndUna 为 sndBuf 中最小的 sn */
    private void shrinkBuf() {
        sndUna = sndBuf.isEmpty() ? sndNxt : sndBuf.get(0).sn;
    }

    // ================= 发送侧 =================

    /**
     * 发送一条消息（自动分片）。
     *
     * @param data 待发送数据
     * @throws KcpException 分片数超过 255
     */
    public void send(byte[] data) {
        if (state != 0) {
            throw new KcpException("KCP 连接已关闭");
        }
        int count = data.length == 0 ? 1 : (data.length + mss - 1) / mss;
        if (count == 0) {
            count = 1;
        }
        if (count > IKCP_MAX_FRG) {
            throw new KcpException("KCP 消息过大，分片数 " + count + " 超过 " + IKCP_MAX_FRG);
        }

        int offset = 0;
        for (int i = 0; i < count; i++) {
            int size = Math.min(mss, data.length - offset);
            byte[] chunk = Arrays.copyOfRange(data, offset, offset + size);
            offset += size;
            // frg 从 count-1 递减到 0，最后一个分片 frg=0
            sndQueue.add(KcpSegment.data((byte) (count - 1 - i), chunk));
        }
    }

    /**
     * 把待发送数据打包。
     *
     * <p>由调用方负责实际发送（返回字节而非回调），避免回调在
     * Netty EventLoop 中造成重入问题。
     *
     * @return 待发送的字节，可能为空数组
     */
    public byte[] flush() {
        if (state != 0) {
            return new byte[0];
        }
        long cur = current;
        List<byte[]> chunks = new ArrayList<>();
        int total = 0;

        // 1. 发送 ACK
        for (long[] a : ackList) {
            KcpSegment s = KcpSegment.ack(a[0], a[1]);
            s.conv = conv;
            s.wnd = wndAvail();
            s.una = rcvNxt;
            byte[] b = s.encode();
            chunks.add(b);
            total += b.length;
        }
        ackList.clear();

        // 2. 窗口探测：远端窗口为 0 时主动询问
        if (rmtWnd == 0) {
            if (probeWait == 0) {
                probeWait = interval;
                probeNeedSend = 1;
            } else {
                probeWait--;
            }
        } else {
            probeWait = 0;
        }
        if (probeNeedSend == 1) {
            KcpSegment s = KcpSegment.wask();
            s.conv = conv;
            s.wnd = wndAvail();
            s.una = rcvNxt;
            byte[] b = s.encode();
            chunks.add(b);
            total += b.length;
            probeNeedSend = 0;
        }

        // 3. 计算可用窗口
        long cw = (sndUna + cwnd) & UINT32_MASK;
        if (cwnd == 0) {
            cw = (sndUna + 1) & UINT32_MASK; // 探测一个段
        }
        if (rmtWnd > 0 && itimediff((sndUna + rmtWnd) & UINT32_MASK, cw) < 0) {
            cw = (sndUna + rmtWnd) & UINT32_MASK;
        }

        // 4. 从 sndQueue 移入 sndBuf（受窗口限制）
        while (!sndQueue.isEmpty()) {
            if (itimediff(sndNxt, cw) >= 0) {
                break;
            }
            KcpSegment seg = sndQueue.remove(0);
            seg.conv = conv;
            seg.wnd = wndAvail();
            seg.ts = cur;
            seg.sn = sndNxt;
            sndNxt = (sndNxt + 1) & UINT32_MASK;
            seg.una = rcvNxt;
            seg.rto = rto;
            seg.resendts = (cur + rto) & UINT32_MASK;
            seg.fastack = 0;
            seg.xmit = 0;
            sndBuf.add(seg);
        }

        // 5. 发送 sndBuf 中需要发出的段（首次 / 超时重传 / 快速重传）
        for (KcpSegment seg : sndBuf) {
            boolean need = false;
            if (seg.xmit == 0) {
                need = true;
                seg.rto = rto;
                seg.resendts = (cur + rto) & UINT32_MASK;
            } else if (itimediff(cur, seg.resendts) >= 0) {
                // 超时重传：RTO ×1.5（TCP 是 ×2，KCP 更激进）
                need = true;
                seg.rto = seg.rto + seg.rto / 2;
                if (seg.rto > 60000) {
                    seg.rto = 60000;
                }
                seg.resendts = (cur + seg.rto) & UINT32_MASK;
            } else if (fastResend > 0 && seg.fastack >= fastResend) {
                // 快速重传：不等超时立即重发
                need = true;
                seg.fastack = 0;
                seg.resendts = (cur + seg.rto) & UINT32_MASK;
            }
            if (need) {
                seg.ts = cur;
                seg.wnd = wndAvail();
                seg.una = rcvNxt;
                seg.xmit++;
                if (deadLink > 0 && seg.xmit >= deadLink) {
                    state = 1; // 判定链路断开
                }
                byte[] b = seg.encode();
                chunks.add(b);
                total += b.length;
            }
        }

        // 6. 合并输出（多个段可打包进一个 UDP 数据报）
        byte[] out = new byte[total];
        int pos = 0;
        for (byte[] c : chunks) {
            System.arraycopy(c, 0, out, pos, c.length);
            pos += c.length;
        }
        return out;
    }

    /**
     * 驱动 KCP 时钟。
     *
     * <p><b>必须周期性调用</b>（建议 10ms），否则不会产生重传与 ACK。
     *
     * @param currentMs 当前时间戳（毫秒）
     * @return 待发送的字节，可能为空数组
     */
    public byte[] update(long currentMs) {
        current = currentMs & UINT32_MASK;
        if (tsFlush == 0) {
            tsFlush = current;
        }
        if (itimediff(current, tsFlush) >= 0) {
            tsFlush = (current + interval) & UINT32_MASK;
            return flush();
        }
        return new byte[0];
    }

    /** 计算通告给对端的剩余接收窗口 */
    private int wndAvail() {
        long avail = rcvWnd - rcvQueue.size();
        if (avail < 0) {
            avail = 0;
        }
        if (avail > 65535) {
            avail = 65535;
        }
        return (int) avail;
    }

    /**
     * 计算两个 32 位时间戳的有序差值（正确处理回绕）。
     *
     * @return 正数表示 later 晚于 earlier
     */
    static int itimediff(long later, long earlier) {
        return (int) ((later - earlier) & UINT32_MASK);
    }

    // ================= 测试与诊断用访问器 =================

    /** 当前时间戳 */
    public long current() {
        return current;
    }

    /** 最小未确认序号 */
    public long sndUna() {
        return sndUna;
    }

    /** 下一个待接收序号 */
    public long rcvNxt() {
        return rcvNxt;
    }

    /** 当前 RTO */
    public long rto() {
        return rto;
    }

    /** 等待发送的数据段数（诊断用） */
    public int pendingSegments() {
        return sndBuf.size() + sndQueue.size();
    }

    @Override
    public String toString() {
        return "KcpControl{conv=" + conv + ", sndUna=" + sndUna + ", sndNxt=" + sndNxt
                + ", rcvNxt=" + rcvNxt + ", rto=" + rto + ", state=" + state + '}';
    }
}
