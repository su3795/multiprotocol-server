package io.mp.gateway;

import io.netty.bootstrap.Bootstrap;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.ServerSocketChannel;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.mp.consensus.Consensus;
import io.mp.gateway.kcp.KcpChannelHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 多协议接入网关。
 *
 * <p>内置四条通道：TCP、UDP、CUSTOM、KCP。
 * QUIC 需额外原生依赖，位于独立源目录 {@code src/main/quic}，
 * 通过 {@code mvn -Pquic} 激活后由 QuicServer 单独启动。
 *
 * <p>线程模型：Boss 接受连接，Worker 处理 IO；业务处理同步完成，
 * 不阻塞 EventLoop（共识写走异步 propose 线程池）。
 */
public final class GatewayServer {

    private static final Logger log = LoggerFactory.getLogger(GatewayServer.class);

    private final Consensus consensus;
    private final int tcpPort;
    private final int udpPort;
    private final int customPort;
    private final int kcpPort;

    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;
    private Channel tcpChannel;
    private Channel udpChannel;
    private Channel customChannel;
    private Channel kcpChannel;

    /**
     * @param consensus  共识层
     * @param tcpPort    TCP 端口
     * @param udpPort    UDP 端口，&lt;=0 表示不启用
     * @param customPort CUSTOM 端口，&lt;=0 表示不启用
     * @param kcpPort    KCP 端口，&lt;=0 表示不启用
     */
    public GatewayServer(Consensus consensus, int tcpPort, int udpPort,
                         int customPort, int kcpPort) {
        this.consensus = consensus;
        this.tcpPort = tcpPort;
        this.udpPort = udpPort;
        this.customPort = customPort;
        this.kcpPort = kcpPort;
    }

    /** 兼容旧签名：仅启用 TCP + UDP */
    public GatewayServer(Consensus consensus, int tcpPort, int udpPort) {
        this(consensus, tcpPort, udpPort, 0, 0);
    }

    public void start() throws Exception {
        RequestProcessor processor = new RequestProcessor(consensus);
        TcpChannelHandler tcpHandler = new TcpChannelHandler(processor);

        boolean useEpoll = detectEpoll();
        log.info("使用传输实现: {}", useEpoll ? "native epoll" : "NIO");

        if (useEpoll) {
            bossGroup = newGroup(true, 1);
            workerGroup = newGroup(true, 0);
        } else {
            bossGroup = new NioEventLoopGroup(1);
            workerGroup = new NioEventLoopGroup(0);
        }

        // ---------- TCP ----------
        ServerBootstrap b = new ServerBootstrap();
        b.group(bossGroup, workerGroup)
         .channel(serverChannelClass(useEpoll))
         .option(ChannelOption.SO_BACKLOG, 1024)
         .childOption(ChannelOption.TCP_NODELAY, true)
         .childOption(ChannelOption.SO_KEEPALIVE, true)
         .childHandler(new ChannelInitializer<SocketChannel>() {
             @Override
             protected void initChannel(SocketChannel ch) {
                 ch.pipeline().addLast(new FrameDecoder());
                 ch.pipeline().addLast(new FrameEncoder());
                 ch.pipeline().addLast(tcpHandler);
             }
         });
        tcpChannel = b.bind(tcpPort).sync().channel();
        log.info("TCP 接入已启动: 0.0.0.0:{}", tcpPort);

        // ---------- UDP ----------
        if (udpPort > 0) {
            Bootstrap ub = new Bootstrap();
            ub.group(workerGroup)
              .channel(datagramChannelClass(useEpoll))
              .option(ChannelOption.SO_RCVBUF, 4 * 1024 * 1024)
              .option(ChannelOption.SO_SNDBUF, 4 * 1024 * 1024)
              .handler(new UdpChannelHandler(processor));
            udpChannel = ub.bind(udpPort).sync().channel();
            log.info("UDP 接入已启动: 0.0.0.0:{}", udpPort);
        }

        // ---------- CUSTOM（UDP 变体，可叠加 payload 变换） ----------
        if (customPort > 0) {
            Bootstrap cb = new Bootstrap();
            cb.group(workerGroup)
              .channel(datagramChannelClass(useEpoll))
              .option(ChannelOption.SO_RCVBUF, 4 * 1024 * 1024)
              .option(ChannelOption.SO_SNDBUF, 4 * 1024 * 1024)
              .handler(new CustomChannelHandler(processor));
            customChannel = cb.bind(customPort).sync().channel();
            log.info("CUSTOM 接入已启动: 0.0.0.0:{}", customPort);
        }

        // ---------- KCP（可靠 UDP，ARQ 重传） ----------
        if (kcpPort > 0) {
            Bootstrap kb = new Bootstrap();
            kb.group(workerGroup)
              .channel(datagramChannelClass(useEpoll))
              .option(ChannelOption.SO_RCVBUF, 4 * 1024 * 1024)
              .option(ChannelOption.SO_SNDBUF, 4 * 1024 * 1024)
              .handler(new KcpChannelHandler(processor));
            kcpChannel = kb.bind(kcpPort).sync().channel();
            log.info("KCP 接入已启动: 0.0.0.0:{}", kcpPort);
        }
    }

    public void stop() {
        if (tcpChannel != null) {
            tcpChannel.close();
        }
        if (udpChannel != null) {
            udpChannel.close();
        }
        if (customChannel != null) {
            customChannel.close();
        }
        if (kcpChannel != null) {
            kcpChannel.close();
        }
        if (bossGroup != null) {
            bossGroup.shutdownGracefully();
        }
        if (workerGroup != null) {
            workerGroup.shutdownGracefully();
        }
    }

    // ---------- 传输实现探测（失败自动降级为 NIO） ----------

    private static boolean detectEpoll() {
        try {
            Class<?> epoll = Class.forName("io.netty.channel.epoll.Epoll");
            return (Boolean) epoll.getMethod("isAvailable").invoke(null);
        } catch (Throwable t) {
            return false;
        }
    }

    private static EventLoopGroup newGroup(boolean epoll, int threads) throws Exception {
        if (epoll) {
            Class<?> g = Class.forName("io.netty.channel.epoll.EpollEventLoopGroup");
            if (threads > 0) {
                return (EventLoopGroup) g.getConstructor(int.class).newInstance(threads);
            }
            return (EventLoopGroup) g.getConstructor().newInstance();
        }
        return threads > 0 ? new NioEventLoopGroup(threads) : new NioEventLoopGroup();
    }

    @SuppressWarnings("unchecked")
    private static Class<? extends ServerSocketChannel> serverChannelClass(boolean epoll) throws Exception {
        if (epoll) {
            return (Class<? extends ServerSocketChannel>)
                    Class.forName("io.netty.channel.epoll.EpollServerSocketChannel");
        }
        return NioServerSocketChannel.class;
    }

    @SuppressWarnings("unchecked")
    private static Class<? extends Channel> datagramChannelClass(boolean epoll) throws Exception {
        if (epoll) {
            return (Class<? extends Channel>)
                    Class.forName("io.netty.channel.epoll.EpollDatagramChannel");
        }
        return NioDatagramChannel.class;
    }
}
