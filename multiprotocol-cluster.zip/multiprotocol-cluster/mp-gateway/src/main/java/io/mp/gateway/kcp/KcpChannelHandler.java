package io.mp.gateway.kcp;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.mp.common.codec.Protocol;
import io.mp.gateway.RequestProcessor;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.socket.DatagramPacket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.SocketAddress;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * KCP 接入 Handler（运行在 UDP 之上）。
 *
 * <p>与裸 UDP 的差异：KCP 提供<b>可靠、有序、带重传</b>的字节流，
 * 上层不再需要关心丢包与乱序，但仍保留 UDP 的低延迟特性
 * （无队头阻塞、RTO 增长更温和）。
 *
 * <h3>为什么必须周期性 update</h3>
 * <p>KCP 靠时钟驱动重传与 ACK。本 Handler 在 {@code handlerAdded}
 * 时通过 EventLoop 的 {@code scheduleAtFixedRate} 以 10ms 周期驱动
 * 所有会话（KCP 内部 interval=100ms）。
 * <b>不驱动就等于没有重传</b>，这是接入 KCP 最容易踩的坑。
 *
 * <h3>会话标识</h3>
 * <p>以「对端地址」为会话键；会话建立时从首个包的前 4 字节读取
 * {@code conv}，后续包由 {@link KcpControl} 校验 conv 一致性。
 *
 * <h3>线程模型</h3>
 * <p>收包与定时驱动都跑在同一个 EventLoop 上，因此会话状态
 * 无需额外加锁。业务处理同步完成，与 TCP/UDP 通道行为一致。
 */
public class KcpChannelHandler extends SimpleChannelInboundHandler<DatagramPacket> {

    private static final Logger log = LoggerFactory.getLogger(KcpChannelHandler.class);

    /** 驱动周期（毫秒），应显著小于 KcpControl.IKCP_INTERVAL */
    private static final long TICK_MS = 10;
    /** 会话空闲超时（毫秒），超时后清理 */
    private static final long SESSION_IDLE_MS = 5 * 60 * 1000L;

    private final RequestProcessor processor;

    /** 会话表：仅在 EventLoop 线程访问，无需并发容器 */
    private final Map<SocketAddress, KcpSession> sessions = new LinkedHashMap<>();

    private ChannelHandlerContext ctx;
    private ScheduledFuture<?> ticker;
    private final AtomicBoolean running = new AtomicBoolean(true);
    private long startMs;

    public KcpChannelHandler(RequestProcessor processor) {
        this.processor = processor;
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) {
        this.ctx = ctx;
        this.startMs = System.currentTimeMillis();
        // 与收包跑在同一 EventLoop，天然串行，无需加锁
        this.ticker = ctx.executor().scheduleAtFixedRate(
                this::tick, TICK_MS, TICK_MS, TimeUnit.MILLISECONDS);
        log.info("KCP 时钟驱动已启动，周期 {}ms", TICK_MS);
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) {
        running.set(false);
        if (ticker != null) {
            ticker.cancel(false);
        }
        sessions.clear();
    }

    /**
     * 定时驱动：推进所有会话时钟、发送待发数据、清理空闲会话。
     *
     * <p>由 EventLoop 线程调用，保证与 channelRead0 串行。
     */
    void tick() {
        if (ctx == null) {
            return;
        }
        long now = System.currentTimeMillis() - startMs;
        Iterator<Map.Entry<SocketAddress, KcpSession>> it = sessions.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<SocketAddress, KcpSession> e = it.next();
            KcpSession s = e.getValue();
            try {
                byte[] out = s.kcp.update(now);
                if (out.length > 0) {
                    sendRaw(e.getKey(), out);
                }
                if (s.isExpired()) {
                    it.remove();
                    log.debug("KCP 会话已清理: {}", e.getKey());
                }
            } catch (Throwable t) {
                log.warn("KCP 会话驱动异常 {}: {}", e.getKey(), t.getMessage());
            }
        }
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, DatagramPacket packet) {
        SocketAddress peer = packet.sender();
        ByteBuf content = packet.content();
        byte[] data = new byte[content.readableBytes()];
        content.getBytes(content.readerIndex(), data);

        if (data.length < KcpSegment.IKCP_OVERHEAD) {
            return;
        }

        KcpSession session = sessions.get(peer);
        if (session == null) {
            int conv = (int) KcpSegment.readUint32(data, 0);
            session = new KcpSession(new KcpControl(conv));
            sessions.put(peer, session);
            log.debug("KCP 会话建立: {} conv={}", peer, conv);
        }

        try {
            session.kcp.input(data);
        } catch (KcpException e) {
            log.warn("KCP 包解析失败 {}: {}", peer, e.getMessage());
            return;
        }
        session.lastActive = System.currentTimeMillis();

        // 取出所有完整消息并处理
        byte[] msg;
        while ((msg = session.kcp.recv()) != null) {
            Frame req;
            try {
                req = FrameCodec.decode(msg);
            } catch (IllegalArgumentException e) {
                log.warn("KCP 帧解析失败: {}", e.getMessage());
                continue;
            }
            Frame resp = processor.process(req, Protocol.KCP);
            byte[] out = FrameCodec.encode(resp);
            try {
                session.kcp.send(out);
            } catch (KcpException e) {
                log.warn("KCP 回包失败: {}", e.getMessage());
            }
        }

        // 立即 flush 一次，让 ACK 与响应尽快发出
        byte[] pending = session.kcp.flush();
        if (pending.length > 0) {
            sendRaw(peer, pending);
        }
    }

    private void sendRaw(SocketAddress peer, byte[] out) {
        ByteBuf buf = ctx.alloc().buffer(out.length);
        buf.writeBytes(out);
        ctx.writeAndFlush(new DatagramPacket(buf, peer));
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.warn("KCP 异常: {}", cause.getMessage());
    }

    // ---------- 诊断 ----------

    /** 当前活跃会话数 */
    public int sessionCount() {
        return sessions.size();
    }

    /** 单个 KCP 会话 */
    static final class KcpSession {
        final KcpControl kcp;
        volatile long lastActive = System.currentTimeMillis();

        KcpSession(KcpControl kcp) {
            this.kcp = kcp;
        }

        boolean isExpired() {
            return System.currentTimeMillis() - lastActive > SESSION_IDLE_MS;
        }
    }
}
