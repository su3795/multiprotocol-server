package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.Protocol;
import io.mp.common.model.Command;
import io.mp.consensus.Consensus;
import io.mp.observability.Metrics;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * 协议无关的业务处理器。
 *
 * <p>关键点：
 * <ul>
 *   <li>输入/输出都是 {@link Frame}，完全不感知底层是 TCP 还是 UDP</li>
 *   <li>写命令（PUT / ROUTE_SET）必须走共识层；读命令走线性读</li>
 *   <li>PING 不走共识，用于压测纯接入层性能</li>
 *   <li>埋点只做原子累加，绝不阻塞</li>
 * </ul>
 */
public final class RequestProcessor {

    private final Consensus consensus;

    public RequestProcessor(Consensus consensus) {
        this.consensus = consensus;
    }

    public Frame process(Frame req, Protocol proto) {
        long start = System.nanoTime();
        try {
            Metrics.get().requests(proto.name(), req.cmd()).increment();
            String text = new String(req.payload(), StandardCharsets.UTF_8);

            switch (req.cmd()) {
                case Cmd.PING:
                    return resp(req, Cmd.OK, "PONG");

                case Cmd.PUT: {
                    if (!consensus.isLeader()) {
                        return resp(req, Cmd.ERR_NOT_LEADER, "not leader, retry on leader");
                    }
                    int eq = text.indexOf('=');
                    if (eq <= 0) {
                        return resp(req, Cmd.ERR_BAD_REQUEST, "expect key=value");
                    }
                    String key = text.substring(0, eq);
                    String value = text.substring(eq + 1);
                    String result = consensus.propose(Command.putKv(key, value));
                    return resp(req, Cmd.OK, result);
                }

                case Cmd.GET: {
                    String value = consensus.linearizableGet(text);
                    return resp(req, Cmd.OK, value == null ? "" : value);
                }

                case Cmd.ROUTE_SET: {
                    if (!consensus.isLeader()) {
                        return resp(req, Cmd.ERR_NOT_LEADER, "not leader");
                    }
                    int eq = text.indexOf('=');
                    if (eq <= 0) {
                        return resp(req, Cmd.ERR_BAD_REQUEST, "expect shardId=node");
                    }
                    long shard = Long.parseLong(text.substring(0, eq).trim());
                    String node = text.substring(eq + 1);
                    String result = consensus.propose(Command.upsertRoute(shard, node));
                    return resp(req, Cmd.OK, result);
                }

                case Cmd.ROUTE_GET: {
                    long shard = Long.parseLong(text.trim());
                    String node = consensus.stateMachine().route(shard);
                    return resp(req, Cmd.OK, node == null ? "" : node);
                }

                case Cmd.STATS: {
                    String stats = String.format(
                            "impl=%s, role=%s, leader=%s, connections=%d, kvCount=%d, routeCount=%d",
                            consensus.implementation(),
                            consensus.role(),
                            consensus.isLeader(),
                            Metrics.get().connectionCount(),
                            consensus.stateMachine().kvCount(),
                            consensus.stateMachine().routeCount());
                    return resp(req, Cmd.OK, stats);
                }

                default:
                    return resp(req, Cmd.ERR_BAD_REQUEST, "unknown cmd " + req.cmd());
            }
        } catch (Exception e) {
            Metrics.get().proposeErrors().increment();
            return resp(req, Cmd.ERR_INTERNAL, "error: " + e.getMessage());
        } finally {
            long costNanos = System.nanoTime() - start;
            Metrics.get().requestDuration(proto.name()).record(costNanos, TimeUnit.NANOSECONDS);
        }
    }

    private static Frame resp(Frame req, int code, String body) {
        String text = (code == Cmd.OK ? "OK|" : "ERR|") + body;
        return new Frame(Frame.FLAG_NEED_RESPONSE, code, req.seq(),
                text.getBytes(StandardCharsets.UTF_8));
    }
}
