package io.mp.gateway;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/** 帧编码器：所有协议共用，保证回包格式统一 */
public class FrameEncoder extends MessageToByteEncoder<Frame> {

    @Override
    protected void encode(ChannelHandlerContext ctx, Frame frame, ByteBuf out) {
        byte[] data = FrameCodec.encode(frame);
        out.writeBytes(data);
    }
}
