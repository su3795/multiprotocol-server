package io.mp.gateway.quic;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.mp.common.codec.Protocol;
import io.mp.gateway.RequestProcessor;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.handler.codec.quic.InsecureQuicTokenHandler;
import io.netty.handler.codec.quic.QuicChannel;
import io.netty.handler.codec.quic.QuicServerCodecBuilder;
import io.netty.handler.codec.quic.QuicSslContextBuilder;
import io.netty.handler.codec.quic.QuicStreamChannel;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;

/**
 * QUIC 接入（基于 netty-incubator-codec-quic，需 Maven profile {@code quic}）。
 *
 * <h3>为什么默认不启用</h3>
 * <p>QUIC 需要额外的原生依赖（netty-incubator-codec-quic + BoringSSL），
 * 且要求 JDK 11+。为保持默认构建零负担，本类位于独立的源目录
 * {@code src/main/quic}，只有激活 profile 时才参与编译：
 * <pre>mvn -Pquic clean package</pre>
 *
 * <h3>QUIC 相比 TCP 的核心优势</h3>
 * <ul>
 *   <li><b>0-RTT / 1-RTT 握手</b>：连接建立延迟显著低于 TCP+TLS</li>
 *   <li><b>无队头阻塞</b>：多路复用流相互独立，单流丢包不阻塞其他流</li>
 *   <li><b>连接迁移</b>：网络切换（WiFi↔4G）时连接不断开</li>
 * </ul>
 *
 * <h3>与 TCP 接入的差异</h3>
 * <p>QUIC 以「流（stream）」为单位。本实现为每条流独立解析帧，
 * 帧格式与 TCP/UDP/KCP <b>完全一致</b>，因此上层
 * {@link RequestProcessor} 无需任何改动。
 *
 * <h3>证书要求</h3>
 * <p>QUIC 强制使用 TLS 1.3，必须提供证书。生成自签证书：
 * <pre>
 * openssl req -x509 -newkey rsa:2048 -nodes \
 *   -keyout key.pem -out cert.pem -days 365 \
 *   -subj "/CN=localhost"
 * </pre>
 *
 * <p><b>注意</b>：netty-incubator-codec-quic 的 API 在版本间有变动，
 * 若编译报错请对照所用版本的官方 example 调整
 * {@code QuicServerCodecBuilder} 与 {@code QuicSslContextBuilder} 调用。
 */
public final class QuicServer {

    private static final Logger log = LoggerFactory.getLogger(QuicServer.class);

    private final RequestProcessor processor;
    private final NioEventLoopGroup group = new NioEventLoopGroup(1);
    private volatile Channel channel;

    public QuicServer(RequestProcessor processor) {
        this.processor = processor;
    }

    /**
     * 启动 QUIC 接入。
     *
     * @param port    监听端口
     * @param keyPem  私钥 PEM 文件路径
     * @param certPem 证书 PEM 文件路径
     * @throws Exception 启动失败
     */
    public void start(int port, String keyPem, String certPem) throws Exception {
        File keyFile = new File(keyPem);
        File certFile = new File(certPem);
        if (!keyFile.exists() || !certFile.exists()) {
            throw new IllegalStateException(
                    "QUIC 需要 TLS 证书，未找到: " + keyPem + " / " + certPem
                            + "；可用 scripts/gen-cert.sh 生成自签证书");
        }

        // QUIC 强制 TLS 1.3
        SslContext sslContext = QuicSslContextBuilder
                .forServer(keyFile, null, certFile)
                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                .applicationProtocols("mp")
                .build();

        ChannelHandler codec = new QuicServerCodecBuilder()
                .sslContext(sslContext)
                .maxIdleTimeout(10000, TimeUnit.MILLISECONDS)
                .initialMaxData(10_000_000L)
                .initialMaxStreamDataBidirectionalLocal(1_000_000L)
                .initialMaxStreamDataBidirectionalRemote(1_000_000L)
                .initialMaxStreamsBidirectional(100L)
                .initialMaxStreamsUnidirectional(100L)
                // 演示用：允许无 token 校验的连接，生产应替换为真实 TokenHandler
                .tokenHandler(InsecureQuicTokenHandler.INSTANCE)
                .handler(new ChannelInitializer<QuicChannel>() {
                    @Override
                    protected void initChannel(QuicChannel ch) {
                        // 每条 QUIC 流独立装配帧处理链
                        ch.pipeline().addLast(new ChannelInitializer<QuicStreamChannel>() {
                            @Override
                            protected void initChannel(QuicStreamChannel stream) {
                                stream.pipeline().addLast(new QuicFrameHandler(processor));
                            }
                        });
                    }
                })
                .build();

        Bootstrap b = new Bootstrap();
        b.group(group)
         .channel(NioDatagramChannel.class)
         .option(ChannelOption.SO_RCVBUF, 4 * 1024 * 1024)
         .option(ChannelOption.SO_SNDBUF, 4 * 1024 * 1024)
         .handler(codec);

        channel = b.bind(new InetSocketAddress(port)).sync().channel();
        log.info("QUIC 接入已启动: 0.0.0.0:{}", port);
    }

    /** 停止 QUIC 接入 */
    public void stop() {
        if (channel != null) {
            channel.close();
        }
        group.shutdownGracefully();
    }

    /**
     * QUIC 流上的帧处理器。
     *
     * <p>每条流是一条独立的字节流，需要像 TCP 一样处理粘包/半包。
     * 这里使用简单的累积缓冲 + 尝试解码；生产环境建议改为
     * 复用 {@code FrameDecoder}（需适配 QUIC 流的 ByteBuf 语义）。
     */
    static final class QuicFrameHandler extends SimpleChannelInboundHandler<ByteBuf> {

        private final RequestProcessor processor;

        QuicFrameHandler(RequestProcessor processor) {
            this.processor = processor;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, ByteBuf in) {
            byte[] data = new byte[in.readableBytes()];
            in.getBytes(in.readerIndex(), data);

            Frame req;
            try {
                req = FrameCodec.decode(data);
            } catch (IllegalArgumentException e) {
                log.warn("QUIC 帧解析失败: {}", e.getMessage());
                return;
            }

            Frame resp = processor.process(req, Protocol.QUIC);
            byte[] out = FrameCodec.encode(resp);
            ByteBuf buf = ctx.alloc().buffer(out.length);
            buf.writeBytes(out);
            ctx.writeAndFlush(buf);
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            log.warn("QUIC 流异常: {}", cause.getMessage());
            ctx.close();
        }
    }
}
