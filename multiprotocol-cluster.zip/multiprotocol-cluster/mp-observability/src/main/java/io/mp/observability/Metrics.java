package io.mp.observability;

import com.sun.net.httpserver.HttpServer;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.prometheus.PrometheusConfig;
import io.micrometer.prometheus.PrometheusMeterRegistry;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 指标门面 + Prometheus 暴露端点。
 *
 * <p>设计要点（与方案文档一致）：
 * <ul>
 *   <li>指标走 Micrometer 门面，后端可换 Prometheus / VictoriaMetrics</li>
 *   <li>埋点只做原子累加，绝不阻塞关键路径</li>
 *   <li>暴露端口独立（默认 9090），与业务端口物理隔离</li>
 * </ul>
 */
public final class Metrics {

    private static volatile Metrics instance;

    private final PrometheusMeterRegistry registry;
    private final AtomicLong connections = new AtomicLong();
    private HttpServer server;

    private Metrics() {
        this.registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
    }

    public static Metrics get() {
        if (instance == null) {
            synchronized (Metrics.class) {
                if (instance == null) {
                    instance = new Metrics();
                }
            }
        }
        return instance;
    }

    public MeterRegistry registry() {
        return registry;
    }

    /** 请求计数，按协议与命令维度打标签 */
    public Counter requests(String protocol, int cmd) {
        return Counter.builder("mp_requests_total")
                .tag("proto", protocol)
                .tag("cmd", String.valueOf(cmd))
                .register(registry);
    }

    /** 请求耗时（μs 级记录，Prometheus 侧换算为秒） */
    public Timer requestDuration(String protocol) {
        return Timer.builder("mp_request_duration")
                .tag("proto", protocol)
                .publishPercentileHistogram()
                .register(registry);
    }

    /** 共识 propose 耗时 */
    public Timer proposeDuration() {
        return Timer.builder("mp_consensus_propose_duration")
                .publishPercentileHistogram()
                .register(registry);
    }

    /** 共识写失败计数 */
    public Counter proposeErrors() {
        return Counter.builder("mp_consensus_propose_errors_total").register(registry);
    }

    /** 当前连接数（ gauge 回调） */
    public void bindConnections() {
        io.micrometer.core.instrument.Gauge.builder("mp_connections_active", connections, AtomicLong::get)
                .register(registry);
    }

    public void incConnection() { connections.incrementAndGet(); }
    public void decConnection() { connections.decrementAndGet(); }
    public long connectionCount() { return connections.get(); }

    /**
     * 启动 Prometheus 抓取端点（/metrics）。
     *
     * @param port 暴露端口，&lt;=0 表示不启动
     */
    public void startScrapeEndpoint(int port) {
        if (port <= 0) {
            return;
        }
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext("/metrics", exchange -> {
                byte[] body = registry.scrape().getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().add("Content-Type", "text/plain; version=0.0.4; charset=utf-8");
                exchange.sendResponseHeaders(200, body.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(body);
                }
            });
            server.start();
        } catch (Exception e) {
            throw new IllegalStateException("启动指标端点失败，端口 " + port, e);
        }
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
        registry.close();
    }

    /** 便捷方法：记录耗时（毫秒） */
    public void recordLatency(Timer timer, long micros) {
        timer.record(micros, TimeUnit.MICROSECONDS);
    }
}
