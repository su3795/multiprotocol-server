#!/usr/bin/env bash
# 构建整个项目（需要 JDK 11+ 与可联网的 Maven）
set -euo pipefail
cd "$(dirname "$0")/.."
echo ">>> 构建 multiprotocol-cluster ..."
mvn -q clean package -DskipTests
echo ">>> 产物: mp-launcher/target/mp-server.jar"
ls -lh mp-launcher/target/mp-server.jar

echo
echo "提示：需要 QUIC 支持时，改用: mvn -Pquic clean package -DskipTests"
