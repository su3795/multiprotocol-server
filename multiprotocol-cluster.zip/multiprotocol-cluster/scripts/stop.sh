#!/usr/bin/env bash
# 停止所有节点
cd "$(dirname "$0")/.."
if [[ -d logs ]]; then
  for pid in logs/*.pid; do
    [[ -f "$pid" ]] || continue
    PID=$(cat "$pid")
    if kill -0 "$PID" 2>/dev/null; then
      echo ">>> 停止进程 $PID"
      kill "$PID"
    fi
    rm -f "$pid"
  done
fi
# Aeron 可能残留 media driver 目录锁
pkill -f "mp-server.jar" 2>/dev/null || true
echo ">>> 已停止"
