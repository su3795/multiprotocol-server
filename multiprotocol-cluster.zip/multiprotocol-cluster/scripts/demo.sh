#!/usr/bin/env bash
# 一键演示：构建 → 启动 jraft 集群 → 跑通 TCP/UDP → 展示指标
set -euo pipefail
cd "$(dirname "$0")/.."

echo "########## 1/5 构建 ##########"
./scripts/build.sh

echo "########## 2/5 启动 3 节点 SOFAJRaft 集群 ##########"
./scripts/start-jraft.sh

echo "########## 3/5 TCP 端到端验证 ##########"
./scripts/test-tcp.sh

echo "########## 4/5 UDP 端到端验证 ##########"
./scripts/test-udp.sh

echo "########## 5/5 抓取 Prometheus 指标 ##########"
echo "--- node1 (9091) ---"
curl -s http://127.0.0.1:9091/metrics | grep -E "^mp_" | head -20

echo
echo "########## 演示完成 ##########"
echo "停止集群: ./scripts/stop.sh"
