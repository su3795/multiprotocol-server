#!/usr/bin/env bash
# 端到端功能验证（TCP）
set -euo pipefail
cd "$(dirname "$0")/.."
JAR="mp-launcher/target/mp-server.jar"
echo ">>> 向节点1(TCP 9101) 发起请求"
java -cp "$JAR" io.mp.launcher.DemoClient --host 127.0.0.1 --tcp-port 9101
