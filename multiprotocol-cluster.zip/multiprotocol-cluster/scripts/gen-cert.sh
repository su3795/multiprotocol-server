#!/usr/bin/env bash
# 生成 QUIC 所需的自签 TLS 证书（仅供演示，生产请用真实 CA 证书）
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p cert

if command -v openssl >/dev/null 2>&1; then
  echo ">>> 使用 openssl 生成自签证书: cert/key.pem / cert/cert.pem"
  openssl req -x509 -newkey rsa:2048 -nodes \
      -keyout cert/key.pem -out cert/cert.pem -days 365 \
      -subj "/CN=localhost"
elif [ -f /etc/ssl/openssl.cnf ]; then
  echo ">>> 使用默认配置生成"
  openssl req -x509 -newkey rsa:2048 -nodes \
      -keyout cert/key.pem -out cert/cert.pem -days 365 \
      -subj "/CN=localhost" -config /etc/ssl/openssl.cnf
else
  echo "❌ 未找到 openssl，请手动安装后再运行本脚本" >&2
  exit 1
fi

echo ">>> 证书已生成:"
ls -lh cert/
echo
echo "启动 QUIC（需先以 -Pquic 构建）:"
echo "  java -jar mp-launcher/target/mp-server.jar --quic-port 9501 \\"
echo "       --quic-key cert/key.pem --quic-cert cert/cert.pem"
