#!/usr/bin/env bash
# 启动 3 节点 Aeron Cluster 集群
set -euo pipefail
cd "$(dirname "$0")/.."
JAR="mp-launcher/target/mp-server.jar"
mkdir -p logs data/aeron

# 所有节点共享同一套 base 端口（clusterMembers 由 base + memberId 推导）
for i in 0 1 2; do
  TP=$((9110 + i))
  UP=$((9210 + i))
  CP=$((9310 + i))
  KP=$((9410 + i))
  MP=$((9095 + i))
  echo ">>> 启动 aeron 节点 memberId=${i}: tcp=${TP} udp=${UP} custom=${CP} kcp=${KP} metrics=${MP}"
  nohup java -jar "$JAR" \
      --mode aeron \
      --member-id "${i}" \
      --data-dir "./data/aeron/node${i}" \
      --tcp-port "${TP}" \
      --udp-port "${UP}" \
      --custom-port "${CP}" \
      --kcp-port "${KP}" \
      --metrics-port "${MP}" \
      > "logs/aeron-node${i}.log" 2>&1 &
  echo $! > "logs/aeron-node${i}.pid"
  sleep 5
done

echo ">>> 全部节点已启动，等待集群形成（Aeron 首次启动较慢，约 20-30s）..."
sleep 25
echo ">>> 节点角色："
for i in 0 1 2; do
  grep -m1 "节点就绪" "logs/aeron-node${i}.log" || echo "  node${i} 尚未就绪"
done
echo ">>> 查看日志: tail -f logs/aeron-node0.log"
