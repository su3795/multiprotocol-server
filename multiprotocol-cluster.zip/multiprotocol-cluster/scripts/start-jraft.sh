#!/usr/bin/env bash
# 启动 3 节点 SOFAJRaft 集群
set -euo pipefail
cd "$(dirname "$0")/.."
JAR="mp-launcher/target/mp-server.jar"
PEERS="127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083"
mkdir -p logs data/jraft

for i in 1 2 3; do
  RP=$((8080 + i))
  TP=$((9100 + i))
  UP=$((9200 + i))
  CP=$((9300 + i))
  KP=$((9400 + i))
  MP=$((9090 + i))
  echo ">>> 启动 jraft 节点 ${i}: raft=${RP} tcp=${TP} udp=${UP} custom=${CP} kcp=${KP} metrics=${MP}"
  nohup java -jar "$JAR" \
      --mode jraft \
      --node-id "127.0.0.1:${RP}" \
      --raft-port "${RP}" \
      --peers "${PEERS}" \
      --data-dir "./data/jraft/node${i}" \
      --tcp-port "${TP}" \
      --udp-port "${UP}" \
      --custom-port "${CP}" \
      --kcp-port "${KP}" \
      --metrics-port "${MP}" \
      > "logs/jraft-node${i}.log" 2>&1 &
  echo $! > "logs/jraft-node${i}.pid"
  sleep 3
done

echo ">>> 全部节点已启动，等待选举..."
sleep 8
echo ">>> 节点角色："
for i in 1 2 3; do
  grep -m1 "节点就绪" "logs/jraft-node${i}.log" || echo "  node${i} 尚未就绪"
done
echo ">>> 查看日志: tail -f logs/jraft-node1.log"
