# 多协议集群服务器 · 可运行 Demo

按前述架构方案实现的**完整可运行参考项目**：多协议接入（TCP / UDP / 自定义帧）+ Raft 强一致集群 + 实时监控与日志 + 性能监测。

**核心特点：共识层可插拔，内置 SOFAJRaft 与 Aeron Cluster 两套实现，运行时通过 `--mode` 一键切换，业务代码零改动。**

---

## 一、模块结构

```
multiprotocol-cluster/
├── mp-common/            # 统一帧格式 + 命令模型（零第三方依赖）
├── mp-consensus-api/     # 共识层抽象接口 + 实现工厂
├── mp-observability/     # Micrometer 指标 + Prometheus 暴露端点
├── mp-gateway/           # Netty 多协议接入层（TCP / UDP / 自定义帧）
├── mp-consensus-jraft/   # ★ SOFAJRaft 实现
├── mp-consensus-aeron/   # ★ Aeron Cluster 实现
├── mp-launcher/          # 启动器 + 演示客户端
└── scripts/              # 构建与集群启停脚本
```

### 分层与依赖

| 层 | 模块 | 职责 |
|---|---|---|
| 帧与命令 | `mp-common` | 统一帧格式、命令模型、路由表状态 |
| 共识抽象 | `mp-consensus-api` | `Consensus` 接口，隔离具体实现 |
| 可观测 | `mp-observability` | 指标采集与 Prometheus 端点 |
| 接入层 | `mp-gateway` | Netty Pipeline：分帧 → 路由 → 业务 → 回包 |
| 共识实现 | `mp-consensus-jraft` / `mp-consensus-aeron` | 两套可切换实现 |
| 启动 | `mp-launcher` | 组装并启动节点 |

---

## 二、统一帧格式

所有协议共用同一帧结构（`mp-common`），协议差异只收敛在接入层：

```
┌────────┬─────────┬───────┬───────┬──────┬────────┬─────────┬───────┐
│ magic  │ version │ flags │  cmd  │ seq  │ length │ payload │ crc32 │
│ 2B 0x4D50│  1B   │  1B   │  4B   │  8B  │   4B   │   N B   │  4B   │
└────────┴─────────┴───────┴───────┴──────┴────────┴─────────┴───────┘
                          头部固定 20B                    尾部 4B
```

- `flags`：bit0=需要响应、bit1=压缩、bit2=加密
- `crc32` 覆盖 `[version .. payload]`，不含 magic 与自身
- TCP 是字节流 → 由 `FrameDecoder` 处理粘包/半包；UDP 是数据报 → 天然分帧，直接整包解码

### 命令字

| cmd | 名称 | 是否走共识 | 说明 |
|---|---|---|---|
| 1 | `PUT` | ✅ 写 | 写 KV，仅 Leader 可写 |
| 2 | `GET` | ✅ 线性读 | ReadIndex / Leader 读 |
| 3 | `ROUTE_SET` | ✅ 写 | 设置 `shard → node` 路由 |
| 4 | `ROUTE_GET` | 本地读 | 读路由表 |
| 5 | `PING` | ❌ | 不走共识，用于压测纯接入层 |
| 6 | `STATS` | ❌ | 返回角色/连接数/KV 数量 |

---

## 三、快速开始

### 前置条件

| 组件 | 版本 | 说明 |
|---|---|---|
| JDK | **11+** | 已在 `pom.xml` 固定 `maven.compiler.source=11` |
| Maven | 3.6+ | 需要能访问 Maven 中央仓库以下载依赖 |
| 内存 | 4GB+ | 3 节点同机启动 |

> **Aeron 额外要求**：Aeron 的 Media Driver 使用共享内存（`/dev/shm`）。
> Linux 默认 `/dev/shm` 通常只有 64MB，可能不足。若启动失败请先执行：
> ```bash
> sudo mount -o remount,size=1G /dev/shm
> ```
> Docker 环境需加 `--shm-size=1g`。

### 1. 构建

```bash
cd multiprotocol-cluster
./scripts/build.sh          # 等价于 mvn clean package -DskipTests
```

产物：`mp-launcher/target/mp-server.jar`（fat jar，已包含全部依赖）

### 2. 启动集群

**SOFAJRaft 模式（推荐先跑这个）**

```bash
./scripts/start-jraft.sh    # 启动 3 节点
```

**Aeron Cluster 模式**

```bash
./scripts/start-aeron.sh    # 启动 3 节点，首次启动约需 20-30s
```

### 3. 端到端验证

```bash
./scripts/test-tcp.sh       # TCP 链路
./scripts/test-udp.sh       # UDP 链路
```

预期输出：

```
=== 演示客户端 · TCP → 127.0.0.1 ===
PING       → OK|PONG
PUT        → OK|applied, cost=1820us
PUT        → OK|applied, cost=940us
GET        → OK|alice
ROUTE_SET  → OK|applied, cost=1150us
ROUTE_GET  → OK|node-3
STATS      → OK|impl=SOFAJRaft, role=LEADER, leader=true, connections=1, kvCount=2, routeCount=1
```

> `cost` 为一次 Raft 复制+提交+应用的耗时。三节点同机时通常在 **0.5~3ms**。

### 4. 查看监控指标

```bash
curl http://127.0.0.1:9091/metrics | grep ^mp_
```

暴露的指标：

| 指标 | 类型 | 说明 |
|---|---|---|
| `mp_requests_total` | Counter | 按协议/命令维度的请求数 |
| `mp_request_duration` | Timer | 请求耗时（含百分位直方图） |
| `mp_consensus_propose_duration` | Timer | Raft propose→commit→apply 耗时 |
| `mp_consensus_propose_errors_total` | Counter | 共识写失败数 |
| `mp_connections_active` | Gauge | 当前活跃连接数 |

### 5. 停止

```bash
./scripts/stop.sh
```

### 一键演示

```bash
./scripts/demo.sh   # 构建 → 启动 → TCP/UDP 验证 → 抓指标
```

---

## 四、两套共识实现对比

| 维度 | SOFAJRaft | Aeron Cluster |
|---|---|---|
| 定位 | 可嵌入一致性库（不含传输层） | 一体化集群框架（传输+归档+共识+容器） |
| 日志复制 | Replicator 显式 AppendEntries + 流水线 | Follower 订阅 Leader log buffer，Transport 自动复制 |
| 提交判定 | 多数派**已接收**即 commit，fsync 可配 | 多数派**已落盘**的 AppendPosition = CommitPosition |
| 索引方式 | (TermId, LogIndex) | 字节索引（byte indexing） |
| 状态机 | 无强制确定性，可自行并发 | **强制确定性**，单线程，禁读时钟/外部 IO/随机数 |
| 快照 | Leader 触发 InstallSnapshot | 任意节点可拍快照 |
| 多组分片 | **原生 Multi-Raft-Group**（10K+ 组） | 非原生，需自行按 shard 分区 |
| 线性读 | ReadIndex / LeaseRead | 仅 Leader 的 Egress 响应生效，Follower 重定向 |
| 成员变更 | 增/删/替换 + TransferLeader | 官方提示动态成员变更有陷阱，推荐 warm standby |
| 正确性验证 | 通过 Jepsen | 官方与社区文档为主 |
| 许可 | Apache 2.0，全功能开源 | 核心 Apache 2.0；内核旁路/ATS 加密为商业版 |

### 为什么本 Demo 默认 SOFAJRaft

1. **改造面小**：已有 Netty 接入层，SOFAJRaft 只替换一致性层；Aeron Cluster 会要求连传输层一起换成 Aeron。
2. **分片是刚需**：方案靠 Multi-Group 分片消除单 Leader 瓶颈，SOFAJRaft 原生支持。
3. **无强制确定性**：保留未来引入外部调用的灵活性。

### 什么时候改用 Aeron Cluster

当且仅当：**单集群组数少 + 延迟要求微秒级 + 状态机可完全确定性 + 能接受商业版成本**。
典型场景：撮合引擎、RFQ/IOI 协商、消息排序器、实时风控、游戏房间状态。

---

## 五、切换共识实现

只需改 `--mode`，其余代码与命令完全一致：

```bash
# SOFAJRaft
java -jar mp-server.jar --mode jraft --node-id 127.0.0.1:8081 \
     --raft-port 8081 --peers 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083 \
     --data-dir ./data/jraft/node1 --tcp-port 9101 --udp-port 9201 --metrics-port 9091

# Aeron Cluster
java -jar mp-server.jar --mode aeron --member-id 0 \
     --data-dir ./data/aeron/node0 --tcp-port 9110 --udp-port 9210 --metrics-port 9095
```

切换逻辑在 `ConsensusProvider` 中，按名称反射加载实现：

```java
Consensus consensus = ConsensusProvider.create(mode, args);
```

---

## 六、扩展新协议

新增一个协议只需两步，业务代码零改动：

1. 实现对应的 `ChannelHandler`（如 QUIC 用 `netty-incubator-codec-quic`）
2. 在 `GatewayServer` 中注册到 Pipeline

```
pipeline.addLast(new FrameDecoder());     // 分帧（UDP 不需要）
pipeline.addLast(new FrameEncoder());     // 编码
pipeline.addLast(new TcpChannelHandler(processor));  // 业务，协议无关
```

`RequestProcessor` 只认 `Frame`，完全不感知底层协议。

---

## 七、运行单元测试

```bash
mvn test
```

当前包含 `FrameCodecTest`：帧编解码往返、CRC 校验失败、半包处理、命令序列化往返。

---

## 八、端口规划

### SOFAJRaft 模式

| 节点 | Raft | TCP | UDP | Metrics |
|---|---|---|---|---|
| node1 | 8081 | 9101 | 9201 | 9091 |
| node2 | 8082 | 9102 | 9202 | 9092 |
| node3 | 8083 | 9103 | 9203 | 9093 |

### Aeron 模式

| 成员 | consensus | ingress | log | catchup | archive | TCP/UDP |
|---|---|---|---|---|---|---|
| 0 | 20110 | 20210 | 20310 | 20410 | 8010 | 9110/9210 |
| 1 | 20111 | 20211 | 20311 | 20411 | 8011 | 9111/9211 |
| 2 | 20112 | 20212 | 20312 | 20412 | 8012 | 9112/9212 |

---

## 九、⚠️ 验证状态与已知风险（请务必阅读）

### 本项目**未在真实环境中编译与运行验证**

生成该项目的沙盒环境存在以下限制：

| 限制 | 影响 |
|---|---|
| 无 JDK（仅有 JRE 11，无 `javac`） | 无法编译任何 Java 代码 |
| 无 Maven | 无法执行构建 |
| 外网 Maven 仓库不可达 | 无法下载 SOFAJRaft / Aeron / Netty 依赖 |

因此，交付的是**完整源码**，逻辑经过逐行审阅，但**未经编译器与运行时验证**。首次构建时请以下面清单排查。

### 依赖版本

| 依赖 | 版本 | 兼容性说明 |
|---|---|---|
| Netty | 4.1.100.Final | JDK 8+ |
| SOFAJRaft | 1.3.14 | JDK 8+ |
| Aeron | 1.42.1 | **1.44+ 需 JDK17**，本项目锁 1.42.x 以兼容 JDK11 |
| Micrometer | 1.12.2 | JDK 8+ |
| Agrona | 1.20.0 | 与 Aeron 1.42.x 匹配 |

### 最可能需要调整的地方

1. **Aeron 的 `EventCode` 类型**（`AeronConsensus.java` 的 `onSessionEvent`）
   本项目使用 `io.aeron.cluster.codecs.EventCode`。若你的 Aeron 版本更名为
   `io.aeron.cluster.client.ClusterEvent`，请替换该类型名即可。

2. **Aeron 的 `clusterMembers` 格式**
   本项目使用 6 段格式 `id,consensus,ingress,log,catchup,archive`。
   若版本差异导致解析失败，请以官方 `BasicAuctionClusteredServiceNode` 示例为准调整。

3. **SOFAJRaft 的 RPC 端口**
   `RaftRpcServerFactory.createRaftRpcServer(raftPort)` 使用与 `node-id` 相同的端口。
   若需分离，请另行创建 `RpcServer`。

4. **Aeron 的 `/dev/shm`**
   见上文「前置条件」，这是 Aeron 启动失败的最常见原因。

### 建议的验证顺序

```bash
mvn test                    # 1. 先跑零依赖的帧编解码测试
./scripts/build.sh          # 2. 全量构建，暴露编译期问题
./scripts/start-jraft.sh    # 3. 先跑 SOFAJRaft（比 Aeron 更容易跑通）
./scripts/test-tcp.sh       # 4. 端到端验证
./scripts/start-aeron.sh    # 5. 再尝试 Aeron
```

---

## 十、与方案文档的对应关系

| 方案要求 | 本项目实现 |
|---|---|
| 支持 TCP/UDP/QUIC/KCP/自定义 | `mp-gateway`：TCP + UDP 已实现，QUIC/KCP 扩展点已预留 |
| 集群采用 Raft 协议 | `mp-consensus-jraft`（SOFAJRaft）+ `mp-consensus-aeron`（Aeron Cluster） |
| 实时网络请求数据监控 | `mp-observability`：按协议/命令维度的 QPS、耗时直方图 |
| 日志 | Logback + SLF4J，关键路径埋点；生产建议换 Log4j2 异步（见方案文档） |
| 性能监测 | Micrometer Timer 采集 P50/P90/P99，Prometheus 端点暴露 |
| 只有元数据上 Raft | `Command` 仅含路由/配置/会话归属/KV，业务数据流不进共识层 |

---

## License

参考实现，可自由使用与修改。

---

## 协议支持（已补全至 5 种）

| 协议 | 状态 | 端口 | 启用方式 |
|---|:---:|:---:|---|
| TCP | ✅ | 9101 | 默认 |
| UDP | ✅ | 9201 | 默认 |
| **KCP** | ✅ 新增 | 9401 | 默认（`--kcp-port`） |
| **CUSTOM** | ✅ 新增 | 9301 | 默认（`--custom-port`） |
| **QUIC** | ✅ 新增 | 9501 | 需 `mvn -Pquic` + `--quic-port` |

### 新增实现位置

| 协议 | 文件 |
|---|---|
| KCP 控制块 | `mp-gateway/.../kcp/KcpControl.java` |
| KCP 段编解码 | `mp-gateway/.../kcp/KcpSegment.java` |
| KCP Netty 接入 | `mp-gateway/.../kcp/KcpChannelHandler.java` |
| CUSTOM 接入 | `mp-gateway/.../CustomChannelHandler.java` |
| CUSTOM payload 变换 | `mp-gateway/.../custom/PayloadCodec.java` |
| QUIC 接入 | `mp-gateway/src/main/quic/.../quic/QuicServer.java` |
| KCP 单元测试 | `mp-gateway/src/test/.../kcp/KcpControlTest.java` |

### KCP 要点

- **必须周期性 update**：`KcpChannelHandler` 在 `handlerAdded` 时通过
  EventLoop 的 `scheduleAtFixedRate` 以 **10ms** 周期驱动（KCP 内部 interval=100ms）。
  **不驱动就等于没有重传**。
- **会话靠 conv**：首个包前 4 字节读取 conv，以对端地址为会话键。
- **单条消息上限**：分片数 ≤ 255，约 345KB。

### CUSTOM 要点

默认使用 `PayloadCodec.noop()`（恒等变换），**保证与 Go/Rust 版 CUSTOM 端口互通**。
需要私有变换时注入 `PayloadCodec.xor(key)` 或自定义实现 ——
但三版必须使用相同算法才能互通。

### QUIC 要点

1. 需 `mvn -Pquic clean package`（引入 `netty-incubator-codec-quic`）
2. 需 TLS 证书：`./scripts/gen-cert.sh`
3. 启动加 `--quic-port 9501 --quic-key cert/key.pem --quic-cert cert/cert.pem`
4. 未以 `-Pquic` 构建时，`ServerMain` 用**反射探测**，不会加载 QUIC 类，
   默认构建完全不受影响。

> ⚠️ QUIC 是本项目**唯一完全未验证**的部分（无工具链、无网络可拉取依赖）。
> `QuicServerCodecBuilder` 的 API 在 0.0.x 各版本间有变动，
> 编译报错请对照所用版本的官方 example 调整。
