package io.mp.consensus;

import io.mp.common.model.Command;
import io.mp.common.model.RouteTable;

/**
 * 共识层统一抽象。
 *
 * <p>本项目同时提供两套实现，运行期通过 {@code --mode} 切换，业务代码零改动：
 * <ul>
 *   <li>{@code jraft} → SOFAJRaft（可嵌入一致性库，原生 Multi-Raft-Group）</li>
 *   <li>{@code aeron} → Aeron Cluster（一体化集群框架，强制确定性状态机）</li>
 * </ul>
 *
 * <p><b>三条硬约束</b>：
 * <ol>
 *   <li>只有元数据上共识层，业务数据流不进 Raft</li>
 *   <li>状态机 apply 必须幂等（日志会被重放与重试）</li>
 *   <li>Aeron 模式下状态机必须完全确定性：禁止读时钟、外部 IO、随机数</li>
 * </ol>
 */
public interface Consensus extends AutoCloseable {

    /** 启动本节点的共识服务 */
    void start() throws Exception;

    /** 当前节点是否为 Leader */
    boolean isLeader();

    /** 当前节点角色（便于日志与监控展示） */
    String role();

    /**
     * 提交一条命令到共识层。仅 Leader 可写；非 Leader 会抛出异常由上层重定向。
     *
     * @return 应用后的结果描述（演示用）
     */
    String propose(Command cmd) throws Exception;

    /**
     * 线性一致读。
     * <ul>
     *   <li>SOFAJRaft：走 ReadIndex / LeaseRead</li>
     *   <li>Aeron Cluster：仅 Leader 的响应生效，Follower 重定向到 Leader</li>
     * </ul>
     */
    String linearizableGet(String key) throws Exception;

    /** 本地状态机（非 Leader 也可用，但为最终一致） */
    RouteTable stateMachine();

    /** 实现名称，用于启动日志 */
    String implementation();
}
