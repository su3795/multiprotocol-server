package io.mp.consensus;

/**
 * 按名称加载共识实现。
 *
 * <p>采用显式映射而非 ServiceLoader，是为了让「两套实现共存于同一个 fat jar」
 * 时行为可预测，且避免遗漏 META-INF/services 配置导致运行期失败。
 */
public final class ConsensusProvider {

    private static final String JRAFT = "io.mp.consensus.jraft.JRaftConsensus";
    private static final String AERON = "io.mp.consensus.aeron.AeronConsensus";

    private ConsensusProvider() {
    }

    /**
     * @param mode {@code jraft} 或 {@code aeron}
     * @param args 透传给具体实现的构造参数（各实现自定义解析）
     */
    public static Consensus create(String mode, String[] args) {
        String className;
        if ("jraft".equalsIgnoreCase(mode)) {
            className = JRAFT;
        } else if ("aeron".equalsIgnoreCase(mode)) {
            className = AERON;
        } else {
            throw new IllegalArgumentException("未知共识模式: " + mode + "（可选 jraft / aeron）");
        }
        try {
            Class<?> clazz = Class.forName(className);
            return (Consensus) clazz.getConstructor(String[].class).newInstance((Object) args);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("无法创建共识实现 " + className + "，请确认对应模块已在 classpath 中", e);
        }
    }
}
