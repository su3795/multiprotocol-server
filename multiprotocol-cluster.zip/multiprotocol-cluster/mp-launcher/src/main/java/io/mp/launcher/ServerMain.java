package io.mp.launcher;

import io.mp.consensus.Consensus;
import io.mp.consensus.ConsensusProvider;
import io.mp.gateway.GatewayServer;
import io.mp.observability.Metrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

/**
 * 集群节点启动入口。
 *
 * <pre>
 * 用法：
 *   java -jar mp-server.jar --mode jraft --node-id 127.0.0.1:8081 \
 *        --raft-port 8081 --peers 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083 \
 *        --data-dir ./data/node1 --tcp-port 9101 --udp-port 9201 --metrics-port 9091
 *
 *   java -jar mp-server.jar --mode aeron --member-id 0 \
 *        --data-dir ./data/aeron-node0 --tcp-port 9101 --udp-port 9201 --metrics-port 9091
 *
 * 端口默认值：TCP=9101 UDP=9201 CUSTOM=9301 KCP=9401 metrics=9091
 * QUIC 默认关闭，需 -Pquic 构建 + 证书：
 *   java -jar mp-server.jar --quic-port 9501 --quic-key cert/key.pem --quic-cert cert/cert.pem
 * </pre>
 */
public class ServerMain {

    private static final Logger log = LoggerFactory.getLogger(ServerMain.class);

    private static String mode = "jraft";
    private static int tcpPort = 9101;
    private static int udpPort = 9201;
    private static int customPort = 9301;
    private static int kcpPort = 9401;
    private static int quicPort = 0;
    private static String quicKey = "cert/key.pem";
    private static String quicCert = "cert/cert.pem";
    private static int metricsPort = 9091;

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--mode":         mode = args[++i]; break;
                case "--tcp-port":     tcpPort = Integer.parseInt(args[++i]); break;
                case "--udp-port":     udpPort = Integer.parseInt(args[++i]); break;
                case "--custom-port":  customPort = Integer.parseInt(args[++i]); break;
                case "--kcp-port":     kcpPort = Integer.parseInt(args[++i]); break;
                case "--quic-port":    quicPort = Integer.parseInt(args[++i]); break;
                case "--quic-key":     quicKey = args[++i]; break;
                case "--quic-cert":    quicCert = args[++i]; break;
                case "--metrics-port": metricsPort = Integer.parseInt(args[++i]); break;
                default: break;
            }
        }

        log.info("=".repeat(60));
        log.info("多协议集群服务器启动中 · 共识实现 = {}", mode.toUpperCase());
        log.info("参数: {}", Arrays.toString(args));
        log.info("=".repeat(60));

        Consensus consensus = ConsensusProvider.create(mode, args);
        consensus.start();

        Metrics.get().bindConnections();
        Metrics.get().startScrapeEndpoint(metricsPort);
        log.info("指标端点: http://0.0.0.0:{}/metrics", metricsPort);

        GatewayServer gateway =
                new GatewayServer(consensus, tcpPort, udpPort, customPort, kcpPort);
        gateway.start();

        // QUIC 为可选能力：仅在 -Pquic 构建且显式指定端口时启用。
        // 这里用反射调用而非直接引用，保证默认构建（不含 quic 源目录）也能编译。
        Object quicServer = null;
        if (quicPort > 0) {
            try {
                Class<?> cls = Class.forName("io.mp.gateway.quic.QuicServer");
                Object inst = cls.getConstructor(io.mp.gateway.RequestProcessor.class)
                        .newInstance(new io.mp.gateway.RequestProcessor(consensus));
                cls.getMethod("start", int.class, String.class, String.class)
                        .invoke(inst, quicPort, quicKey, quicCert);
                quicServer = inst;
                log.info("QUIC 接入已启用: 0.0.0.0:{}", quicPort);
            } catch (ClassNotFoundException e) {
                log.warn("已指定 --quic-port 但未以 -Pquic 构建，QUIC 类不在 classpath 中");
            } catch (Throwable t) {
                log.warn("QUIC 启动失败（将以无 QUIC 模式继续）: {}", t.getMessage());
            }
        }

        final Object finalQuic = quicServer;

        log.info("-".repeat(60));
        log.info("节点就绪 | 实现={} | 角色={} | TCP={} | UDP={} | CUSTOM={} | KCP={} | QUIC={}",
                consensus.implementation(), consensus.role(),
                tcpPort, udpPort, customPort, kcpPort,
                quicPort > 0 ? String.valueOf(quicPort) : "-");
        log.info("-".repeat(60));

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("正在关闭节点...");
            if (finalQuic != null) {
                try {
                    finalQuic.getClass().getMethod("stop").invoke(finalQuic);
                } catch (Throwable ignored) {
                    // ignore
                }
            }
            gateway.stop();
            try {
                consensus.close();
            } catch (Exception ignored) {
                // ignore
            }
            Metrics.get().stop();
            log.info("节点已关闭");
        }, "shutdown-hook"));

        Thread.currentThread().join();
    }
}
