package io.mp.launcher;

import io.mp.common.codec.Frame;
import io.mp.common.codec.FrameCodec;
import io.mp.gateway.Cmd;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 演示客户端：用原生 Socket / DatagramSocket 直接发帧，验证端到端链路。
 *
 * <pre>
 * 用法：
 *   java -cp mp-server.jar io.mp.launcher.DemoClient --host 127.0.0.1 --tcp-port 9101
 *   java -cp mp-server.jar io.mp.launcher.DemoClient --host 127.0.0.1 --udp-port 9201 --proto udp
 * </pre>
 */
public class DemoClient {

    private static final AtomicLong seqGen = new AtomicLong(1);

    private static String host = "127.0.0.1";
    private static int tcpPort = 9101;
    private static int udpPort = 9201;
    private static String proto = "tcp";

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--host":     host = args[++i]; break;
                case "--tcp-port": tcpPort = Integer.parseInt(args[++i]); break;
                case "--udp-port": udpPort = Integer.parseInt(args[++i]); break;
                case "--proto":    proto = args[++i]; break;
                default: break;
            }
        }

        System.out.println("=== 演示客户端 · " + proto.toUpperCase() + " → " + host + " ===");

        if ("udp".equalsIgnoreCase(proto)) {
            runUdp();
        } else {
            runTcp();
        }
    }

    private static void runTcp() throws Exception {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, tcpPort), 5000);
            socket.setSoTimeout(10000);
            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();

            // 1. 心跳（不走共识，测纯接入层）
            sendRecvTcp(out, in, Cmd.PING, "hello");
            // 2. 写 KV（走共识）
            sendRecvTcp(out, in, Cmd.PUT, "user:1=alice");
            sendRecvTcp(out, in, Cmd.PUT, "user:2=bob");
            // 3. 线性一致读
            sendRecvTcp(out, in, Cmd.GET, "user:1");
            // 4. 设置分片路由
            sendRecvTcp(out, in, Cmd.ROUTE_SET, "7=node-3");
            sendRecvTcp(out, in, Cmd.ROUTE_GET, "7");
            // 5. 节点状态
            sendRecvTcp(out, in, Cmd.STATS, "");
        }
    }

    private static void runUdp() throws Exception {
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(10000);
            InetSocketAddress target = new InetSocketAddress(host, udpPort);

            sendRecvUdp(socket, target, Cmd.PING, "hello");
            sendRecvUdp(socket, target, Cmd.PUT, "user:3=carol");
            sendRecvUdp(socket, target, Cmd.GET, "user:3");
            sendRecvUdp(socket, target, Cmd.STATS, "");
        }
    }

    private static void sendRecvTcp(OutputStream out, InputStream in, int cmd, String payload) throws Exception {
        Frame req = new Frame(Frame.FLAG_NEED_RESPONSE, cmd, seqGen.getAndIncrement(),
                payload.getBytes(StandardCharsets.UTF_8));
        byte[] data = FrameCodec.encode(req);
        out.write(data);
        out.flush();

        byte[] buf = new byte[4096];
        int total = 0;
        while (true) {
            int n = in.read(buf, total, buf.length - total);
            if (n < 0) {
                throw new IllegalStateException("连接已关闭");
            }
            total += n;
            if (total >= Frame.HEADER_SIZE) {
                int need = FrameCodec.frameLength(buf);
                if (total >= need) {
                    break;
                }
            }
        }
        Frame resp = FrameCodec.decode(buf, 0, total);
        print(Cmd.name(cmd), new String(resp.payload(), StandardCharsets.UTF_8));
    }

    private static void sendRecvUdp(DatagramSocket socket, InetSocketAddress target, int cmd, String payload)
            throws Exception {
        Frame req = new Frame(Frame.FLAG_NEED_RESPONSE, cmd, seqGen.getAndIncrement(),
                payload.getBytes(StandardCharsets.UTF_8));
        byte[] data = FrameCodec.encode(req);
        socket.send(new DatagramPacket(data, data.length, target));

        byte[] buf = new byte[4096];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        Frame resp = FrameCodec.decode(buf, 0, packet.getLength());
        print(Cmd.name(cmd), new String(resp.payload(), StandardCharsets.UTF_8));
    }

    private static void print(String cmd, String resp) {
        // 响应格式: "OK|<body>" 或 "ERR|<body>"
        System.out.printf("%-10s → %s%n", cmd, resp);
    }
}
