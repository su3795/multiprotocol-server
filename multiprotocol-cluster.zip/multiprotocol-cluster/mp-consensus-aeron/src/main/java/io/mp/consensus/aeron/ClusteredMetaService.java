package io.mp.consensus.aeron;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.Cluster;
import io.aeron.cluster.service.ClientSession;
import io.aeron.cluster.service.ClusteredService;
import io.aeron.cluster.service.Cluster.Role;
import io.aeron.logbuffer.Header;
import io.mp.common.model.Command;
import io.mp.common.model.RouteTable;
import org.agrona.DirectBuffer;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.IdleStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;

/**
 * Aeron Cluster 状态机（ClusteredService）。
 *
 * <p><b>最重要的约束：完全确定性</b>。
 * ClusteredService 单线程运行，且只能从日志获取输入：
 * <ul>
 *   <li>禁止读取当前时钟（使用回调传入的 {@code timestampNs}）</li>
 *   <li>禁止外部 IO（网络、磁盘、数据库）</li>
 *   <li>禁止随机数、禁止依赖 HashMap 迭代顺序等不确定行为</li>
 * </ul>
 * 违反任一条都会导致各副本状态发散，这是 Aeron Cluster 与 SOFAJRaft 最大的使用差异。
 *
 * <p>消息格式（客户端 → 集群）：{@code [correlationId:8][commandBytes]} <br>
 * 响应格式（集群 → 客户端）：{@code [correlationId:8][payload]}
 */
public class ClusteredMetaService implements ClusteredService {

    private static final Logger log = LoggerFactory.getLogger(ClusteredMetaService.class);
    private static final int FRAGMENT_LIMIT = 10;

    private final RouteTable table = new RouteTable();
    private final MutableDirectBuffer replyBuffer = new ExpandableArrayBuffer(4096);

    private volatile Cluster cluster;
    private volatile Role role = Role.FOLLOWER;

    public RouteTable table() {
        return table;
    }

    public Role role() {
        return role;
    }

    public boolean isLeader() {
        return role == Role.LEADER;
    }

    @Override
    public void onStart(Cluster cluster, Image snapshotImage) {
        this.cluster = cluster;
        log.info("ClusteredService 启动，加载快照: {}", snapshotImage != null);

        if (snapshotImage != null) {
            final IdleStrategy idle = new BackoffIdleStrategy();
            final boolean[] done = {false};
            while (!done[0]) {
                int fragments = snapshotImage.poll((buffer, offset, length, header) -> {
                    byte[] data = new byte[length];
                    buffer.getBytes(offset, data);
                    table.loadSnapshot(data);
                    log.info("已从快照恢复状态 ({} bytes)", length);
                    done[0] = true;
                }, FRAGMENT_LIMIT);

                if (fragments == 0) {
                    if (snapshotImage.isEndOfStream()) {
                        break;
                    }
                    idle.idle();
                } else {
                    idle.reset();
                }
            }
        }
    }

    @Override
    public void onSessionOpen(ClientSession session, long timestampNs) {
        log.debug("会话建立: sessionId={}", session.id());
    }

    @Override
    public void onSessionClose(ClientSession session, long timestampNs, CloseReason closeReason) {
        log.debug("会话关闭: sessionId={}, reason={}", session.id(), closeReason);
    }

    @Override
    public void onSessionMessage(
            ClientSession session, long timestampNs,
            DirectBuffer buffer, int offset, int length, Header header) {

        byte[] data = new byte[length];
        buffer.getBytes(offset, data);
        ByteBuffer bb = ByteBuffer.wrap(data);

        long correlationId = bb.getLong();
        byte[] cmdBytes = new byte[bb.remaining()];
        bb.get(cmdBytes);

        String result;
        try {
            // 读请求（GET）不产生状态变更，直接读本地状态机即可——
            // 因为 Aeron 保证 follower 也按相同顺序 apply 了所有日志
            if (cmdBytes.length == 0) {
                result = "";
            } else {
                Command cmd = Command.deserialize(cmdBytes);
                table.apply(cmd);           // 幂等写入
                result = "applied:" + cmd.type();
            }
        } catch (Exception e) {
            log.error("处理消息失败", e);
            result = "error:" + e.getMessage();
        }

        // 只有 Leader 的响应会真正送达客户端，Follower 的响应被静默丢弃
        byte[] payload = result.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        replyBuffer.putLong(0, correlationId);
        replyBuffer.putBytes(8, payload);

        long offered;
        while ((offered = session.reply(replyBuffer, 0, 8 + payload.length)) < 0) {
            Thread.onSpinWait();
        }
        if (offered == 0) {
            log.warn("reply 被背压拒绝, correlationId={}", correlationId);
        }
    }

    @Override
    public void onTimerEvent(long correlationId, long timestampNs) {
        // demo 未使用可靠定时器
    }

    @Override
    public void onTakeSnapshot(ExclusivePublication snapshotPublication) {
        byte[] snapshot = table.snapshot();
        final IdleStrategy idle = new BackoffIdleStrategy();
        // Aeron 允许任意节点拍快照，不会因快照造成 Leader 停顿
        while (snapshotPublication.offer(snapshot, 0, snapshot.length) < 0) {
            idle.idle();
        }
        log.info("快照已写出: {} bytes", snapshot.length);
    }

    @Override
    public void onRoleChange(Role newRole) {
        this.role = newRole;
        log.info("==> 角色变更: {}", newRole);
    }

    @Override
    public void onTerminate(Cluster cluster) {
        log.info("ClusteredService 终止");
    }

    @Override
    public void onNewLeadershipTermEvent(
            long leadershipTermId, long logPosition, long timestampNs,
            long termBaseLogPosition, int leaderMemberId,
            int logSessionId, java.util.concurrent.TimeUnit timeUnit, int appVersion) {
        log.info("==> 新任期: term={}, leaderMemberId={}, logPosition={}",
                leadershipTermId, leaderMemberId, logPosition);
    }
}
