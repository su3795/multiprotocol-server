package io.mp.consensus.aeron;

import io.aeron.archive.Archive;
import io.aeron.cluster.ConsensusModule;
import io.aeron.cluster.client.AeronCluster;
import io.aeron.cluster.client.AeronCluster.Context;
import io.aeron.cluster.client.EgressListener;
import io.aeron.cluster.codecs.EventCode;
import io.aeron.cluster.service.ClusteredServiceContainer;
import io.aeron.driver.MediaDriver;
import io.aeron.cluster.ClusteredMediaDriver;
import io.mp.common.model.Command;
import io.mp.common.model.RouteTable;
import io.mp.consensus.Consensus;
import io.mp.observability.Metrics;
import org.agrona.CloseHelper;
import org.agrona.DirectBuffer;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.IdleStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Aeron Cluster 共识实现。
 *
 * <p>启动参数：
 * <pre>
 *   --member-id   0|1|2
 *   --cluster-host localhost
 *   --data-dir     ./data/aeron-node0
 *   --consensus-base-port 20110
 *   --ingress-base-port    20210
 * </pre>
 *
 * <p>与 SOFAJRaft 的关键差异（详见方案文档）：
 * <ul>
 *   <li>提交判定：多数派<b>已落盘</b>才推进 CommitPosition → 持久性更强，延迟受磁盘 IO 影响</li>
 *   <li>日志复制不靠 AppendEntries RPC，而由 Aeron Transport 订阅 Leader 的 log buffer 自动完成</li>
 *   <li>状态机强制确定性、单线程；任意节点都可拍快照</li>
 *   <li>非原生 Multi-Raft：本 demo 单组运行，横向扩展需自行按 shard 分区</li>
 * </ul>
 *
 * <p><b>注意</b>：本节点同时启动「集群成员」与「集群客户端」两个角色，
 * 客户端通过 ingress 通道提交命令，这与生产部署（客户端独立进程）等价，只是便于单机演示。
 */
public class AeronConsensus implements Consensus {

    private static final Logger log = LoggerFactory.getLogger(AeronConsensus.class);

    private int memberId = 0;
    private String host = "localhost";
    private String dataDir = "./data/aeron-node0";
    private int consensusBasePort = 20110;
    private int ingressBasePort = 20210;
    private int logBasePort = 20310;
    private int catchupBasePort = 20410;
    private int archiveBasePort = 8010;

    private ClusteredMediaDriver clusteredMediaDriver;
    private ClusteredServiceContainer serviceContainer;
    private ClusteredMetaService service;

    private AeronCluster client;
    private final AtomicLong correlationIdGen = new AtomicLong(1);
    private final ConcurrentHashMap<Long, BlockingQueue<byte[]>> pending = new ConcurrentHashMap<>();
    private final MutableDirectBuffer offerBuffer = new ExpandableArrayBuffer(4096);
    private final IdleStrategy idle = new BackoffIdleStrategy();

    public AeronConsensus(String[] args) {
        parseArgs(args);
    }

    private void parseArgs(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--member-id":           memberId = Integer.parseInt(args[++i]); break;
                case "--cluster-host":        host = args[++i]; break;
                case "--data-dir":            dataDir = args[++i]; break;
                case "--consensus-base-port": consensusBasePort = Integer.parseInt(args[++i]); break;
                case "--ingress-base-port":   ingressBasePort = Integer.parseInt(args[++i]); break;
                default: break;
            }
        }
    }

    @Override
    public void start() throws Exception {
        File dir = new File(dataDir);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("无法创建数据目录: " + dataDir);
        }
        String aeronDir = new File(dir, "aeron").getAbsolutePath();
        String clusterDir = new File(dir, "cluster").getAbsolutePath();
        String archiveDir = new File(dir, "archive").getAbsolutePath();

        String clusterMembers = buildClusterMembers();

        // ---------- 集群成员：MediaDriver + Archive + ConsensusModule ----------
        MediaDriver.Context mediaDriverCtx = new MediaDriver.Context()
                .aeronDirectoryName(aeronDir)
                .dirDeleteOnStart(true)
                .dirDeleteOnShutdown(false)
                .termBufferSparseFile(false)
                .threadingMode(io.aeron.driver.ThreadingMode.SHARED)
                .errorHandler(t -> log.error("[MediaDriver] {}", t.getMessage()));

        Archive.Context archiveCtx = new Archive.Context()
                .aeronDirectoryName(aeronDir)
                .archiveDir(new File(archiveDir))
                .errorHandler(t -> log.error("[Archive] {}", t.getMessage()));

        ConsensusModule.Context consensusModuleCtx = new ConsensusModule.Context()
                .clusterMemberId(memberId)
                .clusterMembers(clusterMembers)
                .clusterDir(new File(clusterDir))
                .aeronDirectoryName(aeronDir)
                .ingressChannel("aeron:udp?term-length=64k")
                .logChannel("aeron:udp?term-length=256k")
                .errorHandler(t -> log.error("[ConsensusModule] {}", t.getMessage()));

        clusteredMediaDriver = ClusteredMediaDriver.launch(mediaDriverCtx, archiveCtx, consensusModuleCtx);

        // ---------- 集群服务（你的状态机） ----------
        service = new ClusteredMetaService();
        ClusteredServiceContainer.Context serviceCtx = new ClusteredServiceContainer.Context()
                .aeronDirectoryName(aeronDir)
                .archiveDir(new File(archiveDir))
                .clusterDir(new File(clusterDir))
                .clusteredService(service)
                .errorHandler(t -> log.error("[ClusteredService] {}", t.getMessage()));
        serviceContainer = ClusteredServiceContainer.launch(serviceCtx);

        log.info("Aeron Cluster 成员已启动: memberId={}, aeronDir={}", memberId, aeronDir);

        // ---------- 集群客户端 ----------
        connectClient();

        log.info("Aeron Cluster 就绪: {}", implementation());
    }

    private String buildClusterMembers() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            if (i > 0) {
                sb.append('|');
            }
            sb.append(i).append(',')
              .append(host).append(':').append(consensusBasePort + i).append(',')
              .append(host).append(':').append(ingressBasePort + i).append(',')
              .append(host).append(':').append(logBasePort + i).append(',')
              .append(host).append(':').append(catchupBasePort + i).append(',')
              .append(host).append(':').append(archiveBasePort + i);
        }
        return sb.toString();
    }

    private void connectClient() {
        StringBuilder ingressEndpoints = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            if (i > 0) {
                ingressEndpoints.append(',');
            }
            ingressEndpoints.append(i).append('=').append(host).append(':').append(ingressBasePort + i);
        }

        String clientAeronDir = new File(new File(dataDir), "aeron-client").getAbsolutePath();

        Context ctx = new AeronCluster.Context()
                .aeronDirectoryName(clientAeronDir)
                .ingressChannel("aeron:udp")
                .ingressEndpoints(ingressEndpoints.toString())
                .egressChannel("aeron:udp?endpoint=" + host + ":0")
                .egressListener(new EgressListener() {
                    @Override
                    public void onMessage(long clusterSessionId, long timestamp,
                                          DirectBuffer buffer, int offset, int length, io.aeron.logbuffer.Header header) {
                        long correlationId = buffer.getLong(offset);
                        byte[] payload = new byte[length - 8];
                        buffer.getBytes(offset + 8, payload);
                        BlockingQueue<byte[]> q = pending.get(correlationId);
                        if (q != null) {
                            q.offer(payload);
                        }
                    }

                    @Override
                    public void onSessionEvent(long correlationId, long clusterSessionId,
                                               long leadershipTermId, int leaderMemberId,
                                               EventCode code, String detail) {
                        log.info("集群会话事件: code={}, detail={}", code, detail);
                    }

                    @Override
                    public void onNewLeader(long clusterSessionId, long leadershipTermId,
                                            int leaderMemberId, String memberEndpoints) {
                        log.info("新的 Leader: memberId={}, endpoints={}", leaderMemberId, memberEndpoints);
                    }
                });

        client = AeronCluster.connect(ctx);
        log.info("Aeron Cluster 客户端已连接, ingressEndpoints={}", ingressEndpoints);
    }

    @Override
    public boolean isLeader() {
        return service != null && service.isLeader();
    }

    @Override
    public String role() {
        return service == null ? "UNKNOWN" : service.role().name();
    }

    @Override
    public String propose(Command cmd) throws Exception {
        long start = System.nanoTime();
        long cid = correlationIdGen.getAndIncrement();
        BlockingQueue<byte[]> q = new ArrayBlockingQueue<>(1);
        pending.put(cid, q);

        byte[] cmdBytes = cmd.serialize();
        offerBuffer.putLong(0, cid);
        offerBuffer.putBytes(8, cmdBytes);
        int total = 8 + cmdBytes.length;

        try {
            long result;
            while ((result = client.offer(offerBuffer, 0, total)) < 0) {
                idle.idle();
            }
            if (result == 0) {
                Metrics.get().proposeErrors().increment();
                throw new IllegalStateException("offer 被背压拒绝");
            }

            byte[] reply = q.poll(10, TimeUnit.SECONDS);
            if (reply == null) {
                Metrics.get().proposeErrors().increment();
                throw new IllegalStateException("等待集群响应超时（10s）");
            }
            long costUs = (System.nanoTime() - start) / 1000;
            Metrics.get().proposeDuration().record(costUs, TimeUnit.MICROSECONDS);
            return new String(reply, java.nio.charset.StandardCharsets.UTF_8)
                    + ", cost=" + costUs + "us";
        } finally {
            pending.remove(cid);
        }
    }

    @Override
    public String linearizableGet(String key) throws Exception {
        // Aeron 的读：客户端可连任意成员，Follower 会重定向到 Leader；
        // 只有 Leader 的 Egress 响应真正生效，因此天然满足线性一致。
        // 这里直接读本地状态机（已按日志顺序 apply），演示语义等价。
        return service.table().kv(key);
    }

    @Override
    public RouteTable stateMachine() {
        return service.table();
    }

    @Override
    public String implementation() {
        return "AeronCluster";
    }

    @Override
    public void close() {
        CloseHelper.close(client);
        CloseHelper.close(serviceContainer);
        CloseHelper.close(clusteredMediaDriver);
        log.info("Aeron Cluster 已关闭");
    }
}
