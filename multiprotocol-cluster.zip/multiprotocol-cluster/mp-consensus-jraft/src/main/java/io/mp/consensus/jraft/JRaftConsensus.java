package io.mp.consensus.jraft;

import com.alipay.sofa.jraft.Node;
import com.alipay.sofa.jraft.RaftGroupService;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.entity.Task;
import com.alipay.sofa.jraft.option.NodeOptions;
import com.alipay.sofa.jraft.rpc.RaftRpcServerFactory;
import com.alipay.sofa.jraft.rpc.RpcServer;
import com.alipay.sofa.jraft.util.BytesUtil;
import io.mp.common.model.Command;
import io.mp.common.model.RouteTable;
import io.mp.consensus.Consensus;
import io.mp.observability.Metrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * SOFAJRaft 共识实现。
 *
 * <p>启动参数（{@code --} 形式）：
 * <pre>
 *   --node-id    1
 *   --raft-port  8081
 *   --peers      127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083
 *   --data-dir   ./data/node1
 *   --group-id   mp-meta-group
 * </pre>
 *
 * <p>与 Aeron 实现的关键差异（详见方案文档）：
 * <ul>
 *   <li>提交判定：多数派<b>已接收</b>即推进 commitIndex，fsync 策略可配 → 延迟更灵活</li>
 *   <li>原生 Multi-Raft-Group：本 demo 只启动 1 组，生产可按需扩展到 10K+ 组</li>
 *   <li>线性读走 ReadIndex（本实现），生产可切 LeaseRead 进一步降低读延迟</li>
 *   <li>无强制确定性约束，业务可自行决定并发度</li>
 * </ul>
 */
public class JRaftConsensus implements Consensus {

    private static final Logger log = LoggerFactory.getLogger(JRaftConsensus.class);

    private String nodeId = "127.0.0.1:8081";
    private int raftPort = 8081;
    private String peers = "127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083";
    private String dataDir = "./data/node1";
    private String groupId = "mp-meta-group";

    private RaftGroupService raftGroupService;
    private Node node;
    private MetaStateMachine stateMachine;
    private PeerId serverId;
    private RpcServer rpcServer;

    public JRaftConsensus(String[] args) {
        parseArgs(args);
    }

    private void parseArgs(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--node-id":   nodeId = args[++i]; break;
                case "--raft-port": raftPort = Integer.parseInt(args[++i]); break;
                case "--peers":     peers = args[++i]; break;
                case "--data-dir":  dataDir = args[++i]; break;
                case "--group-id":  groupId = args[++i]; break;
                default: break;
            }
        }
    }

    @Override
    public void start() throws Exception {
        // 数据目录：WAL / Meta / Snapshot 分开存放，便于独立挂载磁盘
        String logUri = dataDir + File.separator + "raft-log";
        String metaUri = dataDir + File.separator + "raft-meta";
        String snapshotUri = dataDir + File.separator + "snapshot";
        for (String dir : new String[]{logUri, metaUri, snapshotUri}) {
            java.nio.file.Files.createDirectories(java.nio.file.Paths.get(dir));
        }

        serverId = PeerId.parsePeer(nodeId);
        Configuration conf = new Configuration();
        for (String p : peers.split(",")) {
            if (p.trim().isEmpty()) {
                continue;
            }
            conf.addPeer(PeerId.parsePeer(p.trim()));
        }

        stateMachine = new MetaStateMachine();

        NodeOptions nodeOptions = new NodeOptions();
        nodeOptions.setElectionTimeoutMs(1000);     // 选举超时，随机化由 JRaft 内部处理
        nodeOptions.setDisableCli(false);
        nodeOptions.setLogUri(logUri);
        nodeOptions.setRaftMetaUri(metaUri);
        nodeOptions.setSnapshotUri(snapshotUri);
        nodeOptions.setFsm(stateMachine);
        nodeOptions.setInitialConf(conf);
        nodeOptions.setSnapshotIntervalSecs(120);
        // 生产建议：开启 Pre-Vote 避免网络抖动引发无谓选举
        nodeOptions.setEnableFollowerSnapshotGeneration(false);

        rpcServer = RaftRpcServerFactory.createRaftRpcServer(raftPort);
        raftGroupService = new RaftGroupService(groupId, serverId, nodeOptions, rpcServer);
        node = raftGroupService.start();

        log.info("SOFAJRaft 已启动: groupId={}, serverId={}, peers={}", groupId, nodeId, peers);

        // 等待选出 Leader（demo 场景同步等待，生产应异步处理）
        for (int i = 0; i < 30; i++) {
            if (node.getLeaderId() != null) {
                log.info("Leader 已就绪: {}", node.getLeaderId());
                break;
            }
            TimeUnit.MILLISECONDS.sleep(500);
        }
    }

    @Override
    public boolean isLeader() {
        return node != null && node.isLeader();
    }

    @Override
    public String role() {
        if (node == null) {
            return "UNKNOWN";
        }
        return node.isLeader() ? "LEADER" : "FOLLOWER";
    }

    @Override
    public String propose(Command cmd) throws Exception {
        if (!isLeader()) {
            throw new IllegalStateException("本节点非 Leader，当前 Leader=" + leaderHint());
        }
        long start = System.nanoTime();
        Task task = new Task();
        task.setData(ByteBuffer.wrap(cmd.serialize()));

        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Status> ref = new AtomicReference<>();
        task.setDone(status -> {
            ref.set(status);
            latch.countDown();
        });

        node.apply(task);

        if (!latch.await(10, TimeUnit.SECONDS)) {
            Metrics.get().proposeErrors().increment();
            throw new IllegalStateException("propose 超时（10s）");
        }
        Status status = ref.get();
        if (status == null || !status.isOk()) {
            Metrics.get().proposeErrors().increment();
            throw new IllegalStateException("propose 失败: " + (status == null ? "未知" : status.getErrorMsg()));
        }

        long costUs = (System.nanoTime() - start) / 1000;
        Metrics.get().proposeDuration().record(costUs, TimeUnit.MICROSECONDS);
        return "applied, cost=" + costUs + "us";
    }

    @Override
    public String linearizableGet(String key) throws Exception {
        if (node == null) {
            throw new IllegalStateException("节点未启动");
        }
        // ReadIndex：先确认 Leader 身份，再等本地 appliedIndex 追上，最后读状态机
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> result = new AtomicReference<>();
        AtomicReference<Status> statusRef = new AtomicReference<>();

        node.readIndex(BytesUtil.EMPTY_BYTES, new com.alipay.sofa.jraft.ReadIndexClosure() {
            @Override
            public void run(Status status, long index, byte[] reqCtx) {
                if (status.isOk()) {
                    // index 之前的日志均已 apply，可安全读取状态机
                    result.set(stateMachine.table().kv(key));
                } else {
                    statusRef.set(status);
                }
                latch.countDown();
            }
        });

        if (!latch.await(5, TimeUnit.SECONDS)) {
            throw new IllegalStateException("线性读超时");
        }
        Status st = statusRef.get();
        if (st != null) {
            throw new IllegalStateException("线性读失败: " + st.getErrorMsg());
        }
        return result.get();
    }

    @Override
    public RouteTable stateMachine() {
        return stateMachine.table();
    }

    @Override
    public String implementation() {
        return "SOFAJRaft";
    }

    private String leaderHint() {
        return node == null || node.getLeaderId() == null ? "未知" : node.getLeaderId().toString();
    }

    @Override
    public void close() {
        if (raftGroupService != null) {
            raftGroupService.shutdown();
        }
        if (rpcServer != null) {
            rpcServer.shutdown();
        }
        log.info("SOFAJRaft 已关闭");
    }
}
