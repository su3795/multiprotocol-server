package io.mp.consensus.jraft;

import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Iterator;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.core.StateMachineAdapter;
import com.alipay.sofa.jraft.entity.LeaderChangeContext;
import com.alipay.sofa.jraft.error.RaftError;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotReader;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotWriter;
import io.mp.common.model.Command;
import io.mp.common.model.RouteTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SOFAJRaft 状态机。
 *
 * <p><b>只承载元数据</b>：路由表、配置、会话归属、演示用 KV。
 * 业务数据流绝不进入这里，否则共识层会成为吞吐天花板。
 *
 * <p>两个必须遵守的约定：
 * <ol>
 *   <li>{@code onApply} 必须幂等 —— Raft 在重放、重试时会重复调用</li>
 *   <li>{@code onApply} 内不做阻塞 IO —— 会拖慢 apply，导致 apply lag 累积</li>
 * </ol>
 */
public class MetaStateMachine extends StateMachineAdapter {

    private static final Logger log = LoggerFactory.getLogger(MetaStateMachine.class);
    private static final String SNAPSHOT_FILE = "meta.snap";

    private final RouteTable table = new RouteTable();
    private final AtomicLong appliedIndex = new AtomicLong(0);
    private final AtomicLong term = new AtomicLong(0);

    public RouteTable table() {
        return table;
    }

    public long appliedIndex() {
        return appliedIndex.get();
    }

    public long term() {
        return term.get();
    }

    @Override
    public void onApply(Iterator iter) {
        while (iter.hasNext()) {
            long index = iter.getIndex();
            ByteBuffer data = iter.getData().duplicate();
            byte[] bytes = new byte[data.remaining()];
            data.get(bytes);

            try {
                Command cmd = Command.deserialize(bytes);
                table.apply(cmd);          // 幂等写入
                appliedIndex.set(index);
                log.debug("apply index={} cmd={}", index, cmd);
            } catch (Exception e) {
                log.error("apply 失败 index={}", index, e);
            }
            iter.next();
        }
    }

    @Override
    public void onSnapshotSave(SnapshotWriter writer, Closure done) {
        Path path = Paths.get(writer.getPath(), SNAPSHOT_FILE);
        try {
            byte[] snapshot = table.snapshot();
            Files.write(path, snapshot);
            writer.addFile(SNAPSHOT_FILE);
            log.info("快照已保存: {} ({} bytes)", path, snapshot.length);
            done.run(Status.OK());
        } catch (Exception e) {
            log.error("快照保存失败", e);
            done.run(new Status(RaftError.EIO, "快照保存失败: %s", e.getMessage()));
        }
    }

    @Override
    public boolean onSnapshotLoad(SnapshotReader reader) {
        if (!reader.listFiles().contains(SNAPSHOT_FILE)) {
            log.warn("快照中未找到 {}", SNAPSHOT_FILE);
            return false;
        }
        Path path = Paths.get(reader.getPath(), SNAPSHOT_FILE);
        try {
            byte[] data = Files.readAllBytes(path);
            table.loadSnapshot(data);
            log.info("快照已加载: {} ({} bytes)", path, data.length);
            return true;
        } catch (Exception e) {
            log.error("快照加载失败", e);
            return false;
        }
    }

    @Override
    public void onLeaderStart(long newTerm) {
        term.set(newTerm);
        log.info("==> 本节点成为 Leader, term={}", newTerm);
    }

    @Override
    public void onLeaderStop(Status status) {
        log.info("==> 本节点卸任 Leader, status={}", status);
    }

    @Override
    public void onStartFollowing(LeaderChangeContext ctx) {
        log.info("==> 开始跟随 Leader: {}", ctx.getLeaderId());
    }

    @Override
    public void onStopFollowing(LeaderChangeContext ctx) {
        log.info("==> 停止跟随 Leader: {}", ctx.getLeaderId());
    }

    @Override
    public void onConfigurationCommitted(Configuration conf) {
        log.info("==> 配置已提交: {}", conf);
    }
}
