package io.mp.common.codec;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

/** 帧编解码测试（零依赖，可独立运行） */
class FrameCodecTest {

    @Test
    void encodeDecodeRoundTrip() {
        byte[] payload = "key=value".getBytes(StandardCharsets.UTF_8);
        Frame frame = new Frame(Frame.FLAG_NEED_RESPONSE, 1, 42L, payload);

        byte[] data = FrameCodec.encode(frame);
        assertEquals(frame.encodedLength(), data.length, "编码长度应等于 头部+payload+CRC");

        Frame decoded = FrameCodec.decode(data);
        assertEquals(frame.cmd(), decoded.cmd());
        assertEquals(frame.seq(), decoded.seq());
        assertEquals(frame.flags(), decoded.flags());
        assertArrayEquals(payload, decoded.payload());
        assertTrue(decoded.needResponse());
    }

    @Test
    void emptyPayload() {
        Frame frame = new Frame((byte) 0, 5, 1L, new byte[0]);
        byte[] data = FrameCodec.encode(frame);
        assertEquals(Frame.HEADER_SIZE + Frame.CRC_SIZE, data.length);
        Frame decoded = FrameCodec.decode(data);
        assertEquals(0, decoded.payload().length);
        assertFalse(decoded.needResponse());
    }

    @Test
    void magicMismatchRejected() {
        byte[] data = FrameCodec.encode(new Frame((byte) 0, 1, 1L, "x".getBytes()));
        data[0] = 0x00; // 破坏 magic
        assertThrows(IllegalArgumentException.class, () -> FrameCodec.decode(data));
    }

    @Test
    void corruptedPayloadFailsCrc() {
        byte[] data = FrameCodec.encode(new Frame((byte) 0, 1, 1L, "hello".getBytes()));
        // 篡改 payload 首字节
        data[Frame.HEADER_SIZE] = (byte) (data[Frame.HEADER_SIZE] ^ 0xFF);
        assertThrows(IllegalArgumentException.class, () -> FrameCodec.decode(data));
    }

    @Test
    void halfPacketReturnsNull() {
        byte[] data = FrameCodec.encode(new Frame((byte) 0, 1, 1L, "half packet".getBytes()));
        byte[] partial = new byte[Frame.HEADER_SIZE + 3];
        System.arraycopy(data, 0, partial, 0, partial.length);

        assertNull(FrameCodec.tryDecode(partial, partial.length), "数据不足一整帧时应返回 null");
    }

    @Test
    void fullPacketDecodesFromStream() {
        byte[] data = FrameCodec.encode(new Frame((byte) 0, 2, 9L, "full".getBytes()));
        Frame f = FrameCodec.tryDecode(data, data.length);
        assertNotNull(f);
        assertEquals("full", new String(f.payload(), StandardCharsets.UTF_8));
        assertEquals(9L, f.seq());
    }

    @Test
    void commandRoundTrip() {
        io.mp.common.model.Command cmd =
                io.mp.common.model.Command.upsertRoute(7L, "node-3");
        byte[] bytes = cmd.serialize();
        io.mp.common.model.Command back =
                io.mp.common.model.Command.deserialize(bytes);
        assertEquals(io.mp.common.model.Command.Type.UPSERT_ROUTE, back.type());
        assertEquals(7L, back.shardId());
        assertEquals("node-3", back.node());
    }
}
