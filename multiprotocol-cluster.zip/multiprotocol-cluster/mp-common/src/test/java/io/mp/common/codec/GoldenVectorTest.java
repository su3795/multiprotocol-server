package io.mp.common.codec;

/**
 * golden 向量测试 —— 由参考实现（Node.js）生成，经 Python 独立复刻交叉验证。
 *
 * <p>用例来源: {@code reference-impl/golden/frames.json}
 * 三版（Java/Go/Rust）编码结果必须逐字节一致。
 * 任何一条失败都说明本版帧编码实现与基准不符。
 */
class GoldenVectorTest {

    private static final class V {
        final String name;
        final int flags;
        final int cmd;
        final long seq;
        final String payload;
        final String wantHex;

        V(String name, int flags, int cmd, long seq, String payload, String wantHex) {
            this.name = name;
            this.flags = flags;
            this.cmd = cmd;
            this.seq = seq;
            this.payload = payload;
            this.wantHex = wantHex;
        }
    }

    private static final V[] VECTORS = {
        new V("empty_ping", 0x01, 5, 1L, "",
                "4d500101000000050000000000000001000000002fa0284c"),
        new V("ping_hello", 0x01, 5, 2L, "hello",
                "4d5001010000000500000000000000020000000568656c6c6fbe0bdba2"),
        new V("put_kv", 0x01, 1, 3L, "user:1=alice",
                "4d5001010000000100000000000000030000000c757365723a313d616c696365422b2ee3"),
        new V("get_key", 0x01, 2, 4L, "user:1",
                "4d50010100000002000000000000000400000006757365723a31d44d66bb"),
        new V("route_set", 0x01, 3, 5L, "7=node-3",
                "4d50010100000003000000000000000500000008373d6e6f64652d333a115965"),
        new V("route_get", 0x01, 4, 6L, "7",
                "4d50010100000004000000000000000600000001378ceb079e"),
        new V("stats", 0x01, 6, 7L, "",
                "4d500101000000060000000000000007000000001d2ab122"),
        new V("utf8_chinese", 0x01, 1, 8L, "\u540d\u5b57=\u5f20\u4e09",
                "4d5001010000000100000000000000080000000de5908de5ad973de5bca0e4b8899fb3a2ea"),
        new V("large_seq", 0x01, 2, 9007199254740991L, "k",
                "4d50010100000002001fffffffffffff000000016b5cab6f88"),
        new V("binary_payload", 0x01, 1, 9L, "a\u0000b\u00ffc",
                "4d50010100000001000000000000000900000006610062c3bf63006087cf"),
        new V("flag_compressed", 0x02, 5, 10L, "x",
                "4d50010200000005000000000000000a00000001786ac3a7f0"),
        new V("flag_all", 0x07, 5, 11L, "y",
                "4d50010700000005000000000000000b000000017932622524"),
    };

    private static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) { sb.append(String.format("%02x", x)); }
        return sb.toString();
    }

    @org.junit.jupiter.api.Test
    void goldenEmptyPing() {
        V v = find("empty_ping");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenPingHello() {
        V v = find("ping_hello");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenPutKv() {
        V v = find("put_kv");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenGetKey() {
        V v = find("get_key");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenRouteSet() {
        V v = find("route_set");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenRouteGet() {
        V v = find("route_get");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenStats() {
        V v = find("stats");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenUtf8Chinese() {
        V v = find("utf8_chinese");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenLargeSeq() {
        V v = find("large_seq");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenBinaryPayload() {
        V v = find("binary_payload");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenFlagCompressed() {
        V v = find("flag_compressed");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    @org.junit.jupiter.api.Test
    void goldenFlagAll() {
        V v = find("flag_all");
        Frame frame = new Frame(Frame.VERSION, (byte) v.flags, v.cmd, v.seq,
                v.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String got = toHex(FrameCodec.encode(frame));
        org.junit.jupiter.api.Assertions.assertEquals(v.wantHex, got,
                "golden 向量 " + v.name + " 不匹配");
    }

    private static V find(String name) {
        for (V v : VECTORS) { if (v.name.equals(name)) { return v; } }
        throw new IllegalArgumentException("未找到向量: " + name);
    }
}
