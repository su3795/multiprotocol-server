package io.mp.common.codec;

import java.nio.ByteBuffer;
import java.util.zip.CRC32;

/**
 * 帧编解码器。纯 JDK 实现，不依赖 Netty，便于单测与跨模块复用。
 *
 * <p>校验范围：从 version 字段到 payload 末尾（不含 magic 与 crc32 本身）。
 */
public final class FrameCodec {

    private FrameCodec() {
    }

    /** 编码为完整字节数组（含 magic 与 crc32） */
    public static byte[] encode(Frame frame) {
        byte[] out = new byte[frame.encodedLength()];
        ByteBuffer buf = ByteBuffer.wrap(out);

        buf.putShort(Frame.MAGIC);
        buf.put(frame.version());
        buf.put(frame.flags());
        buf.putInt(frame.cmd());
        buf.putLong(frame.seq());
        buf.putInt(frame.payload().length);
        buf.put(frame.payload());

        CRC32 crc = new CRC32();
        // 覆盖 version(1) 起到 payload 结束：偏移 2 .. (2 + 18 + len)
        crc.update(out, 2, Frame.HEADER_SIZE - 2 + frame.payload().length);
        buf.putInt((int) crc.getValue());

        return out;
    }

    /**
     * 解码。要求入参是从 magic 开始的完整一帧。
     *
     * @throws IllegalArgumentException 长度不足、magic 不匹配或 CRC 校验失败
     */
    public static Frame decode(byte[] data) {
        return decode(data, 0, data.length);
    }

    public static Frame decode(byte[] data, int offset, int length) {
        if (length < Frame.HEADER_SIZE + Frame.CRC_SIZE) {
            throw new IllegalArgumentException("帧长度不足: " + length);
        }
        ByteBuffer buf = ByteBuffer.wrap(data, offset, length);

        short magic = buf.getShort();
        if (magic != Frame.MAGIC) {
            throw new IllegalArgumentException(
                    String.format("magic 不匹配: 期望 0x%04X 实际 0x%04X", Frame.MAGIC, magic));
        }

        byte version = buf.get();
        byte flags = buf.get();
        int cmd = buf.getInt();
        long seq = buf.getLong();
        int payloadLen = buf.getInt();

        if (payloadLen < 0 || payloadLen > length - Frame.HEADER_SIZE - Frame.CRC_SIZE) {
            throw new IllegalArgumentException("payload 长度非法: " + payloadLen);
        }

        byte[] payload = new byte[payloadLen];
        buf.get(payload);
        int actualCrc = buf.getInt();

        CRC32 crc = new CRC32();
        crc.update(data, offset + 2, Frame.HEADER_SIZE - 2 + payloadLen);
        if ((int) crc.getValue() != actualCrc) {
            throw new IllegalArgumentException("CRC32 校验失败");
        }

        return new Frame(version, flags, cmd, seq, payload);
    }

    /**
     * 从缓冲区中尝试切出一帧，用于 TCP 流式分帧。
     *
     * @return 解析出的帧；若数据不足一整帧返回 null（调用方应继续累积）
     */
    public static Frame tryDecode(byte[] accumulated, int readable) {
        if (readable < Frame.HEADER_SIZE) {
            return null;
        }
        ByteBuffer peek = ByteBuffer.wrap(accumulated, 0, Frame.HEADER_SIZE);
        peek.getShort(); // magic
        peek.get();      // version
        peek.get();      // flags
        peek.getInt();   // cmd
        peek.getLong();  // seq
        int payloadLen = peek.getInt();

        if (payloadLen < 0) {
            throw new IllegalArgumentException("payload 长度为负");
        }
        int total = Frame.HEADER_SIZE + payloadLen + Frame.CRC_SIZE;
        if (readable < total) {
            return null;
        }
        return decode(accumulated, 0, total);
    }

    /** 计算给定数据应从累积缓冲中消费的字节数 */
    public static int frameLength(byte[] accumulated) {
        ByteBuffer peek = ByteBuffer.wrap(accumulated, 0, Frame.HEADER_SIZE);
        peek.getShort();
        peek.get();
        peek.get();
        peek.getInt();
        peek.getLong();
        return Frame.HEADER_SIZE + peek.getInt() + Frame.CRC_SIZE;
    }
}
