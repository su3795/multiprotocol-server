package io.mp.common.codec;

import java.util.Arrays;

/**
 * 统一帧结构（协议无关）。
 *
 * <pre>
 * 字段布局（大端序）：
 *   magic   : 2 bytes  固定 0x4D50 ("MP")
 *   version : 1 byte   当前 1
 *   flags   : 1 byte   bit0=需要响应 bit1=压缩 bit2=加密
 *   cmd     : 4 bytes  命令字
 *   seq     : 8 bytes  请求序号（用于请求-响应配对）
 *   length  : 4 bytes  payload 长度
 *   payload : N bytes
 *   crc32   : 4 bytes  覆盖 [version .. payload] 的校验和
 *
 * 头部固定 20 字节，尾部 CRC 4 字节。
 * </pre>
 */
public final class Frame {

    public static final short MAGIC = 0x4D50; // 'M''P'
    public static final byte VERSION = 1;
    /** 头部：magic(2)+ver(1)+flags(1)+cmd(4)+seq(8)+len(4) */
    public static final int HEADER_SIZE = 20;
    public static final int CRC_SIZE = 4;

    public static final int FLAG_NEED_RESPONSE = 0x01;
    public static final int FLAG_COMPRESSED = 0x02;
    public static final int FLAG_ENCRYPTED = 0x04;

    private final byte version;
    private final byte flags;
    private final int cmd;
    private final long seq;
    private final byte[] payload;

    public Frame(byte flags, int cmd, long seq, byte[] payload) {
        this(VERSION, flags, cmd, seq, payload);
    }

    public Frame(byte version, byte flags, int cmd, long seq, byte[] payload) {
        this.version = version;
        this.flags = flags;
        this.cmd = cmd;
        this.seq = seq;
        this.payload = payload == null ? new byte[0] : payload;
    }

    public byte version() { return version; }
    public byte flags() { return flags; }
    public int cmd() { return cmd; }
    public long seq() { return seq; }
    public byte[] payload() { return payload; }

    public boolean needResponse() {
        return (flags & FLAG_NEED_RESPONSE) != 0;
    }

    public boolean compressed() {
        return (flags & FLAG_COMPRESSED) != 0;
    }

    public boolean encrypted() {
        return (flags & FLAG_ENCRYPTED) != 0;
    }

    /** 编码后的总长度 */
    public int encodedLength() {
        return HEADER_SIZE + payload.length + CRC_SIZE;
    }

    @Override
    public String toString() {
        return "Frame{cmd=" + cmd + ", seq=" + seq + ", flags=" + flags
                + ", payloadLen=" + payload.length + '}';
    }

    /** 浅比较用：payload 内容比较 */
    public boolean payloadEquals(Frame other) {
        return other != null && Arrays.equals(this.payload, other.payload);
    }
}
