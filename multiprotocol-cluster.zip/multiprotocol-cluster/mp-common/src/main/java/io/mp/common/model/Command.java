package io.mp.common.model;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 上共识层的命令模型。
 *
 * <p><b>设计约束：只承载元数据</b>（路由表、配置、会话归属、少量 KV），
 * 业务数据流永不进入共识层，否则 Raft 会成为吞吐天花板。
 *
 * <p>序列化格式：type(1) + 按类型排列的字段（字符串用 UTF 长度前缀）。
 */
public final class Command {

    public enum Type {
        /** shard -> node 的路由表更新 */
        UPSERT_ROUTE(1),
        /** 全局配置项更新 */
        UPDATE_CONFIG(2),
        /** 会话归属迁移 */
        TRANSFER_OWNER(3),
        /** 通用 KV 写入（便于演示线性一致读） */
        PUT_KV(4);

        private final byte code;

        Type(int code) {
            this.code = (byte) code;
        }

        public byte code() {
            return code;
        }

        public static Type of(byte code) {
            for (Type t : values()) {
                if (t.code == code) {
                    return t;
                }
            }
            throw new IllegalArgumentException("未知命令类型: " + code);
        }
    }

    private final Type type;
    private final long key1;      // UPSERT_ROUTE: shardId ; TRANSFER_OWNER: connId
    private final String key2;    // UPSERT_ROUTE: node ; UPDATE_CONFIG/PUT_KV: key
    private final String value;   // UPDATE_CONFIG/PUT_KV: value

    private Command(Type type, long key1, String key2, String value) {
        this.type = type;
        this.key1 = key1;
        this.key2 = key2 == null ? "" : key2;
        this.value = value == null ? "" : value;
    }

    // ---------- 工厂方法 ----------

    public static Command upsertRoute(long shardId, String node) {
        return new Command(Type.UPSERT_ROUTE, shardId, node, "");
    }

    public static Command updateConfig(String key, String value) {
        return new Command(Type.UPDATE_CONFIG, 0L, key, value);
    }

    public static Command transferOwner(long connId, String node) {
        return new Command(Type.TRANSFER_OWNER, connId, node, "");
    }

    public static Command putKv(String key, String value) {
        return new Command(Type.PUT_KV, 0L, key, value);
    }

    // ---------- 访问器 ----------

    public Type type() { return type; }
    public long key1() { return key1; }
    public String key2() { return key2; }
    public String value() { return value; }

    /** UPSERT_ROUTE 场景下的语义化访问器 */
    public long shardId() { return key1; }
    public String node() { return key2; }

    // ---------- 序列化 ----------

    public byte[] serialize() {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bos)) {
            out.writeByte(type.code());
            out.writeLong(key1);
            out.writeUTF(key2);
            out.writeUTF(value);
        } catch (IOException e) {
            throw new IllegalStateException("命令序列化失败", e);
        }
        return bos.toByteArray();
    }

    public static Command deserialize(byte[] data) {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
            Type t = Type.of(in.readByte());
            long k1 = in.readLong();
            String k2 = in.readUTF();
            String v = in.readUTF();
            return new Command(t, k1, k2, v);
        } catch (IOException e) {
            throw new IllegalArgumentException("命令反序列化失败", e);
        }
    }

    @Override
    public String toString() {
        return "Command{" + type + ", key1=" + key1 + ", key2='" + key2 + "', value='" + value + "'}";
    }
}
