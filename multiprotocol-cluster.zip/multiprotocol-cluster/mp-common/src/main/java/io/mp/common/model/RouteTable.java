package io.mp.common.model;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 状态机持有的共享状态：路由表 + 配置 + 会话归属 + 演示用 KV。
 *
 * <p><b>关键约定</b>：
 * <ul>
 *   <li>写操作只能经由共识层 apply（保证所有副本顺序一致）</li>
 *   <li>读操作视一致性级别选择：线性读（ReadIndex/Lease）或本地读</li>
 *   <li>所有变更必须幂等 —— Raft 在重放与重试时会重复 apply 同一条日志</li>
 * </ul>
 */
public final class RouteTable {

    private final Map<Long, String> routes = new ConcurrentHashMap<>();
    private final Map<String, String> config = new ConcurrentHashMap<>();
    private final Map<Long, String> owners = new ConcurrentHashMap<>();
    private final Map<String, String> kv = new ConcurrentHashMap<>();

    /** 应用一条命令（幂等） */
    public void apply(Command cmd) {
        switch (cmd.type()) {
            case UPSERT_ROUTE:
                routes.put(cmd.shardId(), cmd.node());
                break;
            case UPDATE_CONFIG:
                config.put(cmd.key2(), cmd.value());
                break;
            case TRANSFER_OWNER:
                owners.put(cmd.key1(), cmd.node());
                break;
            case PUT_KV:
                kv.put(cmd.key2(), cmd.value());
                break;
            default:
                throw new IllegalArgumentException("不支持的命令: " + cmd.type());
        }
    }

    public String route(long shardId) {
        return routes.get(shardId);
    }

    public String config(String key) {
        return config.get(key);
    }

    public String owner(long connId) {
        return owners.get(connId);
    }

    public String kv(String key) {
        return kv.get(key);
    }

    public int routeCount() {
        return routes.size();
    }

    public int kvCount() {
        return kv.size();
    }

    public Map<Long, String> routes() {
        return Collections.unmodifiableMap(routes);
    }

    public Map<String, String> kv() {
        return Collections.unmodifiableMap(kv);
    }

    /** 全量替换（快照恢复时使用） */
    public void restore(Map<Long, String> newRoutes, Map<String, String> newKv) {
        routes.clear();
        routes.putAll(newRoutes);
        kv.clear();
        kv.putAll(newKv);
    }

    /** 快照序列化：简单 "k=v\n" 文本格式，便于观察与调试 */
    public byte[] snapshot() {
        StringBuilder sb = new StringBuilder();
        routes.forEach((k, v) -> sb.append("R:").append(k).append('=').append(v).append('\n'));
        config.forEach((k, v) -> sb.append("C:").append(k).append('=').append(v).append('\n'));
        kv.forEach((k, v) -> sb.append("K:").append(k).append('=').append(v).append('\n'));
        return sb.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }

    /** 快照反序列化 */
    public void loadSnapshot(byte[] data) {
        String text = new String(data, java.nio.charset.StandardCharsets.UTF_8);
        routes.clear();
        config.clear();
        kv.clear();
        for (String line : text.split("\n")) {
            if (line.length() < 3) {
                continue;
            }
            char kind = line.charAt(0);
            int eq = line.indexOf('=', 2);
            if (eq <= 0) {
                continue;
            }
            String k = line.substring(2, eq);
            String v = line.substring(eq + 1);
            switch (kind) {
                case 'R': routes.put(Long.parseLong(k), v); break;
                case 'C': config.put(k, v); break;
                case 'K': kv.put(k, v); break;
                default: break;
            }
        }
    }
}
