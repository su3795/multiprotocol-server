package io.mp.common.codec;

/**
 * 支持的传输协议。接入层按协议装配不同的 ChannelHandler 链。
 */
public enum Protocol {
    TCP((byte) 1, "可靠有序字节流"),
    UDP((byte) 2, "无连接数据报"),
    QUIC((byte) 3, "可靠 UDP / HTTP3"),
    KCP((byte) 4, "ARQ over UDP"),
    CUSTOM((byte) 5, "私有帧协议");

    private final byte code;
    private final String desc;

    Protocol(byte code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public byte code() {
        return code;
    }

    public String desc() {
        return desc;
    }

    public static Protocol of(byte code) {
        for (Protocol p : values()) {
            if (p.code == code) {
                return p;
            }
        }
        throw new IllegalArgumentException("未知协议码: " + code);
    }
}
